// USA Spending Analyzer - Frontend JavaScript
// FIXED: Enhanced with standardized financial calculations matching backend
// FIXED: Display correct financial metrics consistent with Excel and JSON

// Global variables
let currentQuery = '';
let isProcessing = false;
let progressInterval = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 USA Spending Analyzer initialized');
    
    // Initialize form handlers
    initializeFormHandlers();
    
    // Initialize tooltips if Bootstrap is available
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
    
    // Check for existing results on page load
    checkExistingResults();
});

// Initialize form handlers
function initializeFormHandlers() {
    const queryForm = document.getElementById('queryForm');
    if (queryForm) {
        queryForm.addEventListener('submit', handleQuerySubmit);
    }
    
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        // Add Enter key handler (Ctrl+Enter to submit)
        promptInput.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                handleQuerySubmit(e);
            }
        });
        
        // Auto-resize textarea
        promptInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
    }
}

// Handle form submission
async function handleQuerySubmit(e) {
    e.preventDefault();
    
    if (isProcessing) {
        showAlert('Please wait for the current query to complete', 'warning');
        return;
    }
    
    const promptInput = document.getElementById('promptInput');
    const prompt = promptInput.value.trim();
    
    if (!prompt) {
        showAlert('Please enter a query about government spending', 'warning');
        promptInput.focus();
        return;
    }
    
    currentQuery = prompt;
    isProcessing = true;
    
    try {
        // Show loading state
        showProcessingState();
        
        // Start progress simulation
        startProgressSimulation();
        
        // Submit query
        const response = await fetch('/process_query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ prompt: prompt })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            showSuccess(data);
        } else {
            throw new Error(data.error || 'Unknown error occurred');
        }
        
    } catch (error) {
        console.error('❌ Query processing error:', error);
        showError(error.message);
    } finally {
        isProcessing = false;
        stopProgressSimulation();
        hideProcessingState();
    }
}

// Show processing state
function showProcessingState() {
    const statusCard = document.getElementById('statusCard');
    const analyzeBtn = document.getElementById('analyzeBtn');
    const resultsCard = document.getElementById('resultsCard');
    
    if (statusCard) {
        statusCard.style.display = 'block';
        statusCard.classList.add('fade-in');
    }
    
    if (analyzeBtn) {
        analyzeBtn.disabled = true;
        analyzeBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Processing...';
    }
    
    if (resultsCard) {
        resultsCard.style.display = 'none';
    }
    
    updateStatus('Processing Query...', 'Analyzing your request and extracting relevant parameters...');
}

// Hide processing state
function hideProcessingState() {
    const statusCard = document.getElementById('statusCard');
    const analyzeBtn = document.getElementById('analyzeBtn');
    
    if (statusCard) {
        setTimeout(() => {
            statusCard.style.display = 'none';
        }, 1000);
    }
    
    if (analyzeBtn) {
        analyzeBtn.disabled = false;
        analyzeBtn.innerHTML = '<i class="fas fa-chart-line me-1"></i>Analyze';
    }
}

// Update status message
function updateStatus(title, message) {
    const statusTitle = document.getElementById('statusTitle');
    const statusMessage = document.getElementById('statusMessage');
    
    if (statusTitle) statusTitle.textContent = title;
    if (statusMessage) statusMessage.textContent = message;
}

// Start progress simulation
function startProgressSimulation() {
    let progress = 0;
    const progressBar = document.getElementById('progressBar');
    
    const stages = [
        { progress: 20, message: 'Analyzing query parameters...' },
        { progress: 40, message: 'Searching recipient database...' },
        { progress: 60, message: 'Fetching spending data from APIs...' },
        { progress: 80, message: 'Processing results with standardized calculations...' },
        { progress: 95, message: 'Finalizing financial analysis...' }
    ];
    
    let stageIndex = 0;
    
    progressInterval = setInterval(() => {
        if (stageIndex < stages.length) {
            const stage = stages[stageIndex];
            progress = stage.progress;
            
            if (progressBar) {
                progressBar.style.width = progress + '%';
            }
            
            updateStatus('Processing Query...', stage.message);
            stageIndex++;
        }
    }, 2000);
}

// Stop progress simulation
function stopProgressSimulation() {
    if (progressInterval) {
        clearInterval(progressInterval);
        progressInterval = null;
    }
    
    const progressBar = document.getElementById('progressBar');
    if (progressBar) {
        progressBar.style.width = '100%';
    }
}

// FIXED: Show success results with STANDARDIZED financial calculations
function showSuccess(data) {
    const resultsCard = document.getElementById('resultsCard');
    const resultsContent = document.getElementById('resultsContent');
    
    if (!resultsCard || !resultsContent) return;
    
    // FIXED: Use standardized financial data from backend
    const financial_summary = data.financial_summary || {};
    const awards_count = data.awards_count || data.total_awards_count || 0;
    const total_results_count = data.results_count || 0;
    
    // Create results HTML
    let resultsHtml = `
        <div class="alert alert-success">
            <i class="fas fa-check-circle me-2"></i>
            <strong>Analysis Complete!</strong> Successfully processed your query and found ${awards_count} awards.
        `;
    
    // Show additional info if total results differ from awards count
    if (total_results_count > awards_count) {
        resultsHtml += ` (${total_results_count} total records including transactions and summaries)`;
    }
    
    resultsHtml += `
        </div>
    `;
    
    if (data.query_details) {
        resultsHtml += `
            <div class="mb-4">
                <h6 class="text-muted">Query Analysis:</h6>
                <div class="row g-3">
        `;
        
        if (data.query_details.recipients && data.query_details.recipients.length > 0) {
            resultsHtml += `
                <div class="col-md-6">
                    <div class="card bg-primary text-white">
                        <div class="card-body py-2">
                            <h6 class="card-title mb-1">Recipients</h6>
                            <small>${data.query_details.recipients.join(', ')}</small>
                        </div>
                    </div>
                </div>
            `;
        }
        
        if (data.query_details.agency_name && data.query_details.agency_name.length > 0) {
            resultsHtml += `
                <div class="col-md-6">
                    <div class="card bg-info text-white">
                        <div class="card-body py-2">
                            <h6 class="card-title mb-1">Agencies</h6>
                            <small>${data.query_details.agency_name.join(', ')}</small>
                        </div>
                    </div>
                </div>
            `;
        }
        
        if (data.query_details.state && data.query_details.state.length > 0) {
            resultsHtml += `
                <div class="col-md-6">
                    <div class="card bg-success text-white">
                        <div class="card-body py-2">
                            <h6 class="card-title mb-1">States</h6>
                            <small>${data.query_details.state.join(', ')}</small>
                        </div>
                    </div>
                </div>
            `;
        }
        
        if (data.query_details.year && data.query_details.year.length > 0) {
            resultsHtml += `
                <div class="col-md-6">
                    <div class="card bg-warning text-dark">
                        <div class="card-body py-2">
                            <h6 class="card-title mb-1">Years</h6>
                            <small>${data.query_details.year.join(', ')}</small>
                        </div>
                    </div>
                </div>
            `;
        }
        
        resultsHtml += `
                </div>
            </div>
        `;
    }
    
    // FIXED: Display standardized financial summary
    if (financial_summary && Object.keys(financial_summary).length > 0) {
        // Use standardized field names from backend
        const total_awarded = financial_summary.total_amount_awarded || 0;
        const total_spent = financial_summary.total_amount_spent || 0;
        const remaining_amount = financial_summary.remaining_amount || 0;
        const spending_percentage = financial_summary.spending_percentage || 0;
        const efficiency_ratio = financial_summary.efficiency_ratio || 0;
        
        resultsHtml += `
            <div class="mb-4">
                <h6 class="text-muted">Financial Summary (Standardized Calculations):</h6>
                <div class="row g-3">
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="h3 text-primary">${formatCurrency(total_awarded)}</div>
                            <small class="text-muted">Total Awarded</small>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="h3 text-success">${formatCurrency(total_spent)}</div>
                            <small class="text-muted">Amount Spent</small>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="h3 text-warning">${formatCurrency(remaining_amount)}</div>
                            <small class="text-muted">Remaining</small>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="h3 text-info">${awards_count}</div>
                            <small class="text-muted">Awards Found</small>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // FIXED: Enhanced financial metrics display with standardized calculations
        resultsHtml += `
            <div class="mb-4">
                <h6 class="text-muted">Spending Efficiency (Standardized Method):</h6>
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="h4 text-primary">${spending_percentage.toFixed(1)}%</div>
                            <small class="text-muted">Average Spending Rate</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="h4 text-success">${efficiency_ratio.toFixed(1)}%</div>
                            <small class="text-muted">Efficiency Ratio</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="text-center">
                            <div class="h4 text-info">${awards_count}</div>
                            <small class="text-muted">Awards Analyzed</small>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // FIXED: Add calculation methodology note
        resultsHtml += `
            <div class="mb-4">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Calculation Method:</strong> All financial metrics use standardized calculations:
                    <ul class="mb-0 mt-2">
                        <li><strong>Award Amount:</strong> Total amount awarded/obligated</li>
                        <li><strong>Amount Spent:</strong> Total outlays/disbursements (from USA Spending API)</li>
                        <li><strong>Remaining Amount:</strong> Award Amount - Amount Spent</li>
                        <li><strong>Spending Rate:</strong> (Amount Spent ÷ Award Amount) × 100</li>
                        <li><strong>Efficiency Ratio:</strong> (Remaining Amount ÷ Award Amount) × 100</li>
                    </ul>
                    <small class="text-muted">These calculations match the Excel export and JSON data.</small>
                </div>
            </div>
        `;
        
        // FIXED: Display top recipients with standardized calculations
        if (data.structured_results && data.structured_results.summary && data.structured_results.summary.top_recipients) {
            const top_recipients = data.structured_results.summary.top_recipients.slice(0, 5);
            
            if (top_recipients.length > 0) {
                resultsHtml += `
                    <div class="mb-4">
                        <h6 class="text-muted">Top Recipients (by Award Amount):</h6>
                        <div class="list-group">
                `;
                
                top_recipients.forEach(recipient => {
                    const name = recipient.name || 'Unknown';
                    const amount = recipient.amount || 0;
                    const type = recipient.type || 'Unknown';
                    
                    resultsHtml += `
                        <div class="list-group-item">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">${name}</h6>
                                    <small class="text-muted">Type: ${type}</small>
                                </div>
                                <span class="badge bg-success">${formatCurrency(amount)}</span>
                            </div>
                        </div>
                    `;
                });
                
                resultsHtml += `
                        </div>
                    </div>
                `;
            }
        }
    }
    
    resultsHtml += `
        <div class="text-center">
            <p class="text-muted">Data has been processed and saved with standardized financial calculations. Use the buttons above to view detailed results or export to Excel.</p>
    `;
    
    // Add year filtering info if applicable
    if (data.query_details && data.query_details.year && data.query_details.year.length > 0) {
        resultsHtml += `
            <p class="text-info"><i class="fas fa-filter me-1"></i>Results filtered by years: ${data.query_details.year.join(', ')}</p>
        `;
    }
    
    // FIXED: Add data consistency note
    resultsHtml += `
            <div class="alert alert-success mt-3">
                <i class="fas fa-check-circle me-2"></i>
                <strong>Data Consistency:</strong> All financial calculations shown here match the exported Excel file and JSON data.
            </div>
        </div>
    `;
    
    resultsContent.innerHTML = resultsHtml;
    resultsCard.style.display = 'block';
    resultsCard.classList.add('slide-up');
    
    // FIXED: Show success message with standardized calculations
    showAlert(`Query processed successfully! Found ${awards_count} awards with standardized financial calculations. ${data.message || ''}`, 'success');
    
    // Scroll to results
    resultsCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Show error message
function showError(message) {
    showAlert(`Error: ${message}`, 'danger');
    
    const resultsCard = document.getElementById('resultsCard');
    if (resultsCard) {
        resultsCard.style.display = 'none';
    }
}

// Show alert message
function showAlert(message, type = 'info') {
    // Remove existing alerts
    const existingAlerts = document.querySelectorAll('.alert-dismissible');
    existingAlerts.forEach(alert => alert.remove());
    
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            <i class="fas fa-${getAlertIcon(type)} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Insert alert at the top of the main container
    const container = document.querySelector('.container-fluid .row');
    if (container) {
        container.insertAdjacentHTML('afterbegin', `<div class="col-12">${alertHtml}</div>`);
    }
    
    // Auto-remove after 10 seconds for success/info messages
    if (type === 'success' || type === 'info') {
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert-dismissible');
            alerts.forEach(alert => {
                if (alert.classList.contains(`alert-${type}`)) {
                    alert.remove();
                }
            });
        }, 10000);
    }
}

// Get icon for alert type
function getAlertIcon(type) {
    const icons = {
        'success': 'check-circle',
        'danger': 'exclamation-triangle',
        'warning': 'exclamation-circle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Clear form
function clearForm() {
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        promptInput.value = '';
        promptInput.style.height = 'auto';
        promptInput.focus();
    }
    
    const resultsCard = document.getElementById('resultsCard');
    if (resultsCard) {
        resultsCard.style.display = 'none';
    }
    
    currentQuery = '';
}

// Set example query
function setExampleQuery(query) {
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        promptInput.value = query;
        promptInput.style.height = 'auto';
        promptInput.style.height = (promptInput.scrollHeight) + 'px';
        promptInput.focus();
    }
}

// Fetch recipient data
async function fetchRecipientData() {
    try {
        showAlert('Updating recipient database... This may take a few minutes.', 'info');
        
        const response = await fetch('/fetch_recipient_data');
        const data = await response.json();
        
        if (response.ok && data.success) {
            showAlert(`Successfully updated recipient database with ${data.count} recipients.`, 'success');
        } else {
            throw new Error(data.error || 'Failed to update recipient database');
        }
        
    } catch (error) {
        console.error('❌ Error fetching recipient data:', error);
        showAlert(`Error updating recipient database: ${error.message}`, 'danger');
    }
}

// Check for existing results
function checkExistingResults() {
    // This could be expanded to check if there are existing results
    // and show a notification or summary
    console.log('🔍 Checking for existing results...');
}

// FIXED: Utility function to format currency with proper handling
function formatCurrency(amount) {
    if (typeof amount !== 'number' || isNaN(amount)) return '$0.00';
    
    // Handle very large numbers
    if (amount >= 1e12) {
        return '$' + (amount / 1e12).toFixed(1) + 'T';
    } else if (amount >= 1e9) {
        return '$' + (amount / 1e9).toFixed(1) + 'B';
    } else if (amount >= 1e6) {
        return '$' + (amount / 1e6).toFixed(1) + 'M';
    } else if (amount >= 1e3) {
        return '$' + (amount / 1e3).toFixed(1) + 'K';
    } else {
        return '$' + amount.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }
}

// FIXED: Utility function to format large numbers
function formatNumber(num) {
    if (typeof num !== 'number' || isNaN(num)) return '0';
    
    if (num >= 1e9) {
        return (num / 1e9).toFixed(1) + 'B';
    } else if (num >= 1e6) {
        return (num / 1e6).toFixed(1) + 'M';
    } else if (num >= 1e3) {
        return (num / 1e3).toFixed(1) + 'K';
    } else {
        return num.toLocaleString();
    }
}

// FIXED: Utility function to format percentage
function formatPercentage(percentage) {
    if (typeof percentage !== 'number' || isNaN(percentage)) return '0.0%';
    return percentage.toFixed(1) + '%';
}

// Debounce function for search
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// FIXED: Export functions for use in other scripts with enhanced formatting
window.USASpendingAnalyzer = {
    clearForm,
    setExampleQuery,
    fetchRecipientData,
    showAlert,
    formatCurrency,
    formatNumber,
    formatPercentage
};

// Handle page unload
window.addEventListener('beforeunload', function(e) {
    if (isProcessing) {
        e.preventDefault();
        e.returnValue = 'A query is currently being processed. Are you sure you want to leave?';
    }
});

console.log('✅ USA Spending Analyzer JavaScript loaded successfully with standardized financial calculations');