"""
ENHANCED: Enhanced query extraction with CONSISTENT fiscal year support
FIXED: Better validation to catch typos like "blckfeet" instead of "blackfeet" but allow searches to proceed
FISCAL YEAR FOCUS: All year references are treated as fiscal years by default
FIXED: Better award type extraction to properly distinguish between contracts, grants, and loans
FIXED: "from YYYY" patterns now create ranges from YYYY to current year
"""

import re
import json
import logging
from difflib import get_close_matches
from typing import Dict, List, Any

class EnhancedQueryExtractor:
    def __init__(self):
        self.known_recipients = self._load_known_recipients()
        self.known_agencies = self._load_known_agencies()
        self.known_states = self._load_known_states()
        # Add stop words to prevent incorrect entity extraction
        self.stop_words = {
            'contracts', 'contract', 'grants', 'grant', 'awards', 'award', 'spending',
            'data', 'information', 'details', 'show', 'get', 'find', 'fetch', 'tell',
            'give', 'me', 'the', 'of', 'for', 'in', 'on', 'at', 'to', 'from', 'with',
            'by', 'about', 'all', 'any', 'some', 'this', 'that', 'these', 'those'
        }
        # Create lowercase versions of known entities for matching
        self.known_recipients_lower = [r.lower() for r in self.known_recipients]
        self.known_agencies_lower = [a.lower() for a in self.known_agencies]
        self.known_states_lower = [s.lower() for s in self.known_states]
    
    def _load_known_recipients(self) -> List[str]:
        """Load known recipients from all_recipients.json if available"""
        try:
            with open('all_recipients.json', 'r') as f:
                data = json.load(f)
                return [item.get('name', '') for item in data if item.get('name')]
        except:
            return [
                'LOCKHEED MARTIN CORP', 'BOEING COMPANY', 'RAYTHEON COMPANY',
                'GENERAL DYNAMICS', 'NORTHROP GRUMMAN', 'MICROSOFT CORP',
                'AMAZON.COM INC', 'APPLE INC', 'GOOGLE LLC', 'NYS DEPARTMENT OF HEALTH',
                'DEPARTMENT OF HEALTH AND HUMAN SERVICES', 'UNIVERSITY OF CALIFORNIA',
                'BLACKFEET HOUSING', 'BLACKFEET HOUSING AUTHORITY',
                'NAMBE PUEBLO HOUSING ENTITY', 'NAMBE PUEBLO HOUSING',
                'NAVAJO TECHNICAL UNIVERSITY', 'NAVAJO TECHNICAL COLLEGE',
                'NAVAJO NATION', 'TRIBAL COLLEGE'
            ]
    
    def _load_known_agencies(self) -> List[str]:
        """Load known federal agencies"""
        return [
            'DEPARTMENT OF DEFENSE', 'DEPARTMENT OF HEALTH AND HUMAN SERVICES',
            'DEPARTMENT OF ENERGY', 'DEPARTMENT OF HOMELAND SECURITY',
            'DEPARTMENT OF VETERANS AFFAIRS', 'DEPARTMENT OF AGRICULTURE',
            'DEPARTMENT OF TRANSPORTATION', 'DEPARTMENT OF EDUCATION',
            'DEPARTMENT OF JUSTICE', 'DEPARTMENT OF STATE',
            'NASA', 'NSF', 'NIH', 'EPA', 'FDA', 'CDC', 'USDA',
            'NYS DEPARTMENT OF HEALTH', 'NEW YORK STATE DEPARTMENT OF HEALTH'
        ]
    
    def _load_known_states(self) -> List[str]:
        """Load known US states"""
        return [
            'ALABAMA', 'ALASKA', 'ARIZONA', 'ARKANSAS', 'CALIFORNIA',
            'COLORADO', 'CONNECTICUT', 'DELAWARE', 'FLORIDA', 'GEORGIA',
            'HAWAII', 'IDAHO', 'ILLINOIS', 'INDIANA', 'IOWA', 'KANSAS',
            'KENTUCKY', 'LOUISIANA', 'MAINE', 'MARYLAND', 'MASSACHUSETTS',
            'MICHIGAN', 'MINNESOTA', 'MISSISSIPPI', 'MISSOURI', 'MONTANA',
            'NEBRASKA', 'NEVADA', 'NEW HAMPSHIRE', 'NEW JERSEY', 'NEW MEXICO',
            'NEW YORK', 'NORTH CAROLINA', 'NORTH DAKOTA', 'OHIO', 'OKLAHOMA',
            'OREGON', 'PENNSYLVANIA', 'RHODE ISLAND', 'SOUTH CAROLINA',
            'SOUTH DAKOTA', 'TENNESSEE', 'TEXAS', 'UTAH', 'VERMONT',
            'VIRGINIA', 'WASHINGTON', 'WEST VIRGINIA', 'WISCONSIN', 'WYOMING'
        ]
    
    def extract_query_details(self, prompt: str) -> Dict[str, Any]:
        """
        ENHANCED: Extract structured information with CONSISTENT FISCAL YEAR validation and IMPROVED award type extraction
        FIXED: "from YYYY" patterns now create ranges from YYYY to current year
        """
        logging.info(f"🔍 Extracting query details with FISCAL YEAR support and IMPROVED award type extraction from: {prompt}")
        
        # Initialize default result with fiscal year defaults
        result = {
            "action": "fetch_awards",
            "year": ["2020", "2021", "2022", "2023", "2024", "2025"],
            "year_type": "fiscal",  # ALWAYS fiscal year
            "award_types": ["all"],  # FIXED: Default to all, will be overridden by extraction
            "recipients": [],
            "agency_name": [],
            "state": [],
            "validation_errors": [],
            "validation_warnings": [],
            "fiscal_year_note": "All years are interpreted as US Federal Fiscal Years (October 1 - September 30)"
        }
        
        # Keep original prompt for case preservation
        prompt_original = prompt
        prompt_clean = self._clean_prompt(prompt)
        prompt_lower = prompt_clean.lower()
        
        # ENHANCED: Extract fiscal years with CORRECTED range handling and FIXED "from YYYY" support
        years = self._extract_years_enhanced_fiscal_focus(prompt_clean)
        if years:
            result["year"] = years
            result["year_type"] = "fiscal"  # ALWAYS fiscal year
            logging.info(f"🗓️ Extracted FISCAL years: {years}")
            
            # Add detailed fiscal year explanation
            fiscal_explanations = []
            for fy in years:
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    fiscal_explanations.append(f"FY{fy}: {start_date} to {end_date}")
                except:
                    fiscal_explanations.append(f"FY{fy}")
            
            result["fiscal_year_explanation"] = fiscal_explanations
            logging.info(f"📅 FISCAL year date ranges: {fiscal_explanations}")
        else:
            logging.info(f"🗓️ No specific fiscal years found, using default range: {result['year']}")
            result["year_type"] = "fiscal"  # ALWAYS fiscal year
            result["fiscal_year_explanation"] = ["Using default fiscal year range: FY2020-FY2025"]
        
        # FIXED: Extract award types with IMPROVED context awareness and specific matching
        award_types = self._extract_award_types_enhanced(prompt_lower, prompt_original)
        if award_types:
            result["award_types"] = award_types
            logging.info(f"🎯 Extracted AWARD TYPES: {award_types}")
        else:
            logging.info(f"🎯 No specific award types found, using default: {result['award_types']}")
        
        # Extract entities with enhanced logic
        entities = self._extract_entities_enhanced_fixed(prompt_original, prompt_clean, prompt_lower)
        
        result["recipients"] = entities.get("recipients", [])
        result["agency_name"] = entities.get("agencies", [])
        result["state"] = entities.get("states", [])
        
        # FIXED: LENIENT validation of recipients with better error detection
        validation_errors, validation_warnings = self._lenient_validate_recipients(result["recipients"])
        result["validation_errors"] = validation_errors
        result["validation_warnings"] = validation_warnings
        
        # Log extraction results for debugging
        logging.info(f"🎯 Extracted entities: {entities}")
        logging.info(f"🎯 Final award types: {result['award_types']}")
        if validation_errors:
            logging.warning(f"❌ LENIENT Validation errors: {validation_errors}")
        if validation_warnings:
            logging.warning(f"⚠️ Validation warnings: {validation_warnings}")
        
        # Save to output.json with fiscal year information
        with open("output.json", "w") as f:
            json.dump(result, f, indent=4)
        
        logging.info(f"✅ Query analysis completed with FISCAL YEAR support and IMPROVED award type extraction: {result}")
        return result
    
    def _lenient_validate_recipients(self, recipients: List[str]) -> tuple[List[str], List[str]]:
        """FIXED: More lenient validation that allows searches with warnings instead of blocking errors"""
        validation_errors = []
        validation_warnings = []
        
        for recipient in recipients:
            if not self._is_valid_recipient_lenient(recipient):
                # FIXED: Find close matches with suggestions
                suggestions = self.get_enhanced_suggestions(recipient)
                
                if suggestions:
                    # If we have close suggestions, make it a WARNING instead of ERROR
                    warning_msg = f"'{recipient}' not found in pre-loaded database. Closest matches: {', '.join(suggestions[:3])}. Will search anyway."
                    validation_warnings.append(warning_msg)
                    logging.warning(f"⚠️ LENIENT: Recipient '{recipient}' not in database but proceeding with search - suggestions: {suggestions[:3]}")
                else:
                    # If no suggestions found, still make it a WARNING and allow search
                    warning_msg = f"'{recipient}' not found in pre-loaded database. Will search federal spending records anyway."
                    validation_warnings.append(warning_msg)
                    logging.warning(f"⚠️ LENIENT: Recipient '{recipient}' not in database but proceeding with search - no suggestions found")
            else:
                logging.info(f"✅ LENIENT: Valid recipient '{recipient}'")
        
        # FIXED: Return empty errors list to allow searches to proceed
        return validation_errors, validation_warnings

    def _is_valid_recipient_lenient(self, recipient_name: str) -> bool:
        """FIXED: More lenient recipient validation - only reject obvious invalid formats"""
        if not recipient_name or len(recipient_name.strip()) < 2:
            return False
        
        recipient_upper = recipient_name.upper().strip()
        recipient_lower = recipient_name.lower().strip()
        
        # FIXED: Check for obviously invalid patterns only
        invalid_patterns = [
            r'^[^a-zA-Z]*$',  # No letters at all
            r'^.{1}$',        # Only 1 character
            r'^[0-9]+$',      # Only numbers
        ]
        
        for pattern in invalid_patterns:
            if re.match(pattern, recipient_name.strip()):
                logging.warning(f"❌ LENIENT: Obviously invalid recipient name: '{recipient_name}'")
                return False
        
        # FIXED: If it passes basic validation, check database but don't reject if not found
        # First check for EXACT matches (case-insensitive)
        for known_recipient in self.known_recipients:
            if recipient_upper == known_recipient.upper():
                return True
        
        # Check for very close matches
        close_matches = get_close_matches(recipient_upper, self.known_recipients, n=1, cutoff=0.9)
        if close_matches:
            match = close_matches[0]
            similarity = self._calculate_similarity(recipient_upper, match.upper())
            if similarity >= 0.9:
                logging.info(f"✅ LENIENT: Very close match found for '{recipient_name}' -> '{match}' (similarity: {similarity:.2f})")
                return True
        
        # FIXED: If not in database but looks like a valid entity name, allow it anyway
        if self._looks_like_valid_entity(recipient_name):
            logging.info(f"✅ LENIENT: '{recipient_name}' looks like a valid entity, allowing search even though not in pre-loaded database")
            return False  # Return False to trigger warning but still allow search
        
        logging.info(f"ℹ️ LENIENT: '{recipient_name}' not found in database but will proceed with search")
        return False  # Return False to trigger warning but still allow search

    def _looks_like_valid_entity(self, name: str) -> bool:
        """ENHANCED: Check if name looks like a valid organization/entity"""
        if not name or len(name.strip()) < 3:
            return False
        
        # Valid entity indicators - EXPANDED list
        entity_indicators = [
            # Corporate indicators
            'corp', 'corporation', 'company', 'inc', 'llc', 'ltd', 'group',
            'systems', 'technologies', 'solutions', 'industries', 'international',
            'global', 'national', 'enterprises', 'holdings', 'services',
            
            # Educational indicators
            'university', 'college', 'school', 'institute', 'technical', 'community',
            'academy', 'education', 'educational', 'learning', 'campus',
            
            # Government/institutional indicators
            'department', 'ministry', 'agency', 'bureau', 'service', 'commission',
            'authority', 'foundation', 'center', 'centre', 'association', 'council',
            'board', 'office', 'administration', 'division',
            
            # Tribal/indigenous indicators (IMPORTANT for this use case)
            'housing', 'tribal', 'nation', 'pueblo', 'band', 'tribe', 'reservation',
            'indian', 'indians', 'native', 'indigenous', 'first', 'nations',
            'navajo', 'apache', 'cherokee', 'sioux', 'choctaw', 'blackfeet',
            
            # Healthcare indicators
            'hospital', 'medical', 'health', 'healthcare', 'clinic', 'care',
            
            # Geographic indicators
            'state', 'county', 'city', 'municipal', 'regional', 'district',
            
            # Professional service indicators
            'consulting', 'engineering', 'research', 'development', 'construction'
        ]
        
        name_lower = name.lower()
        
        # Check if name contains any valid entity indicators
        for indicator in entity_indicators:
            if indicator in name_lower:
                return True
        
        # Check if it looks like a proper name (multiple capitalized words)
        words = name.split()
        if len(words) >= 2:
            capitalized_count = sum(1 for word in words if word and word[0].isupper())
            if capitalized_count >= 2:
                return True
        
        # Check for common academic patterns
        academic_patterns = [
            r'\b\w+\s+(university|college|institute|technical|school)\b',
            r'\b(university|college|institute|technical|school)\s+\w+\b',
        ]
        
        for pattern in academic_patterns:
            if re.search(pattern, name_lower):
                return True
        
        return False
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """Calculate similarity ratio between two strings"""
        try:
            from difflib import SequenceMatcher
            return SequenceMatcher(None, str1, str2).ratio()
        except:
            # Fallback: simple character overlap
            set1 = set(str1.lower())
            set2 = set(str2.lower())
            intersection = len(set1 & set2)
            union = len(set1 | set2)
            return intersection / union if union > 0 else 0
    
    def get_enhanced_suggestions(self, recipient_name: str) -> List[str]:
        """FIXED: Get enhanced suggestions with better matching"""
        try:
            suggestions = []
            
            # FIXED: Get close matches with multiple cutoff levels
            cutoffs = [0.8, 0.7, 0.6]
            
            for cutoff in cutoffs:
                close_matches = get_close_matches(recipient_name.upper(), self.known_recipients, n=5, cutoff=cutoff)
                if close_matches:
                    suggestions.extend(close_matches)
                    break  # Use the strictest cutoff that yields results
            
            # FIXED: Look for partial matches with word overlap
            if not suggestions:
                for known_recipient in self.known_recipients:
                    if self._has_significant_word_overlap(recipient_name.upper(), known_recipient.upper()):
                        if known_recipient not in suggestions:
                            suggestions.append(known_recipient)
                            if len(suggestions) >= 5:
                                break
            
            # FIXED: Special handling for common typos
            suggestions.extend(self._check_common_typos(recipient_name))
            
            # Remove duplicates and return top 5
            unique_suggestions = []
            seen = set()
            for suggestion in suggestions:
                if suggestion.upper() not in seen:
                    seen.add(suggestion.upper())
                    unique_suggestions.append(suggestion)
                    if len(unique_suggestions) >= 5:
                        break
            
            return unique_suggestions
            
        except Exception as e:
            logging.error(f"❌ Error getting enhanced suggestions: {e}")
            return []
    
    def _has_significant_word_overlap(self, name1: str, name2: str) -> bool:
        """Check if two names have significant word overlap"""
        words1 = set(name1.split())
        words2 = set(name2.split())
        
        # Remove common words
        common_words = {'THE', 'OF', 'AND', 'FOR', 'IN', 'ON', 'AT', 'TO', 'A', 'AN'}
        words1 -= common_words
        words2 -= common_words
        
        if not words1 or not words2:
            return False
        
        overlap = len(words1 & words2)
        min_words = min(len(words1), len(words2))
        
        return overlap >= max(1, min_words * 0.5)
    
    def _check_common_typos(self, name: str) -> List[str]:
        """FIXED: Check for common typos and return corrections"""
        corrections = []
        name_lower = name.lower()
        
        # Common typos mapping
        typo_corrections = {
            'blckfeet': 'BLACKFEET HOUSING',
            'blakfeet': 'BLACKFEET HOUSING',
            'blackeet': 'BLACKFEET HOUSING',
            'navjo': 'NAVAJO TECHNICAL UNIVERSITY',
            'nvajo': 'NAVAJO TECHNICAL UNIVERSITY',
            'lockheed': 'LOCKHEED MARTIN CORP',
            'boing': 'BOEING COMPANY',
            'amazom': 'AMAZON.COM INC',
            'googl': 'GOOGLE LLC'
        }
        
        # Check for direct typo matches
        for typo, correction in typo_corrections.items():
            if typo in name_lower:
                corrections.append(correction)
        
        # Check for character transpositions and missing letters
        for known_recipient in self.known_recipients:
            if self._is_likely_typo(name_lower, known_recipient.lower()):
                corrections.append(known_recipient)
        
        return corrections[:3]  # Return top 3 corrections
    
    def _is_likely_typo(self, typo: str, correct: str) -> bool:
        """Check if typo is likely a typo of correct word"""
        if abs(len(typo) - len(correct)) > 2:
            return False
        
        # Count character differences
        differences = 0
        for i, char in enumerate(min(typo, correct, key=len)):
            if i < len(max(typo, correct, key=len)):
                if typo[i] != correct[i] if i < len(typo) else True:
                    differences += 1
        
        # Allow 1-2 character differences for short strings, more for longer ones
        max_differences = max(1, len(correct) // 4)
        return differences <= max_differences
    
    def _clean_prompt(self, prompt: str) -> str:
        """Clean and normalize the prompt"""
        # Remove extra whitespace
        prompt = re.sub(r'\s+', ' ', prompt.strip())
        
        # Don't remove action words here - we need them for context
        return prompt.strip()
    
    def _extract_years_enhanced_fiscal_focus(self, prompt: str) -> List[str]:
        """ENHANCED: Extract fiscal years from prompt with CONSISTENT fiscal year interpretation and FIXED "from YYYY" support"""
        years = []
        
        logging.info(f"🔍 FISCAL FOCUS: Extracting FISCAL years from: {prompt}")
        
        # FIXED: Get current year for "from YYYY" patterns
        current_year = 2025
        
        # ENHANCED: Pattern for year ranges - handle various formats (ALL INTERPRETED AS FISCAL YEARS)
        range_patterns = [
            # "from 2015 to 2024" -> FY2015 to FY2024
            r'\bfrom\s+(20\d{2})\s+to\s+(20\d{2})\b',
            # "2015 to 2024" -> FY2015 to FY2024
            r'\b(20\d{2})\s+to\s+(20\d{2})\b',
            # "2015-2024" -> FY2015 to FY2024
            r'\b(20\d{2})\s*[-–]\s*(20\d{2})\b',
            # "between 2015 and 2024" -> FY2015 to FY2024
            r'\bbetween\s+(20\d{2})\s+and\s+(20\d{2})\b',
            # "2015 through 2024" -> FY2015 to FY2024
            r'\b(20\d{2})\s+through\s+(20\d{2})\b',
            # "2015 until 2024" -> FY2015 to FY2024
            r'\b(20\d{2})\s+until\s+(20\d{2})\b'
        ]
        
        range_found = False
        for pattern in range_patterns:
            matches = re.findall(pattern, prompt, re.IGNORECASE)
            for start_year, end_year in matches:
                start = int(start_year)
                end = int(end_year)
                
                # ENHANCED: Generate all fiscal years in the range
                range_years = [str(year) for year in range(start, end + 1)]
                years.extend(range_years)
                range_found = True
                logging.info(f"🗓️ FISCAL: Fiscal year range FY{start_year}-FY{end_year} found, expanded to: {range_years}")
        
        # FIXED: Handle "from YYYY" patterns (without "to") - these should create ranges to current year
        if not range_found:
            from_year_patterns = [
                r'\bfrom\s+(20\d{2})(?!\s+(?:to|through|until))\b',  # "from 2008" but not "from 2008 to"
                r'\bsince\s+(20\d{2})\b',  # "since 2008"
                r'\bstarting\s+(?:from\s+)?(20\d{2})\b',  # "starting 2008" or "starting from 2008"
                r'\bbeginning\s+(?:in\s+)?(20\d{2})\b',  # "beginning 2008" or "beginning in 2008"
            ]
            
            for pattern in from_year_patterns:
                matches = re.findall(pattern, prompt, re.IGNORECASE)
                for start_year in matches:
                    start = int(start_year)
                    # Create range from start year to current year
                    range_years = [str(year) for year in range(start, current_year + 1)]
                    years.extend(range_years)
                    range_found = True
                    logging.info(f"🗓️ FISCAL: 'From FY{start_year}' pattern found, expanded to range: FY{start_year}-FY{current_year} = {range_years}")
        
        # Only look for individual years if no range was found
        if not range_found:
            # Pattern 1: Explicit years (2020, 2021, etc.) -> ALL TREATED AS FISCAL YEARS
            year_matches = re.findall(r'\b(20\d{2})\b', prompt)
            years.extend(year_matches)
            logging.info(f"Pattern 1 - Individual fiscal years found: {year_matches}")
            
            # Pattern 2: "in YYYY" pattern -> FISCAL YEAR
            in_year_pattern = r'\bin\s+(20\d{2})\b'
            in_year_matches = re.findall(in_year_pattern, prompt, re.IGNORECASE)
            years.extend(in_year_matches)
            logging.info(f"Pattern 2 - 'in YYYY' fiscal year pattern found: {in_year_matches}")
            
            # Pattern 3: "for YYYY" pattern -> FISCAL YEAR
            for_year_pattern = r'\bfor\s+(20\d{2})\b'
            for_year_matches = re.findall(for_year_pattern, prompt, re.IGNORECASE)
            years.extend(for_year_matches)
            logging.info(f"Pattern 3 - 'for YYYY' fiscal year pattern found: {for_year_matches}")
            
            # Pattern 4: "during YYYY" pattern -> FISCAL YEAR
            during_year_pattern = r'\bduring\s+(20\d{2})\b'
            during_year_matches = re.findall(during_year_pattern, prompt, re.IGNORECASE)
            years.extend(during_year_matches)
            logging.info(f"Pattern 4 - 'during YYYY' fiscal year pattern found: {during_year_matches}")
            
            # Pattern 5: "YYYY contracts/grants" pattern -> FISCAL YEAR
            year_type_pattern = r'\b(20\d{2})\s+(?:contracts?|grants?|awards?)\b'
            year_type_matches = re.findall(year_type_pattern, prompt, re.IGNORECASE)
            years.extend(year_type_matches)
            logging.info(f"Pattern 5 - 'YYYY contracts/grants' fiscal year pattern found: {year_type_matches}")
        
        # Pattern 6: Relative years (last year, past 3 years, etc.) -> FISCAL YEARS
        if re.search(r'\blast\s+year\b', prompt, re.IGNORECASE):
            years.append(str(current_year - 1))
            logging.info(f"Pattern 6 - 'last year' fiscal year found: FY{current_year - 1}")
        elif re.search(r'\bpast\s+(\d+)\s+years?\b', prompt, re.IGNORECASE):
            match = re.search(r'\bpast\s+(\d+)\s+years?\b', prompt, re.IGNORECASE)
            if match:
                num_years = int(match.group(1))
                past_years = [str(current_year - i) for i in range(1, num_years + 1)]
                years.extend(past_years)
                logging.info(f"Pattern 6 - 'past {num_years} years' fiscal years found: {past_years}")
        
        # ENHANCED: Add fiscal year context patterns
        fy_patterns = [
            r'\bfy\s*(20\d{2})\b',  # FY2022, FY 2022
            r'\bfiscal\s+year\s+(20\d{2})\b',  # fiscal year 2022
            r'\b(20\d{2})\s+fiscal\s+year\b',  # 2022 fiscal year
        ]
        
        for pattern in fy_patterns:
            fy_matches = re.findall(pattern, prompt, re.IGNORECASE)
            years.extend(fy_matches)
            if fy_matches:
                logging.info(f"FISCAL CONTEXT: Found explicit fiscal year references: {fy_matches}")
        
        # Remove duplicates and sort
        unique_years = list(set(years))
        unique_years.sort()
        
        # Add fiscal year notation to logging
        if unique_years:
            fiscal_year_ranges = []
            for fy in unique_years:
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    fiscal_year_ranges.append(f"FY{fy} ({start_date} to {end_date})")
                except:
                    fiscal_year_ranges.append(f"FY{fy}")
            logging.info(f"✅ FISCAL FOCUS: Final extracted FISCAL years: {unique_years}")
            logging.info(f"📅 FISCAL year date ranges: {fiscal_year_ranges}")
        
        return unique_years if unique_years else []
    
    def _extract_award_types_enhanced(self, prompt_lower: str, prompt_original: str) -> List[str]:
        """FIXED: Enhanced award type extraction with better context awareness and IMPROVED handling for generic 'awards' terms"""
        award_types = []
        
        logging.info(f"🎯 ENHANCED: Extracting award types from: {prompt_original}")
        
        # FIXED: Check for generic "awards" patterns first - these should return ALL award types
        generic_award_patterns = [
            r'\bshow\s+(all\s+)?awards?\b',  # "show awards" or "show all awards"
            r'\bget\s+(all\s+)?awards?\b',   # "get awards" or "get all awards"
            r'\bfind\s+(all\s+)?awards?\b',  # "find awards" or "find all awards"
            r'\bfetch\s+(all\s+)?awards?\b', # "fetch awards" or "fetch all awards"
            r'\blist\s+(all\s+)?awards?\b',  # "list awards" or "list all awards"
            r'\ball\s+awards?\b',            # "all awards"
            r'\bawards?\s+of\b',             # "awards of"
            r'\bawards?\s+for\b',            # "awards for"
            r'\bawards?\s+data\b'            # "awards data"
        ]
        
        # Check for generic award patterns first
        generic_awards_found = False
        for pattern in generic_award_patterns:
            if re.search(pattern, prompt_lower):
                generic_awards_found = True
                logging.info(f"🎯 GENERIC AWARDS pattern matched: {pattern} - will return ALL award types")
                award_types = ["all"]
                break
        
        # Only proceed with specific type detection if no generic pattern was found
        if not generic_awards_found:
            # FIXED: More specific and comprehensive patterns to avoid false positives
            # Contracts patterns
            contract_patterns = [
                r'\bcontracts?\b',
                r'\bcontract\s+awards?\b',
                r'\bcontracting\b',
                r'\bprocurement\b',
                r'\bcontractual\b',
                r'\bcontracted\b',
                r'\bshow\s+contracts?\b',
                r'\bget\s+contracts?\b',
                r'\bfind\s+contracts?\b',
                r'\bfetch\s+contracts?\b',
                r'\blist\s+contracts?\b'
            ]
            
            # Grants patterns
            grant_patterns = [
                r'\bgrants?\b',
                r'\bgrant\s+awards?\b',
                r'\bgranting\b',
                r'\bfederal\s+grants?\b',
                r'\bgovernment\s+grants?\b',
                r'\bshow\s+grants?\b',
                r'\bget\s+grants?\b',
                r'\bfind\s+grants?\b',
                r'\bfetch\s+grants?\b',
                r'\blist\s+grants?\b'
            ]
            
            # Loans patterns
            loan_patterns = [
                r'\bloans?\b',
                r'\bloan\s+guarantees?\b',
                r'\blending\b',
                r'\bcredit\s+programs?\b',
                r'\bshow\s+loans?\b',
                r'\bget\s+loans?\b',
                r'\bfind\s+loans?\b'
            ]
            
            # FIXED: Check for contracts first (more specific matching)
            contracts_found = False
            for pattern in contract_patterns:
                if re.search(pattern, prompt_lower):
                    contracts_found = True
                    logging.info(f"🎯 CONTRACTS pattern matched: {pattern}")
                    break
            
            # FIXED: Check for grants (more specific matching)
            grants_found = False
            for pattern in grant_patterns:
                if re.search(pattern, prompt_lower):
                    grants_found = True
                    logging.info(f"🎯 GRANTS pattern matched: {pattern}")
                    break
            
            # FIXED: Check for loans (more specific matching)
            loans_found = False
            for pattern in loan_patterns:
                if re.search(pattern, prompt_lower):
                    loans_found = True
                    logging.info(f"🎯 LOANS pattern matched: {pattern}")
                    break
            
            # FIXED: Apply logic to determine award types based on what was found
            if contracts_found and not grants_found and not loans_found:
                award_types.append("contracts")
                logging.info(f"🎯 EXCLUSIVE: Only contracts patterns found")
            elif grants_found and not contracts_found and not loans_found:
                award_types.append("grants")
                logging.info(f"🎯 EXCLUSIVE: Only grants patterns found")
            elif loans_found and not contracts_found and not grants_found:
                award_types.append("loans")
                logging.info(f"🎯 EXCLUSIVE: Only loans patterns found")
            elif contracts_found and grants_found:
                # Both found - include both
                award_types.extend(["contracts", "grants"])
                logging.info(f"🎯 MIXED: Both contracts and grants patterns found")
            elif contracts_found and loans_found:
                # Both found - include both
                award_types.extend(["contracts", "loans"])
                logging.info(f"🎯 MIXED: Both contracts and loans patterns found")
            elif grants_found and loans_found:
                # Both found - include both
                award_types.extend(["grants", "loans"])
                logging.info(f"🎯 MIXED: Both grants and loans patterns found")
            elif contracts_found or grants_found or loans_found:
                # At least one found with others, include all found
                if contracts_found:
                    award_types.append("contracts")
                if grants_found:
                    award_types.append("grants")
                if loans_found:
                    award_types.append("loans")
                logging.info(f"🎯 MULTIPLE: Multiple award type patterns found")
            else:
                # FIXED: Context-based fallback detection
                context_patterns = {
                    "contracts": [
                        r'\b(procurement|contractor|contracting|vendor|supplier)\b',
                        r'\b(defense|military|equipment|services)\s+(spending|awards?|contracts?)\b',
                        r'\b(construction|it|technology|consulting)\s+(contracts?|awards?)\b'
                    ],
                    "grants": [
                        r'\b(research|education|health|science|university|college)\b',
                        r'\b(funding|support|assistance|program)\b',
                        r'\b(non-?profit|foundation|institute|agency)\b'
                    ],
                    "loans": [
                        r'\b(credit|financing|lending|borrowing)\b',
                        r'\b(small\s+business|economic\s+development)\b'
                    ]
                }
                
                for award_type, patterns in context_patterns.items():
                    for pattern in patterns:
                        if re.search(pattern, prompt_lower):
                            award_types.append(award_type)
                            logging.info(f"🎯 CONTEXT: {award_type} detected via context pattern: {pattern}")
                            break
                    if award_types:  # Stop after finding first context match
                        break
        
        # FIXED: Final fallback - if no specific type mentioned, check for generic terms
        if not award_types:
            generic_patterns = [
                r'\b(spending|funding|expenditure|money|funds)\b',
                r'\b(federal|government|public)\s+(spending|money|funds)\b'
            ]
            
            for pattern in generic_patterns:
                if re.search(pattern, prompt_lower):
                    award_types = ["all"]
                    logging.info(f"🎯 GENERIC: Generic spending pattern found, using 'all': {pattern}")
                    break
        
        # Remove duplicates and ensure we have something
        if award_types:
            award_types = list(set(award_types))
        else:
            award_types = ["all"]  # Ultimate fallback
            logging.info(f"🎯 FALLBACK: No award type patterns found, using 'all'")
        
        logging.info(f"🎯 FINAL AWARD TYPES: {award_types}")
        return award_types
    
    def _extract_entities_enhanced_fixed(self, prompt_original: str, prompt: str, prompt_lower: str) -> Dict[str, List[str]]:
        """
        Enhanced entity extraction with proper "and" handling and case preservation
        """
        entities = {
            "recipients": [],
            "agencies": [],
            "states": []
        }
        
        logging.info(f"🔍 Starting entity extraction from: {prompt}")
        
        # Strategy 1 - Handle "X of Y, Z and W" pattern correctly with case preservation
        of_pattern = r'(?:contracts?|grants?|awards?|data|information|details|spending)\s+(?:data\s+)?of\s+(.+?)(?:\s*$|\s+(?:in|during|from|since|between|for)\s+|\s+\d{4}|\s+from\s+\d{4})'
        
        # Search in both original and lowercase versions
        matches = re.findall(of_pattern, prompt_original, re.IGNORECASE)
        
        for match in matches:
            match_clean = match.strip()
            logging.info(f"🎯 Found 'of' pattern match: '{match_clean}'")
            
            if not self._is_stop_word_phrase(match_clean):
                # Smart entity splitting that preserves case
                extracted_entities = self._smart_entity_split(match_clean)
                for entity in extracted_entities:
                    entity_type = self._classify_entity_enhanced(entity, prompt)
                    if entity_type and entity not in entities[entity_type]:
                        entities[entity_type].append(entity)
                        logging.info(f"✅ Added '{entity}' as {entity_type}")
        
        # Strategy 2 - Handle "for X, Y and Z" patterns with case preservation
        for_pattern = r'(?:contracts?|grants?|awards?|data|information|details|spending)\s+for\s+(.+?)(?:\s*$|\s+(?:in|during|from|since|between)\s+|\s+\d{4}|\s+from\s+\d{4})'
        matches = re.findall(for_pattern, prompt_original, re.IGNORECASE)
        for match in matches:
            match_clean = match.strip()
            logging.info(f"🎯 Found 'for' pattern match: '{match_clean}'")
            
            if not self._is_stop_word_phrase(match_clean):
                extracted_entities = self._smart_entity_split(match_clean)
                for entity in extracted_entities:
                    entity_type = self._classify_entity_enhanced(entity, prompt)
                    if entity_type and entity not in entities[entity_type]:
                        entities[entity_type].append(entity)
                        logging.info(f"✅ Added '{entity}' as {entity_type}")
        
        # Strategy 3 - Handle "show X, Y and Z data" patterns with case preservation
        show_pattern = r'show\s+(.+?)\s+(?:data|information|details|contracts?|grants?|awards?|spending)'
        matches = re.findall(show_pattern, prompt_original, re.IGNORECASE)
        for match in matches:
            match_clean = match.strip()
            logging.info(f"🎯 Found 'show' pattern match: '{match_clean}'")
            
            if not self._is_award_type_only(match_clean) and not self._is_stop_word_phrase(match_clean):
                extracted_entities = self._smart_entity_split(match_clean)
                for entity in extracted_entities:
                    entity_type = self._classify_entity_enhanced(entity, prompt)
                    if entity_type and entity not in entities[entity_type]:
                        entities[entity_type].append(entity)
                        logging.info(f"✅ Added '{entity}' as {entity_type}")
        
        # Post-process to handle specific cases
        entities = self._post_process_entities_enhanced(entities, prompt_original)
        
        logging.info(f"🏁 Final extracted entities: {entities}")
        return entities
    
    def _smart_entity_split(self, entity_string: str) -> List[str]:
        """
        Smart entity splitting that properly handles commas and 'and' while preserving case
        """
        entities = []
        
        # Clean the entity string first
        entity_string = entity_string.strip()
        
        # FIXED: Remove trailing words that aren't part of entity names and year references
        stop_words_pattern = r'\s+(data|information|details|contracts?|grants?|awards?|spending|in\s+\d{4}|for\s+\d{4}|during\s+\d{4}|from\s+\d{4}|from\s+\d{4}\s+to\s+\d{4}|from\s+\d{4})'
        entity_string = re.sub(stop_words_pattern, '', entity_string, flags=re.IGNORECASE)
        
        if not entity_string:
            return entities
        
        logging.info(f"🔄 Smart splitting: '{entity_string}'")
        
        # Handle comma and 'and' splitting properly while preserving case
        # First, split by commas to get main segments
        comma_parts = [part.strip() for part in entity_string.split(',')]
        
        for part in comma_parts:
            part = part.strip()
            if not part:
                continue
            
            # Check if this part contains 'and' and should be split further
            # Use case-insensitive regex but preserve original case
            and_pattern = re.compile(r'\s+and\s+', re.IGNORECASE)
            if and_pattern.search(part):
                # Split by 'and' but preserve case
                and_parts = and_pattern.split(part)
                
                for and_part in and_parts:
                    and_part = and_part.strip()
                    if and_part and self._is_substantial_entity(and_part):
                        clean_entity = self._clean_entity_name(and_part)
                        if clean_entity:
                            entities.append(clean_entity)
                            logging.info(f"  ➜ Split from 'and': '{clean_entity}'")
            else:
                # No 'and' in this part, treat as single entity
                if self._is_substantial_entity(part):
                    clean_entity = self._clean_entity_name(part)
                    if clean_entity:
                        entities.append(clean_entity)
                        logging.info(f"  ➜ Single entity: '{clean_entity}'")
        
        logging.info(f"🎯 Smart split result: {entities}")
        return entities
    
    def _is_stop_word_phrase(self, phrase: str) -> bool:
        """Check if phrase consists only of stop words"""
        if not phrase:
            return True
        
        words = phrase.lower().split()
        meaningful_words = [word for word in words if word not in self.stop_words]
        
        # If no meaningful words remain, it's a stop word phrase
        return len(meaningful_words) == 0
    
    def _is_award_type_only(self, phrase: str) -> bool:
        """Check if phrase is only award type words"""
        if not phrase:
            return True
        
        award_type_words = {'contract', 'contracts', 'grant', 'grants', 'award', 'awards', 'loan', 'loans'}
        words = phrase.lower().split()
        
        # If all words are award type words, return True
        return all(word in award_type_words for word in words)
    
    def _is_substantial_entity(self, text: str) -> bool:
        """Check if text is a substantial entity (not just stop words)"""
        if not text or len(text) < 3:
            return False
        
        # Remove stop words and see if anything meaningful remains
        words = text.lower().split()
        meaningful_words = [word for word in words if word not in self.stop_words]
        
        return len(meaningful_words) > 0
    
    def _classify_entity_enhanced(self, entity: str, full_prompt: str) -> str:
        """Enhanced entity classification with better context awareness and case-insensitive matching"""
        entity_upper = entity.upper()
        entity_lower = entity.lower()
        
        logging.info(f"🔍 Classifying entity: {entity}")
        
        # Priority 1: Check against known lists with fuzzy matching (case-insensitive)
        
        # Check recipients first with more lenient matching
        recipient_matches = get_close_matches(entity_upper, self.known_recipients, n=1, cutoff=0.6)
        if recipient_matches:
            logging.info(f"✅ Matched as recipient: {recipient_matches[0]}")
            return "recipients"
        
        # Also try lowercase matching
        recipient_matches_lower = get_close_matches(entity_lower, self.known_recipients_lower, n=1, cutoff=0.6)
        if recipient_matches_lower:
            # Find the original case version
            idx = self.known_recipients_lower.index(recipient_matches_lower[0])
            logging.info(f"✅ Matched as recipient (lowercase): {self.known_recipients[idx]}")
            return "recipients"
        
        # Check for partial matches in recipients
        for known_recipient in self.known_recipients:
            if self._partial_match(entity_upper, known_recipient):
                logging.info(f"✅ Partial match as recipient: {known_recipient}")
                return "recipients"
        
        # Check agencies (case-insensitive)
        agency_matches = get_close_matches(entity_upper, self.known_agencies, n=1, cutoff=0.8)
        if agency_matches:
            logging.info(f"✅ Matched as agency: {agency_matches[0]}")
            return "agencies"
        
        agency_matches_lower = get_close_matches(entity_lower, self.known_agencies_lower, n=1, cutoff=0.8)
        if agency_matches_lower:
            idx = self.known_agencies_lower.index(agency_matches_lower[0])
            logging.info(f"✅ Matched as agency (lowercase): {self.known_agencies[idx]}")
            return "agencies"
        
        # Check states (case-insensitive)
        state_matches = get_close_matches(entity_upper, self.known_states, n=1, cutoff=0.8)
        if state_matches:
            logging.info(f"✅ Matched as state: {state_matches[0]}")
            return "states"
        
        state_matches_lower = get_close_matches(entity_lower, self.known_states_lower, n=1, cutoff=0.8)
        if state_matches_lower:
            idx = self.known_states_lower.index(state_matches_lower[0])
            logging.info(f"✅ Matched as state (lowercase): {self.known_states[idx]}")
            return "states"
        
        # Priority 2: Pattern-based classification with enhanced patterns
        
        # Corporate/recipient patterns (check this first for companies)
        corporate_patterns = [
            r'\b(corp|corporation|company|inc|llc|ltd|group|systems|technologies|solutions|industries|international|global|housing|authority)\b',
            r'\b(lockheed|boeing|raytheon|general dynamics|northrop|microsoft|amazon|apple|google|ibm|oracle|blackfeet|nambe|pueblo|navajo)\b',
            r'\b(band|tribe|tribal|nation|indian|indians|native|indigenous|technical)\b',
            r'\b(university|college|institute|foundation|association|council|consortium)\b',
            r'\b(cahuilla|navajo|cherokee|apache|choctaw|sioux|hopi|zuni|mohawk|seminole)\b'
        ]
        
        for pattern in corporate_patterns:
            if re.search(pattern, entity_lower):
                logging.info(f"✅ Pattern matched as recipient: {pattern}")
                return "recipients"
        
        # Agency patterns
        agency_patterns = [
            r'\b(department|agency|bureau|service|commission|administration|office|ministry)\b',
            r'\b(nys|new york state|california state|federal|national)\s+(department|agency|bureau|service|commission|administration|office)',
            r'\b(dept|dep)\s+(of|for)\b',
            r'\b(health|defense|energy|education|agriculture|transportation|justice|state|homeland|veterans)\s+(department|agency|bureau|service|commission|administration|office)',
        ]
        
        for pattern in agency_patterns:
            if re.search(pattern, entity_lower):
                logging.info(f"✅ Pattern matched as agency: {pattern}")
                return "agencies"
        
        # State patterns
        state_patterns = [
            r'\b(state|commonwealth)\b',
            r'\b(california|new york|texas|florida|illinois|pennsylvania|ohio|michigan|georgia|north carolina)\b'
        ]
        
        for pattern in state_patterns:
            if re.search(pattern, entity_lower):
                logging.info(f"✅ Pattern matched as state: {pattern}")
                return "states"
        
        # Default: classify as recipient (most common case for company names)
        logging.info(f"✅ Default classification as recipient")
        return "recipients"
    
    def _partial_match(self, entity: str, known_entity: str) -> bool:
        """Check for partial matches between entities (case-insensitive)"""
        entity_words = set(entity.upper().split())
        known_words = set(known_entity.upper().split())
        
        # Remove common words
        common_words = {'THE', 'OF', 'AND', 'FOR', 'IN', 'ON', 'AT', 'TO', 'A', 'AN'}
        entity_words -= common_words
        known_words -= common_words
        
        if not entity_words or not known_words:
            return False
        
        # Check if significant portion of words match
        intersection = entity_words & known_words
        return len(intersection) >= min(2, len(entity_words) * 0.6, len(known_words) * 0.6)
    
    def _clean_entity_name(self, name: str) -> str:
        """Clean and normalize entity name while preserving original case"""
        if not name:
            return ""
        
        name = name.strip()
        
        # ENHANCED: Remove year references from entity names including ranges and "from" patterns
        year_patterns = [
            r'\s+in\s+\d{4}',
            r'\s+for\s+\d{4}', 
            r'\s+during\s+\d{4}',
            r'\s+from\s+\d{4}\s+to\s+\d{4}',
            r'\s+from\s+\d{4}',
            r'\s+since\s+\d{4}',
            r'\s+starting\s+\d{4}',
            r'\s+beginning\s+\d{4}',
            r'\s+\d{4}',
            r'\s+fy\s*\d{4}',  # Remove fiscal year references
            r'\s+fiscal\s+year\s+\d{4}'
        ]
        
        for pattern in year_patterns:
            name = re.sub(pattern, '', name, flags=re.IGNORECASE)
        
        # Remove common trailing words that shouldn't be part of entity names
        trailing_words = ['data', 'information', 'details', 'contracts', 'grants', 'awards', 'spending']
        words = name.split()
        while words and words[-1].lower() in trailing_words:
            words.pop()
        
        if not words:
            return ""
        
        name = ' '.join(words)
        
        # Remove trailing punctuation
        name = re.sub(r'[.,;!?]+', '', name)
        
        # Skip if too short or contains only common words
        if len(name) < 3:
            return ""
        
        # Don't return names that are just stop words
        if self._is_stop_word_phrase(name):
            return ""
        
        return name
    
    def _post_process_entities_enhanced(self, entities: Dict[str, List[str]], original_prompt: str) -> Dict[str, List[str]]:
        """Enhanced post-processing with conflict resolution"""
        
        # Remove duplicates across categories with priority (case-insensitive)
        all_found = set()
        processed_entities = {"recipients": [], "agencies": [], "states": []}
        
        # Priority order: agencies, states, recipients (agencies and states are more specific)
        for category in ["agencies", "states", "recipients"]:
            for entity in entities[category]:
                entity_clean = entity.strip()
                entity_clean_upper = entity_clean.upper()
                if entity_clean_upper not in all_found and not self._is_stop_word_phrase(entity):
                    processed_entities[category].append(entity_clean)  # Preserve original case
                    all_found.add(entity_clean_upper)
        
        # Validate entities against the original prompt context
        processed_entities = self._validate_entities_context(processed_entities, original_prompt)
        
        return processed_entities
    
    def _validate_entities_context(self, entities: Dict[str, List[str]], prompt: str) -> Dict[str, List[str]]:
        """Validate entities against the original prompt context (case-insensitive)"""
        validated_entities = {"recipients": [], "agencies": [], "states": []}
        
        for category, entity_list in entities.items():
            for entity in entity_list:
                # Check if entity actually appears in the original prompt (case-insensitive)
                if self._entity_in_prompt(entity, prompt):
                    validated_entities[category].append(entity)
                    logging.info(f"✅ Validated {entity} in prompt")
                else:
                    logging.info(f"❌ Entity {entity} not found in prompt")
        
        return validated_entities
    
    def _entity_in_prompt(self, entity: str, prompt: str) -> bool:
        """Check if entity is actually mentioned in the prompt (case-insensitive)"""
        entity_words = [word.lower() for word in entity.split() if len(word) > 2 and word.lower() not in self.stop_words]
        prompt_lower = prompt.lower()
        
        if not entity_words:
            return False
        
        # Check if substantial portion of entity words appear in prompt
        found_words = sum(1 for word in entity_words if word in prompt_lower)
        
        # Require at least 60% of meaningful words to be found
        return (found_words / len(entity_words)) >= 0.6