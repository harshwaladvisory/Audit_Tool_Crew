"""
FIXED: Excel export module with CONSISTENT fiscal year filtering and financial calculations
ENHANCED: Ensures Excel data matches JSON data exactly
"""
import json
import logging
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
import io
from datetime import datetime

def is_date_in_fiscal_year_excel(date_str, fiscal_year):
    """
    ENHANCED: Check if a date falls within the specified fiscal year - Excel version
    """
    if not date_str or not fiscal_year:
        return True  # Include if no filtering needed
    
    try:
        fy_int = int(fiscal_year)
        fy_start = f"{fy_int-1}-10-01"  # Oct 1 of previous year
        fy_end = f"{fy_int}-09-30"      # Sep 30 of fiscal year
        
        # Enhanced date parsing to handle multiple formats
        if isinstance(date_str, str) and len(date_str) >= 8:
            # Handle ISO datetime format (e.g., "2022-03-15T10:30:00Z")
            if 'T' in date_str:
                test_date = date_str.split('T')[0]  # YYYY-MM-DD format
            # Handle hyphen-separated dates (YYYY-MM-DD)
            elif '-' in date_str and len(date_str.split('-')) == 3:
                test_date = date_str.split(' ')[0]  # Remove any time component
            # Handle slash-separated dates
            elif '/' in date_str:
                parts = date_str.split('/')
                if len(parts) >= 3:
                    if len(parts[2]) == 4:  # MM/DD/YYYY format
                        month, day, year = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                        test_date = f"{year}-{month}-{day}"
                    elif len(parts[0]) == 4:  # YYYY/MM/DD format
                        year, month, day = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                        test_date = f"{year}-{month}-{day}"
                    else:  # DD/MM/YY format
                        day, month, year = parts[0].zfill(2), parts[1].zfill(2), f"20{parts[2]}"
                        test_date = f"{year}-{month}-{day}"
                else:
                    return True  # Can't parse, include it
            else:
                test_date = date_str[:10]  # Take first 10 characters
        else:
            return True  # Invalid date, include it
        
        # Validate the parsed date format
        try:
            datetime.strptime(test_date, '%Y-%m-%d')
        except ValueError:
            logging.warning(f"⚠️ Excel: Invalid date format after parsing: {test_date} from {date_str}")
            return True  # Include if date is invalid
        
        # Check if date falls in fiscal year range
        in_range = fy_start <= test_date <= fy_end
        
        if in_range:
            logging.debug(f"✅ Excel: Date {test_date} is in FY{fiscal_year}")
        else:
            logging.debug(f"❌ Excel: Date {test_date} is NOT in FY{fiscal_year}")
        
        return in_range
        
    except Exception as e:
        logging.warning(f"⚠️ Excel: Error checking date {date_str} against fiscal year {fiscal_year}: {e}")
        return True  # Include if we can't determine

def filter_awards_by_fiscal_year_excel(awards_data, target_years):
    """
    ENHANCED: Filter awards based on fiscal year with consistent logic matching webapp.py
    """
    if not target_years or not awards_data:
        logging.info(f"📊 Excel: No fiscal year filtering needed - returning all {len(awards_data)} awards")
        return awards_data
    
    # Convert target years to strings for comparison
    target_years_str = [str(year) for year in target_years]
    filtered_awards = []
    
    logging.info(f"🔍 Excel: Filtering {len(awards_data)} awards by fiscal years: {target_years_str}")
    
    # Show fiscal year date ranges for clarity
    for fy in target_years_str:
        try:
            fy_int = int(fy)
            start_date = f"{fy_int-1}-10-01"
            end_date = f"{fy_int}-09-30"
            logging.info(f"   Excel FY{fy}: {start_date} to {end_date}")
        except:
            logging.warning(f"   Excel FY{fy}: Invalid format")
    
    excluded_count = 0
    included_count = 0
    
    for award in awards_data:
        try:
            if not isinstance(award, dict):
                filtered_awards.append(award)
                included_count += 1
                continue
            
            # Extract action date with priority order matching webapp.py
            date_fields = [
                'action_date', 'Action Date',  # Highest priority
                'date_signed', 'signed_date', 'Date Signed',
                'award_date', 'Award Date',
                'transaction_date', 'Transaction Date',
                'issued_date', 'Issued Date',
                'executed_date', 'Executed Date',
                'start_date', 'Start Date',
                'end_date', 'End Date',  # Lower priority
                'timestamp', 'processing_timestamp'  # Lowest priority
            ]
            
            award_date = None
            date_field_used = None
            
            # Find the first available date field
            for field_name in date_fields:
                date_value = award.get(field_name)
                if date_value and date_value not in ['Unknown', 'N/A', None, '', 'null']:
                    if isinstance(date_value, str) and len(date_value) >= 8:
                        award_date = date_value
                        date_field_used = field_name
                        break
            
            # Check if award date falls in any fiscal year
            if award_date:
                award_included = False
                for fy in target_years_str:
                    if is_date_in_fiscal_year_excel(award_date, fy):
                        award_included = True
                        break
                
                if award_included:
                    filtered_awards.append(award)
                    included_count += 1
                    logging.debug(f"✅ Excel: Included award with {date_field_used}={award_date}")
                else:
                    excluded_count += 1
                    logging.debug(f"❌ Excel: Excluded award with {date_field_used}={award_date} (not in FY{target_years_str})")
            else:
                # If no date found, include the award
                filtered_awards.append(award)
                included_count += 1
                logging.debug(f"ℹ️ Excel: Included award with no date fields")
                
        except Exception as filter_error:
            logging.warning(f"⚠️ Excel: Error filtering award: {filter_error}")
            # Include the award if there's an error
            filtered_awards.append(award)
            included_count += 1
            continue
    
    logging.info(f"✅ Excel: Fiscal year filtering complete - {included_count} included, {excluded_count} excluded")
    logging.info(f"   Excel: Final count: {len(filtered_awards)} awards matching fiscal years {target_years_str}")
    return filtered_awards

def calculate_standardized_financial_metrics_excel(item):
    """
    ENHANCED: Same standardized financial calculation as webapp.py - Excel version
    """
    try:
        # Extract award amount (total amount awarded)
        award_amount = 0
        award_amount_fields = ['Award Amount', 'award_amount', 'amount', 'total_amount', 'awarded_amount']
        for field in award_amount_fields:
            value = item.get(field)
            if value is not None:
                try:
                    award_amount = float(value)
                    break
                except (ValueError, TypeError):
                    continue
        
        # Extract amount spent (Total Outlays from USA Spending API)
        amount_spent = 0
        amount_spent_fields = ['Total Outlays', 'total_outlays', 'amount_spent', 'outlays', 'disbursed_amount']
        for field in amount_spent_fields:
            value = item.get(field)
            if value is not None:
                try:
                    amount_spent = float(value)
                    break
                except (ValueError, TypeError):
                    continue
        
        # Calculate remaining amount correctly
        remaining_amount = award_amount - amount_spent
        
        # Calculate spending percentage correctly
        if award_amount > 0:
            spending_percentage = (amount_spent / award_amount) * 100
            
            # Handle edge cases where Total Outlays might equal Award Amount
            if spending_percentage > 100:
                spending_percentage = 100
                remaining_amount = 0
            elif spending_percentage < 0:
                spending_percentage = 0
                remaining_amount = award_amount
        else:
            spending_percentage = 0
            remaining_amount = 0
        
        return {
            'award_amount': award_amount,
            'amount_spent': amount_spent,
            'remaining_amount': remaining_amount,
            'spending_percentage': round(spending_percentage, 2)
        }
    except Exception as e:
        logging.error(f"❌ Excel: Error calculating financial metrics: {e}")
        return {
            'award_amount': 0,
            'amount_spent': 0,
            'remaining_amount': 0,
            'spending_percentage': 0
        }

def export_dynamic_json_to_excel_bytes(data):
    """
    ENHANCED: Export JSON data to Excel format with CONSISTENT fiscal year filtering and financial calculations
    """
    try:
        wb = Workbook()
        
        # Remove default sheet
        if "Sheet" in wb.sheetnames:
            wb.remove(wb["Sheet"])
        
        # Get the actual query data (exclude metadata)
        query_keys = [k for k in data.keys() if not k.startswith("_")]
        
        if not query_keys:
            logging.warning("⚠️ Excel: No query data found in export data")
            # Create error sheet
            create_error_sheet(wb, "No query data found")
            excel_buffer = io.BytesIO()
            wb.save(excel_buffer)
            excel_buffer.seek(0)
            return excel_buffer.getvalue()
        
        # Process only the first (and should be only) query
        main_query_key = query_keys[0]
        query_data = data[main_query_key]
        
        logging.info(f"🎯 Excel: Processing SINGLE query for Excel export: {main_query_key}")
        
        # Create detailed sheets for the query
        try:
            # Get query details for fiscal year filtering
            query_details = query_data.get('query_details', {})
            target_years = query_details.get('year', [])
            
            # Get fiscal year filtering info
            fiscal_year_filtering = query_data.get('fiscal_year_filtering', {})
            fiscal_year_applied = fiscal_year_filtering.get('filtering_applied', False)
            
            if target_years:
                logging.info(f"📅 Excel: Target fiscal years found: {target_years}")
                for fy in target_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        logging.info(f"   Excel FY{fy}: {start_date} to {end_date}")
                    except:
                        logging.warning(f"   Excel FY{fy}: Invalid format")
            else:
                logging.info(f"📅 Excel: No specific fiscal years - using all data")
            
            # Create query overview sheet
            create_single_query_overview_sheet_enhanced(wb, main_query_key, query_data)
            
            # Extract and process data with CONSISTENT fiscal year filtering
            raw_results = query_data.get('raw_results', [])
            
            # ENHANCED: Check if data is already filtered or needs filtering
            already_filtered = fiscal_year_applied or any(
                isinstance(item, dict) and item.get('fiscal_year_filtered', False) 
                for item in raw_results
            )
            
            if already_filtered and target_years:
                logging.info(f"📊 Excel: Data already filtered by fiscal year during processing")
                awards_data = []
                for item in raw_results:
                    if isinstance(item, dict) and item.get('data_type') == 'award':
                        # Apply standardized financial calculations
                        financial_metrics = calculate_standardized_financial_metrics_excel(item)
                        item.update(financial_metrics)
                        awards_data.append(item)
            else:
                # Get awards data and apply fiscal year filtering + standardized calculations
                awards_data = []
                for item in raw_results:
                    if isinstance(item, dict) and item.get('data_type') == 'award':
                        # Apply standardized financial calculations
                        financial_metrics = calculate_standardized_financial_metrics_excel(item)
                        item.update(financial_metrics)
                        awards_data.append(item)
                
                # Apply fiscal year filtering if needed
                if target_years and not already_filtered:
                    logging.info(f"🔍 Excel: Applying fiscal year filtering to {len(awards_data)} awards")
                    awards_data = filter_awards_by_fiscal_year_excel(awards_data, target_years)
                    logging.info(f"📅 Excel: After filtering: {len(awards_data)} awards")
            
            # Create awards sheet with standardized calculations
            if awards_data:
                create_awards_sheet_enhanced(wb, awards_data, "Awards_Data", target_years)
                logging.info(f"✅ Excel: Created awards sheet with {len(awards_data)} awards using standardized calculations")
            else:
                logging.warning("⚠️ Excel: No award data found for export")
                create_empty_awards_sheet_enhanced(wb, "Awards_Data", target_years)
            
            logging.info(f"✅ Excel: Created 2 sheets for query: {sanitize_sheet_name(main_query_key)[:20]}")
            
        except Exception as sheet_error:
            logging.error(f"❌ Excel: Error creating detailed sheets for {main_query_key}: {sheet_error}")
            create_error_sheet(wb, f"Error creating sheets: {str(sheet_error)}")
        
        # Save to bytes
        excel_buffer = io.BytesIO()
        wb.save(excel_buffer)
        excel_buffer.seek(0)
        
        logging.info(f"✅ Excel: Excel file generated with standardized financial calculations and fiscal year filtering")
        return excel_buffer.getvalue()
        
    except Exception as e:
        logging.error(f"❌ Excel: Error generating Excel file: {e}")
        # Return a basic workbook if main generation fails
        wb = Workbook()
        ws = wb.active
        ws.title = "Error"
        ws["A1"] = f"Error generating Excel file: {str(e)}"
        
        excel_buffer = io.BytesIO()
        wb.save(excel_buffer)
        excel_buffer.seek(0)
        return excel_buffer.getvalue()

def create_error_sheet(wb, error_message):
    """Create an error sheet when data is not available"""
    try:
        ws = wb.create_sheet(title="Error", index=0)
        
        # Title
        ws["A1"] = "Export Error"
        ws["A1"].font = Font(bold=True, size=16, color="FFFFFF")
        ws["A1"].fill = PatternFill(start_color="DC143C", end_color="DC143C", fill_type="solid")
        ws.merge_cells("A1:D1")
        ws["A1"].alignment = Alignment(horizontal="center")
        
        # Error message
        ws["A3"] = "Error Message:"
        ws["A3"].font = Font(bold=True)
        ws["B3"] = error_message
        
        ws["A5"] = "Please try processing a query first, then export the results."
        
        # Auto-adjust column widths
        for col_num in range(1, 5):
            column_letter = get_column_letter(col_num)
            ws.column_dimensions[column_letter].width = 20
            
    except Exception as e:
        logging.error(f"❌ Excel: Error creating error sheet: {e}")

def create_single_query_overview_sheet_enhanced(wb, query_key, query_data):
    """ENHANCED: Create overview sheet with CONSISTENT fiscal year information and financial calculations"""
    try:
        sheet_name = sanitize_sheet_name("Query_Overview")[:31]
        ws = wb.create_sheet(title=sheet_name, index=0)  # Make it the first sheet
        
        # Title
        ws["A1"] = f"Query Overview - {query_key[:20]}..."
        ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
        ws["A1"].fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
        ws.merge_cells("A1:D1")
        ws["A1"].alignment = Alignment(horizontal="center")
        
        # Query information
        row = 3
        query_details = query_data.get('query_details', {})
        target_years = query_details.get('year', [])
        fiscal_year_filtering = query_data.get('fiscal_year_filtering', {})
        
        # ENHANCED: Get standardized financial summary
        financial_summary = query_data.get('financial_summary', {})
        
        # ENHANCED: Build fiscal year context
        fiscal_year_context = "None specified"
        if target_years:
            fiscal_year_details = []
            for fy in target_years:
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    fiscal_year_details.append(f"FY{fy} ({start_date} to {end_date})")
                except:
                    fiscal_year_details.append(f"FY{fy}")
            fiscal_year_context = '; '.join(fiscal_year_details)
        
        query_info = [
            ("Query Key", query_key),
            ("Search Query", query_data.get('search_query', 'Unknown')),
            ("Target Fiscal Years", fiscal_year_context),
            ("Fiscal Year Filtering Applied", str(fiscal_year_filtering.get('filtering_applied', False))),
            ("Recipients Searched", ', '.join(query_details.get('recipients', []))),
            ("Agencies Searched", ', '.join(query_details.get('agency_name', []))),
            ("States Searched", ', '.join(query_details.get('state', []))),
            ("Award Types", ', '.join(query_details.get('award_types', []))),
            ("Processing Date", query_data.get('retrieval_date', 'Unknown')),
            ("Processing Complete", str(query_data.get('processing_complete', False)))
        ]
        
        for label, val in query_info:
            ws[f"A{row}"] = label
            ws[f"B{row}"] = str(val)
            ws[f"A{row}"].font = Font(bold=True)
            row += 1
        
        row += 1
        
        # ENHANCED: Display standardized financial summary
        if financial_summary:
            ws[f"A{row}"] = "Financial Summary (Standardized Calculations)"
            ws[f"A{row}"].font = Font(bold=True, size=12, color="FFFFFF")
            ws[f"A{row}"].fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            ws.merge_cells(f"A{row}:D{row}")
            row += 1
            
            # Use standardized financial summary
            financial_stats = [
                ("Total Amount Awarded", f"${financial_summary.get('total_amount_awarded', 0):,.2f}"),
                ("Total Amount Spent", f"${financial_summary.get('total_amount_spent', 0):,.2f}"),
                ("Total Remaining Amount", f"${financial_summary.get('remaining_amount', 0):,.2f}"),
                ("Average Spending Percentage", f"{financial_summary.get('spending_percentage', 0):.1f}%"),
                ("Financial Efficiency Ratio", f"{financial_summary.get('efficiency_ratio', 0):.1f}%"),
                ("Total Awards Count", financial_summary.get('total_awards_count', 0)),
                ("Calculation Method", financial_summary.get('calculation_method', 'standardized'))
            ]
            
            for label, val in financial_stats:
                ws[f"A{row}"] = label
                ws[f"B{row}"] = str(val)
                ws[f"A{row}"].font = Font(bold=True)
                row += 1
        
        # ENHANCED: Add fiscal year filtering summary
        if target_years:
            row += 1
            ws[f"A{row}"] = "Fiscal Year Filtering Details"
            ws[f"A{row}"].font = Font(bold=True, size=12, color="FFFFFF")
            ws[f"A{row}"].fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
            ws.merge_cells(f"A{row}:D{row}")
            row += 1
            
            filtering_details = [
                ("Original Results Count", fiscal_year_filtering.get('original_results_count', 'Unknown')),
                ("Filtered Results Count", fiscal_year_filtering.get('filtered_results_count', 'Unknown')),
                ("Filtering Applied", str(fiscal_year_filtering.get('filtering_applied', False))),
                ("Target Fiscal Years", ', '.join(target_years))
            ]
            
            for label, val in filtering_details:
                ws[f"A{row}"] = label
                ws[f"B{row}"] = str(val)
                ws[f"A{row}"].font = Font(bold=True)
                row += 1
        
        # Auto-adjust column widths
        for col_num in range(1, 5):
            max_length = 0
            column_letter = get_column_letter(col_num)
            
            for row_num in range(1, row + 1):
                try:
                    cell = ws.cell(row=row_num, column=col_num)
                    if not is_merged_cell(ws, cell) and cell.value:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                except Exception:
                    continue
            
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
            
    except Exception as e:
        logging.error(f"❌ Excel: Error creating single query overview sheet: {e}")

def create_awards_sheet_enhanced(wb, awards_data, sheet_name, target_years=None):
    """ENHANCED: Create awards sheet with CONSISTENT fiscal year filtering and financial calculations"""
    try:
        ws = wb.create_sheet(title=sanitize_sheet_name(sheet_name)[:31])
        
        # Remove duplicates from awards_data BEFORE processing
        unique_awards = []
        seen_award_ids = set()
        
        logging.info(f"🔍 Excel: Processing {len(awards_data)} awards with standardized calculations...")
        
        for award in awards_data:
            if not isinstance(award, dict):
                continue
            
            # Create unique identifier for award
            award_id = (award.get('award_id') or 
                       award.get('Award ID') or 
                       award.get('id') or 'unknown')
            
            recipient_name = (award.get('recipient_name') or 
                            award.get('Recipient Name') or 
                            award.get('name') or 'unknown')
            
            # Use standardized award_amount field
            award_amount = award.get('award_amount', 0)
            
            # Create composite key for deduplication
            unique_key = f"{award_id}_{recipient_name}_{award_amount}"
            
            if unique_key not in seen_award_ids:
                seen_award_ids.add(unique_key)
                unique_awards.append(award)
            else:
                logging.debug(f"🗑️ Excel: Removing duplicate award: {award_id} - {recipient_name}")
        
        logging.info(f"✅ Excel: Removed {len(awards_data) - len(unique_awards)} duplicates, processing {len(unique_awards)} unique awards")
        
        # ENHANCED: Create title with fiscal year context
        title_text = f"Awards Data - Standardized Financial Calculations - {len(unique_awards)} Records"
        if target_years:
            title_text += f" (Fiscal Years: {', '.join([f'FY{fy}' for fy in target_years])})"
        
        ws["A1"] = title_text
        ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
        ws["A1"].fill = PatternFill(start_color="1F497D", end_color="1F497D", fill_type="solid")
        ws.merge_cells("A1:J1")  # Extended to accommodate new column
        ws["A1"].alignment = Alignment(horizontal="center")
        
        # ENHANCED: Headers for the table (starting at row 3) - Added Action Date column
        headers = [
            "Award ID", "Recipient Name", "Award Amount", "Amount Spent", 
            "Remaining Amount", "Spending %", "Award Type", "Awarding Agency", "Action Date", "Fiscal Year Match"
        ]
        
        # Write headers without formatting (table will handle this)
        for col, header in enumerate(headers, 1):
            ws.cell(row=3, column=col, value=header)
        
        # Data rows - ENHANCED: Use standardized financial calculations with fiscal year validation
        last_row = 3  # Start after headers
        for row_idx, award in enumerate(unique_awards, 4):
            try:
                if not isinstance(award, dict):
                    continue
                
                # Extract award data
                award_id = (award.get('award_id') or 
                           award.get('Award ID') or 
                           award.get('id') or 'Unknown')
                
                recipient_name = (award.get('recipient_name') or 
                                award.get('Recipient Name') or 
                                award.get('name') or 'Unknown')
                
                # ENHANCED: Use standardized financial fields
                award_amount = award.get('award_amount', 0)
                amount_spent = award.get('amount_spent', 0)
                remaining_amount = award.get('remaining_amount', 0)
                spending_percentage = award.get('spending_percentage', 0)
                
                # Action date extraction with enhanced handling
                action_date = extract_action_date_for_filtering_excel(award)
                
                # ENHANCED: Check fiscal year match
                fiscal_year_match = "N/A"
                if target_years and action_date and action_date != 'Not Available':
                    matches = []
                    for fy in target_years:
                        if is_date_in_fiscal_year_excel(action_date, fy):
                            matches.append(f"FY{fy}")
                    fiscal_year_match = ', '.join(matches) if matches else "No Match"
                elif target_years:
                    fiscal_year_match = "No Date"
                
                # Other award details
                award_type = (award.get('award_type') or 
                            award.get('Award Type') or 
                            award.get('type') or 'Unknown')
                
                awarding_agency = (award.get('awarding_agency') or 
                                 award.get('Awarding Agency') or 
                                 award.get('agency') or 'Unknown')
                
                # Format financial amounts properly
                award_amount_str = f"${award_amount:,.2f}" if award_amount > 0 else "$0.00"
                amount_spent_str = f"${amount_spent:,.2f}" if amount_spent > 0 else "$0.00"
                remaining_amount_str = f"${remaining_amount:,.2f}" if remaining_amount != 0 else "$0.00"
                spending_percentage_str = f"{spending_percentage:.1f}%" if spending_percentage > 0 else "0.0%"
                
                # Write row data - ENHANCED: Include fiscal year match
                row_data = [
                    str(award_id), str(recipient_name), award_amount_str, 
                    amount_spent_str, remaining_amount_str, spending_percentage_str,
                    str(award_type), str(awarding_agency), str(action_date), str(fiscal_year_match)
                ]
                
                for col, data in enumerate(row_data, 1):
                    ws.cell(row=row_idx, column=col, value=data)
                
                last_row = row_idx  # Track the last row with data
                    
            except Exception as row_error:
                logging.warning(f"⚠️ Excel: Error processing award row {row_idx}: {row_error}")
                continue
        
        # Create Excel Table for filtering functionality
        try:
            if last_row > 3:  # Only create table if we have data
                # Define table range (from headers to last data row)
                table_range = f"A3:{get_column_letter(len(headers))}{last_row}"
                
                # Create table
                table = Table(displayName="AwardsTable", ref=table_range)
                
                # Apply table style
                style = TableStyleInfo(
                    name="TableStyleMedium9",  # Blue table style
                    showFirstColumn=False,
                    showLastColumn=False,
                    showRowStripes=True,
                    showColumnStripes=False
                )
                table.tableStyleInfo = style
                
                # Add table to worksheet
                ws.add_table(table)
                
                logging.info(f"✅ Excel: Created filterable Excel table with standardized calculations - {len(unique_awards)} records")
            else:
                # If no data, just format headers
                for col, header in enumerate(headers, 1):
                    cell = ws.cell(row=3, column=col, value=header)
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
                    cell.alignment = Alignment(horizontal="center")
                
                logging.info("✅ Excel: Created headers for empty awards sheet")
                
        except Exception as table_error:
            logging.warning(f"⚠️ Excel: Error creating Excel table: {table_error}")
            # Fallback to manual header formatting if table creation fails
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=3, column=col, value=header)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
                cell.alignment = Alignment(horizontal="center")
        
        # Auto-adjust column widths
        auto_adjust_columns(ws, len(headers))
        
        # ENHANCED: Add financial calculation note with fiscal year context
        note_row = last_row + 2
        ws.cell(row=note_row, column=1, value="Financial Calculation Note:")
        ws.cell(row=note_row, column=1).font = Font(bold=True)
        ws.cell(row=note_row + 1, column=1, value="All financial calculations use standardized methodology:")
        ws.cell(row=note_row + 2, column=1, value="• Award Amount: Total amount awarded/obligated")
        ws.cell(row=note_row + 3, column=1, value="• Amount Spent: Total outlays/disbursements (from USA Spending API)")
        ws.cell(row=note_row + 4, column=1, value="• Remaining Amount: Award Amount - Amount Spent")
        ws.cell(row=note_row + 5, column=1, value="• Spending %: (Amount Spent / Award Amount) × 100")
        ws.cell(row=note_row + 6, column=1, value="• Data matches UI and JSON calculations")
        
        if target_years:
            ws.cell(row=note_row + 7, column=1, value="Fiscal Year Filtering:")
            ws.cell(row=note_row + 7, column=1).font = Font(bold=True)
            for i, fy in enumerate(target_years):
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    ws.cell(row=note_row + 8 + i, column=1, value=f"• FY{fy}: {start_date} to {end_date}")
                except:
                    ws.cell(row=note_row + 8 + i, column=1, value=f"• FY{fy}: Invalid format")
        
        logging.info(f"✅ Excel: Created awards sheet with standardized calculations and fiscal year context - {len(unique_awards)} awards")
        
    except Exception as e:
        logging.error(f"❌ Excel: Error creating awards sheet: {e}")

def create_empty_awards_sheet_enhanced(wb, sheet_name, target_years=None):
    """ENHANCED: Create empty awards sheet when no data is available - with fiscal year context"""
    try:
        ws = wb.create_sheet(title=sanitize_sheet_name(sheet_name)[:31])
        
        # ENHANCED: Title with fiscal year context
        title_text = "Awards Data - No Data Available"
        if target_years:
            title_text += f" (Searched Fiscal Years: {', '.join([f'FY{fy}' for fy in target_years])})"
        
        ws["A1"] = title_text
        ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
        ws["A1"].fill = PatternFill(start_color="DC143C", end_color="DC143C", fill_type="solid")
        ws.merge_cells("A1:J1")
        ws["A1"].alignment = Alignment(horizontal="center")
        
        # Headers (same as the table structure)
        headers = [
            "Award ID", "Recipient Name", "Award Amount", "Amount Spent", 
            "Remaining Amount", "Spending %", "Award Type", "Awarding Agency", "Action Date", "Fiscal Year Match"
        ]
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="70AD47", end_color="70AD47", fill_type="solid")
            cell.alignment = Alignment(horizontal="center")
        
        # No data message
        ws["A5"] = "No awards data available for the specified criteria."
        ws["A5"].font = Font(italic=True)
        
        # ENHANCED: Add fiscal year context if available
        if target_years:
            ws["A7"] = "Searched Fiscal Years:"
            ws["A7"].font = Font(bold=True)
            for i, fy in enumerate(target_years):
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    ws[f"A{8+i}"] = f"• FY{fy}: {start_date} to {end_date}"
                except:
                    ws[f"A{8+i}"] = f"• FY{fy}: Invalid format"
        
        # Auto-adjust column widths
        auto_adjust_columns(ws, len(headers))
        
        logging.info(f"✅ Excel: Created empty awards sheet with table headers and fiscal year context")
        
    except Exception as e:
        logging.error(f"❌ Excel: Error creating empty awards sheet: {e}")

def extract_action_date_for_filtering_excel(award):
    """ENHANCED: Extract action date for year filtering - Excel version with consistent logic"""
    action_date_fields = [
        'action_date', 'Action Date',  # Highest priority
        'date_signed', 'signed_date', 'Date Signed',
        'award_date', 'Award Date',
        'transaction_date', 'Transaction Date',
        'issued_date', 'Issued Date',
        'executed_date', 'Executed Date',
        'start_date', 'Start Date',  # Lower priority
        'end_date', 'End Date',
        'timestamp', 'processing_timestamp'  # Lowest priority
    ]
    
    for field_name in action_date_fields:
        value = award.get(field_name)
        if value and value not in ['Unknown', 'N/A', None, '', 'null']:
            if isinstance(value, str):
                # Remove time component if present
                if 'T' in value:
                    date_part = value.split('T')[0]
                else:
                    date_part = value.split(' ')[0]
                if date_part and len(date_part) >= 8:
                    return date_part
            return str(value)
    
    return 'Not Available'

def auto_adjust_columns(ws, num_columns):
    """Auto-adjust column widths with proper error handling"""
    try:
        for col_num in range(1, num_columns + 1):
            max_length = 0
            column_letter = get_column_letter(col_num)
            
            # Check first 50 rows for performance
            for row_num in range(1, min(ws.max_row + 1, 51)):
                try:
                    cell = ws.cell(row=row_num, column=col_num)
                    if not is_merged_cell(ws, cell) and cell.value:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                except Exception:
                    continue
            
            # Set column width
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
    except Exception as e:
        logging.warning(f"⚠️ Excel: Error auto-adjusting columns: {e}")

def is_merged_cell(worksheet, cell):
    """Check if a cell is part of a merged range"""
    try:
        for merged_range in worksheet.merged_cells.ranges:
            if cell.coordinate in merged_range:
                return True
        return False
    except Exception:
        return False

def sanitize_sheet_name(name):
    """Sanitize sheet name to be Excel-compatible"""
    try:
        # Remove invalid characters
        invalid_chars = ['\\', '/', '*', '[', ']', ':', '?']
        for char in invalid_chars:
            name = name.replace(char, '_')
        
        # Ensure it's not too long and not empty
        name = name[:31] if name else "Sheet"
        
        return name
    except Exception:
        return "Sheet"