"""
Data validation and cleaning utilities with FIXED validation rules
FIXED: Enhanced support for strict validation mode
"""

import json
import logging
from typing import List, Dict, Any, Optional
from decimal import Decimal
import re
from datetime import datetime

class DataValidator:
    def __init__(self):
        self.required_fields = ['name']  # Keep minimal requirements
        self.numeric_fields = ['amount', 'total_amount', 'award_amount', 'Award Amount']
        self.date_fields = ['start_date', 'end_date', 'date_signed', 'Start Date', 'End Date']
        self.validation_rules = self._init_validation_rules()
        self.strict_mode = False  # FIXED: Add strict mode support
    
    def _init_validation_rules(self) -> Dict[str, Any]:
        """FIXED: Initialize validation rules with strict mode support"""
        return {
            'max_amount': 1000000000000,  # $1T limit
            'min_amount': -1000000000000,  # Allow negative amounts for adjustments
            'max_string_length': 1000,
            'max_list_length': 1000,
            'max_dict_depth': 10,
            'min_name_length': 2,  # FIXED: Reduced from 3 to 2
            'allow_empty_amounts': True,  # FIXED: Allow empty amounts
            'strict_validation': False,  # FIXED: Disable strict validation by default
            'strict_name_validation': False,  # FIXED: Add strict name validation option
            'require_valid_entities': False,  # FIXED: Add entity validation requirement
            'block_suspicious_names': False  # FIXED: Add suspicious name blocking
        }
    
    def set_strict_mode(self, strict: bool = True):
        """FIXED: Enable/disable strict validation mode"""
        self.strict_mode = strict
        self.validation_rules['strict_validation'] = strict
        self.validation_rules['strict_name_validation'] = strict
        self.validation_rules['require_valid_entities'] = strict
        self.validation_rules['block_suspicious_names'] = strict
        
        if strict:
            self.validation_rules['min_name_length'] = 3  # Stricter in strict mode
            self.validation_rules['allow_empty_amounts'] = False
            logging.info("✅ STRICT validation mode enabled")
        else:
            self.validation_rules['min_name_length'] = 2
            self.validation_rules['allow_empty_amounts'] = True
            logging.info("✅ LENIENT validation mode enabled")
    
    def validate_and_clean(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        FIXED: Validate and clean the results data with strict/lenient mode support
        """
        if not data:
            return []
        
        validated_data = []
        
        for item in data:
            try:
                cleaned_item = self.clean_single_item(item)
                
                # FIXED: Use appropriate validation based on mode
                if self.strict_mode:
                    is_valid = self.is_valid_item_strict(cleaned_item)
                else:
                    is_valid = self.is_valid_item_fixed(cleaned_item)
                
                if is_valid:
                    validated_data.append(cleaned_item)
                else:
                    # FIXED: In strict mode, be more aggressive about rejecting
                    if self.strict_mode:
                        logging.warning(f"❌ STRICT: Item rejected: {item.get('name', 'unknown')}")
                        continue
                    else:
                        # Try to salvage in lenient mode
                        logging.warning(f"⚠️ Item failed validation but attempting to salvage: {item.get('name', 'unknown')}")
                        salvaged_item = self.salvage_item(item)
                        if salvaged_item:
                            validated_data.append(salvaged_item)
                            
            except Exception as e:
                logging.error(f"❌ Error validating item: {e}")
                
                # FIXED: In strict mode, don't try to salvage errors
                if self.strict_mode:
                    logging.warning(f"❌ STRICT: Skipping errored item")
                    continue
                else:
                    # Try to salvage the item even if validation fails
                    try:
                        salvaged_item = self.salvage_item(item)
                        if salvaged_item:
                            validated_data.append(salvaged_item)
                    except Exception as salvage_error:
                        logging.error(f"❌ Could not salvage item: {salvage_error}")
                        continue
        
        # Remove duplicates
        deduplicated_data = self.remove_duplicates(validated_data)
        
        # Sort by relevance
        sorted_data = self.sort_by_relevance(deduplicated_data)
        
        mode_text = "STRICT" if self.strict_mode else "LENIENT"
        logging.info(f"✅ Validated {len(sorted_data)} items from {len(data)} original items ({mode_text} mode)")
        return sorted_data
    
    def is_valid_item_strict(self, item: Dict[str, Any]) -> bool:
        """FIXED: Strict item validation for strict mode"""
        if not item or not isinstance(item, dict):
            return False
        
        # FIXED: Stricter required field check
        for field in self.required_fields:
            if field not in item:
                # Check alternative field names but be stricter
                alt_fields = {
                    'name': ['Recipient Name', 'recipient_name', 'entity_name']
                }
                
                if field in alt_fields:
                    found = False
                    for alt_field in alt_fields[field]:
                        if alt_field in item and item[alt_field]:
                            found = True
                            break
                    if not found:
                        logging.warning(f"❌ STRICT: Required field '{field}' not found")
                        return False
                else:
                    return False
        
        # FIXED: Strict name quality check
        name_candidates = [
            item.get('name'),
            item.get('Recipient Name'),
            item.get('recipient_name'),
            item.get('entity_name')
        ]
        
        valid_name = None
        for name in name_candidates:
            if name and isinstance(name, str):
                name_clean = name.strip()
                if len(name_clean) >= self.validation_rules['min_name_length']:
                    # FIXED: Additional strict checks
                    if self._is_suspicious_name(name_clean):
                        logging.warning(f"❌ STRICT: Suspicious name detected: {name_clean}")
                        return False
                    
                    if self._has_valid_entity_pattern(name_clean):
                        valid_name = name
                        break
        
        if not valid_name:
            logging.warning(f"❌ STRICT: No valid name found")
            return False
        
        # FIXED: Strict amount validation if configured
        if not self.validation_rules['allow_empty_amounts']:
            has_valid_amount = False
            for amount_field in ['amount', 'Award Amount', 'award_amount', 'total_amount']:
                amount = item.get(amount_field)
                if amount is not None:
                    try:
                        amount_float = float(amount)
                        if not (amount_float != amount_float):  # Check for NaN
                            if (self.validation_rules['min_amount'] <= amount_float <= 
                               self.validation_rules['max_amount']):
                                has_valid_amount = True
                                break
                    except (ValueError, TypeError):
                        continue
            
            if not has_valid_amount:
                logging.warning(f"❌ STRICT: No valid amount found")
                return False
        
        # FIXED: Check for strict validation flags
        if item.get('strict_validation_applied') is False:
            logging.warning(f"❌ STRICT: Item not processed with strict validation")
            return False
        
        return True
    
    def _is_suspicious_name(self, name: str) -> bool:
        """FIXED: Check for suspicious name patterns"""
        if not name or len(name) < 3:
            return True
        
        name_lower = name.lower()
        
        # Check for common typo patterns
        suspicious_patterns = [
            r'^[a-z]*[0-9]+[a-z]*$',  # Mixed letters and numbers randomly
            r'^[^a-zA-Z]*$',          # No letters at all
            r'^\w{1,2}$',             # Too short
            r'^(.)\1{3,}',            # Repeated characters (aaaa, bbbb)
            r'^[^aeiou]{4,}$',        # No vowels in long words
        ]
        
        for pattern in suspicious_patterns:
            if re.match(pattern, name_lower):
                return True
        
        # Check for common typos in known entities
        known_typos = {
            'blckfeet', 'blakfeet', 'blackeet', 'blcket',  # blackfeet typos
            'navjo', 'nvajo', 'naavjo',  # navajo typos
            'boing', 'boeng',  # boeing typos
            'googl', 'gogle',  # google typos
            'amazom', 'amazn',  # amazon typos
        }
        
        for word in name_lower.split():
            if word in known_typos:
                return True
        
        return False
    
    def _has_valid_entity_pattern(self, name: str) -> bool:
        """FIXED: Check if name has valid entity patterns"""
        if not name or len(name) < 3:
            return False
        
        name_lower = name.lower()
        
        # Valid entity indicators
        valid_patterns = [
            # Corporate indicators
            r'\b(corp|corporation|company|inc|llc|ltd|group)\b',
            r'\b(systems|technologies|solutions|industries)\b',
            r'\b(international|global|national)\b',
            
            # Government/institutional indicators
            r'\b(department|agency|bureau|service|commission)\b',
            r'\b(authority|foundation|institute|center)\b',
            r'\b(university|college|school)\b',
            
            # Tribal/indigenous indicators
            r'\b(housing|tribal|nation|pueblo|band|tribe)\b',
            r'\b(indian|indians|native|indigenous)\b',
            
            # Geographic indicators
            r'\b(state|county|city|municipal)\b',
            
            # Professional service indicators
            r'\b(consulting|engineering|research|development)\b'
        ]
        
        # Check if name contains valid patterns
        for pattern in valid_patterns:
            if re.search(pattern, name_lower):
                return True
        
        # Check if it looks like a proper name (multiple capitalized words)
        words = name.split()
        if len(words) >= 2:
            capitalized_count = sum(1 for word in words if word and word[0].isupper())
            if capitalized_count >= 2:
                return True
        
        return False
    
    def salvage_item(self, item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """FIXED: Attempt to salvage items that fail validation with strict mode awareness"""
        if not isinstance(item, dict):
            return None
        
        # FIXED: In strict mode, don't salvage anything
        if self.strict_mode:
            logging.warning(f"❌ STRICT: No salvaging in strict mode")
            return None
        
        try:
            salvaged = {
                'validation_status': 'salvaged',
                'validation_timestamp': datetime.now().isoformat(),
                'original_validation_failed': True,
                'salvage_mode': 'lenient'
            }
            
            # Try to extract a name from various fields
            name_candidates = [
                item.get('name'),
                item.get('recipient_name'),
                item.get('Recipient Name'),
                item.get('entity_name'),
                item.get('award_id'),
                item.get('Award ID'),
                'Unknown Entity'
            ]
            
            for name_candidate in name_candidates:
                if name_candidate and isinstance(name_candidate, str) and len(name_candidate.strip()) >= 1:
                    salvaged['name'] = name_candidate.strip()
                    break
            
            if 'name' not in salvaged:
                salvaged['name'] = 'Unknown Entity'
            
            # Try to extract amount information
            amount_candidates = [
                item.get('amount'),
                item.get('award_amount'),
                item.get('Award Amount'),
                item.get('total_amount'),
                item.get('transaction_amount'),
                0
            ]
            
            for amount_candidate in amount_candidates:
                if amount_candidate is not None:
                    try:
                        amount_value = float(amount_candidate)
                        if not (amount_value != amount_value):  # Check for NaN
                            salvaged['amount'] = amount_value
                            break
                    except (ValueError, TypeError):
                        continue
            
            if 'amount' not in salvaged:
                salvaged['amount'] = 0
            
            # Copy other useful fields
            useful_fields = [
                'data_type', 'query_type', 'source', 'award_id', 'recipient_id',
                'awarding_agency', 'award_type', 'description', 'start_date', 'end_date',
                'processing_timestamp', 'extracted_from', 'original_query'
            ]
            
            for field in useful_fields:
                if field in item:
                    salvaged[field] = item[field]
            
            # Add salvage metadata
            salvaged['salvage_reason'] = 'Original validation failed, data salvaged with minimal requirements'
            salvaged['salvage_timestamp'] = datetime.now().isoformat()
            
            logging.info(f"✅ Salvaged item in lenient mode: {salvaged.get('name', 'Unknown')}")
            return salvaged
            
        except Exception as e:
            logging.error(f"❌ Error salvaging item: {e}")
            return None
    
    def clean_single_item(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """FIXED: Clean a single data item with strict mode awareness"""
        cleaned = {}
        
        for key, value in item.items():
            # Clean the key
            clean_key = self.clean_field_name(key)
            
            # Clean the value
            clean_value = self.clean_field_value(clean_key, value)
            
            if clean_value is not None:
                cleaned[clean_key] = clean_value
        
        # Add metadata
        cleaned['validation_timestamp'] = datetime.now().isoformat()
        cleaned['validation_status'] = 'cleaned'
        cleaned['validation_mode'] = 'strict' if self.strict_mode else 'lenient'
        
        return cleaned
    
    def clean_field_name(self, field_name: str) -> str:
        """Clean field names with enhanced normalization"""
        if not field_name:
            return ""
        
        # Keep original case for known important fields
        known_fields = {
            'Award ID', 'Award Amount', 'Award Type', 'Awarding Agency',
            'Start Date', 'End Date', 'Recipient Name', 'Description'
        }
        
        if field_name in known_fields:
            return field_name
        
        # Convert to lowercase and replace spaces/special chars with underscores
        clean_name = re.sub(r'[^a-zA-Z0-9_]', '_', str(field_name).lower())
        
        # Remove multiple underscores
        clean_name = re.sub(r'_+', '_', clean_name)
        
        # Remove leading/trailing underscores
        clean_name = clean_name.strip('_')
        
        return clean_name
    
    def clean_field_value(self, field_name: str, value: Any) -> Any:
        """FIXED: Clean field values based on field type with strict mode awareness"""
        if value is None:
            return None
        
        # Handle numeric fields
        if field_name.lower() in [f.lower() for f in self.numeric_fields]:
            return self.clean_numeric_value(value)
        
        # Handle date fields
        if field_name.lower() in [f.lower() for f in self.date_fields]:
            return self.clean_date_value(value)
        
        # Handle string fields
        if isinstance(value, str):
            return self.clean_string_value(value)
        
        # Handle list fields
        if isinstance(value, list):
            return self.clean_list_value(value)
        
        # Handle dict fields
        if isinstance(value, dict):
            return self.clean_dict_value(value)
        
        return value
    
    def clean_numeric_value(self, value: Any) -> Optional[float]:
        """FIXED: Clean numeric values with strict mode awareness"""
        if value is None:
            return None
        
        try:
            # Handle Decimal objects
            if isinstance(value, Decimal):
                return float(value)
            
            # Handle strings
            if isinstance(value, str):
                # Remove currency symbols, commas, and whitespace
                clean_str = re.sub(r'[$,\s€£¥]', '', value)
                
                # Handle negative values in parentheses
                if clean_str.startswith('(') and clean_str.endswith(')'):
                    clean_str = '-' + clean_str[1:-1]
                
                if clean_str:
                    parsed_value = float(clean_str)
                    
                    # FIXED: Stricter validation in strict mode
                    if self.strict_mode:
                        if not (self.validation_rules['min_amount'] <= parsed_value <= 
                                self.validation_rules['max_amount']):
                            logging.warning(f"❌ STRICT: Numeric value outside range: {parsed_value}")
                            return None
                    else:
                        # More lenient validation - allow wider range
                        if (self.validation_rules['min_amount'] <= parsed_value <= 
                            self.validation_rules['max_amount']):
                            return parsed_value
                        else:
                            # Don't reject - just log warning and return the value
                            logging.warning(f"⚠️ Numeric value outside expected range but allowing: {parsed_value}")
                            return parsed_value
                return None
            
            # Handle other numeric types
            parsed_value = float(value)
            
            # FIXED: Apply validation based on mode
            if self.strict_mode:
                if not (self.validation_rules['min_amount'] <= parsed_value <= 
                        self.validation_rules['max_amount']):
                    logging.warning(f"❌ STRICT: Numeric value outside range: {parsed_value}")
                    return None
            else:
                # More lenient validation - allow wider range
                if (self.validation_rules['min_amount'] <= parsed_value <= 
                    self.validation_rules['max_amount']):
                    return parsed_value
                else:
                    # Don't reject - just log warning and return the value
                    logging.warning(f"⚠️ Numeric value outside expected range but allowing: {parsed_value}")
                    return parsed_value
            
            return parsed_value
            
        except (ValueError, TypeError, OverflowError):
            # FIXED: Stricter handling in strict mode
            if self.strict_mode:
                logging.warning(f"❌ STRICT: Could not convert to numeric: {value}")
                return None
            else:
                # More lenient - try to return 0 instead of None for failed conversions
                logging.warning(f"⚠️ Could not convert to numeric, using 0: {value}")
                return 0
    
    def clean_date_value(self, value: Any) -> Optional[str]:
        """Clean date values with enhanced parsing"""
        if value is None:
            return None
        
        try:
            # If it's already a string, validate format
            if isinstance(value, str):
                # Remove time component if present
                value = value.split('T')[0].split(' ')[0]
                
                # Check if it matches common date formats
                date_patterns = [
                    (r'^\d{4}-\d{2}-\d{2}$', '%Y-%m-%d'),  # YYYY-MM-DD
                    (r'^\d{2}/\d{2}/\d{4}$', '%m/%d/%Y'),  # MM/DD/YYYY
                    (r'^\d{2}-\d{2}-\d{4}$', '%m-%d-%Y'),  # MM-DD-YYYY
                    (r'^\d{4}/\d{2}/\d{2}$', '%Y/%m/%d'),  # YYYY/MM/DD
                ]
                
                for pattern, format_str in date_patterns:
                    if re.match(pattern, value):
                        # Validate that it's a real date
                        try:
                            datetime.strptime(value, format_str)
                            return value
                        except ValueError:
                            continue
            
            # Try to parse as timestamp
            if isinstance(value, (int, float)):
                if value > 0:  # Reasonable timestamp check
                    dt = datetime.fromtimestamp(value)
                    return dt.strftime('%Y-%m-%d')
            
            return str(value) if value else None
            
        except Exception:
            logging.warning(f"⚠️ Could not clean date value: {value}")
            return None
    
    def clean_string_value(self, value: str) -> str:
        """Clean string values with enhanced cleaning"""
        if not value:
            return ""
        
        # Remove excessive whitespace
        cleaned = re.sub(r'\s+', ' ', value.strip())
        
        # Remove null bytes and other problematic characters
        cleaned = cleaned.replace('\x00', '').replace('\n', ' ').replace('\r', ' ')
        
        # Remove control characters
        cleaned = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', cleaned)
        
        # Limit length
        if len(cleaned) > self.validation_rules['max_string_length']:
            cleaned = cleaned[:self.validation_rules['max_string_length']] + "..."
        
        return cleaned
    
    def clean_list_value(self, value: List[Any]) -> List[Any]:
        """Clean list values with enhanced processing"""
        if not value:
            return []
        
        # Limit list length
        if len(value) > self.validation_rules['max_list_length']:
            value = value[:self.validation_rules['max_list_length']]
        
        cleaned_list = []
        for item in value:
            if isinstance(item, dict):
                cleaned_item = self.clean_single_item(item)
                if cleaned_item:
                    cleaned_list.append(cleaned_item)
            elif item is not None:
                cleaned_list.append(item)
        
        return cleaned_list
    
    def clean_dict_value(self, value: Dict[str, Any], depth: int = 0) -> Dict[str, Any]:
        """Clean dictionary values with depth protection"""
        if not value:
            return {}
        
        if depth > self.validation_rules['max_dict_depth']:
            return {'_truncated': 'Max depth reached'}
        
        cleaned_dict = {}
        for k, v in value.items():
            clean_key = self.clean_field_name(k)
            if isinstance(v, dict):
                cleaned_dict[clean_key] = self.clean_dict_value(v, depth + 1)
            else:
                cleaned_dict[clean_key] = self.clean_field_value(clean_key, v)
        
        return cleaned_dict
    
    def is_valid_item_fixed(self, item: Dict[str, Any]) -> bool:
        """FIXED: More lenient item validation for non-strict mode"""
        if not item:
            return False
        
        # Check basic structure
        if not isinstance(item, dict):
            return False
        
        # FIXED: More lenient required field check
        for field in self.required_fields:
            if field not in item:
                # Allow alternative field names
                alt_fields = {
                    'name': ['Recipient Name', 'recipient_name', 'entity_name', 'award_id', 'Award ID']
                }
                
                if field in alt_fields:
                    found = False
                    for alt_field in alt_fields[field]:
                        if alt_field in item and item[alt_field]:
                            found = True
                            break
                    if not found:
                        # FIXED: Don't immediately reject - check if we can salvage
                        logging.warning(f"⚠️ Required field '{field}' not found but attempting to continue")
                        return False
                else:
                    return False
        
        # FIXED: More lenient name quality check
        name_candidates = [
            item.get('name'),
            item.get('Recipient Name'),
            item.get('recipient_name'),
            item.get('entity_name'),
            item.get('award_id'),
            item.get('Award ID')
        ]
        
        valid_name = None
        for name in name_candidates:
            if name and isinstance(name, str) and len(name.strip()) >= self.validation_rules['min_name_length']:
                valid_name = name
                break
        
        if not valid_name:
            # FIXED: Don't immediately reject - log warning
            logging.warning(f"⚠️ No valid name found in item: {list(item.keys())}")
            return False
        
        # FIXED: More lenient amount validation
        if not self.validation_rules['allow_empty_amounts']:
            # Check for reasonable data
            if len(valid_name.strip()) < self.validation_rules['min_name_length']:
                return False
            
            # Validate amount if present
            for amount_field in ['amount', 'Award Amount', 'award_amount', 'total_amount']:
                amount = item.get(amount_field)
                if amount is not None:
                    try:
                        amount_float = float(amount)
                        if not (self.validation_rules['min_amount'] <= amount_float <= 
                               self.validation_rules['max_amount']):
                            # FIXED: Don't reject - just log warning
                            logging.warning(f"⚠️ Amount outside range but allowing: {amount_float}")
                    except (ValueError, TypeError):
                        # FIXED: Don't reject - just log warning
                        logging.warning(f"⚠️ Could not validate amount but allowing: {amount}")
        
        return True
    
    def remove_duplicates(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate items with enhanced deduplication"""
        seen = set()
        unique_data = []
        
        for item in data:
            # Create a unique key for deduplication
            key_parts = []
            
            # Use various fields for uniqueness
            for field in ['id', 'Award ID', 'award_id']:
                if item.get(field):
                    key_parts.append(str(item[field]))
                    break
            
            # Use name
            name_candidates = ['name', 'Recipient Name', 'recipient_name']
            for name_field in name_candidates:
                if item.get(name_field):
                    key_parts.append(item[name_field].upper().strip())
                    break
            
            # Use DUNS if available
            for duns_field in ['duns', 'DUNS', 'duns_number']:
                if item.get(duns_field):
                    key_parts.append(str(item[duns_field]))
                    break
            
            # Use amount as tie-breaker
            for amount_field in ['amount', 'Award Amount', 'award_amount']:
                if item.get(amount_field):
                    key_parts.append(str(item[amount_field]))
                    break
            
            # FIXED: Create unique key even if no fields found
            if not key_parts:
                key_parts = [f"unknown_{len(unique_data)}"]
            
            unique_key = '|'.join(key_parts)
            
            if unique_key not in seen:
                seen.add(unique_key)
                unique_data.append(item)
        
        return unique_data
    
    def sort_by_relevance(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sort data by relevance with multiple criteria"""
        
        def get_sort_key(item):
            # Primary: Amount (highest first)
            amount = 0
            for amount_field in ['amount', 'Award Amount', 'award_amount', 'total_amount']:
                if item.get(amount_field):
                    try:
                        amount = float(item[amount_field])
                        break
                    except (ValueError, TypeError):
                        continue
            
            # Secondary: Match score if available
            match_score = item.get('match_score', 0)
            
            # Tertiary: Processing timestamp (most recent first)
            timestamp = item.get('processing_timestamp', 0)
            
            # FIXED: Handle validation status - prioritize based on mode
            validation_status = item.get('validation_status', 'unknown')
            status_priority = 0
            
            if self.strict_mode:
                # In strict mode, prioritize strict validation
                if validation_status == 'cleaned' and item.get('strict_validation_applied'):
                    status_priority = 3
                elif validation_status == 'cleaned':
                    status_priority = 2
                elif validation_status == 'salvaged':
                    status_priority = 0  # Lowest priority in strict mode
                else:
                    status_priority = 1
            else:
                # In lenient mode, don't heavily penalize salvaged items
                if validation_status == 'cleaned':
                    status_priority = 2
                elif validation_status == 'salvaged':
                    status_priority = 1
                else:
                    status_priority = 0
            
            return (-amount, -match_score, -timestamp, -status_priority)
        
        return sorted(data, key=get_sort_key)
    
    def validate_structure(self, data: Any) -> bool:
        """FIXED: Structure validation with strict mode support"""
        if not isinstance(data, list):
            if self.strict_mode:
                logging.error("❌ STRICT: Data must be a list")
                return False
            else:
                logging.warning("⚠️ Data must be a list, but attempting to process anyway")
                return True  # FIXED: Don't reject, just warn
        
        if not data:
            if self.strict_mode:
                logging.error("❌ STRICT: Data list is empty")
                return False
            else:
                logging.warning("⚠️ Data list is empty")
                return True
        
        # Check first few items for structure
        sample_size = min(5, len(data))
        valid_items = 0
        
        for i in range(sample_size):
            item = data[i]
            if isinstance(item, dict):
                valid_items += 1
            else:
                logging.warning(f"⚠️ Item {i} is not a dictionary: {type(item)}")
        
        # FIXED: Stricter validation in strict mode
        if self.strict_mode:
            if valid_items < sample_size:
                logging.error(f"❌ STRICT: Only {valid_items}/{sample_size} items are valid dictionaries")
                return False
        else:
            # More lenient - allow if at least 50% of items are valid
            if valid_items < (sample_size * 0.5):
                logging.warning(f"⚠️ Only {valid_items}/{sample_size} items are valid dictionaries")
                return True  # FIXED: Still return True to allow processing
        
        return True
    
    def get_validation_summary(self, original_data: List[Dict[str, Any]], 
                             validated_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """FIXED: Get a comprehensive summary of the validation process with strict mode info"""
        summary = {
            'original_count': len(original_data),
            'validated_count': len(validated_data),
            'filtered_count': len(original_data) - len(validated_data),
            'success_rate': (len(validated_data) / len(original_data) * 100) if original_data else 0,
            'validation_timestamp': datetime.now().isoformat(),
            'validation_mode': 'strict' if self.strict_mode else 'lenient',
            'strict_validation_enabled': self.strict_mode
        }
        
        # Add field statistics
        field_stats = {}
        cleaned_count = 0
        salvaged_count = 0
        strict_validated_count = 0
        
        for item in validated_data:
            # Count validation status
            validation_status = item.get('validation_status', 'unknown')
            if validation_status == 'cleaned':
                cleaned_count += 1
            elif validation_status == 'salvaged':
                salvaged_count += 1
            
            # Count strict validation
            if item.get('strict_validation_applied'):
                strict_validated_count += 1
            
            # Count fields
            for field in item.keys():
                if field not in field_stats:
                    field_stats[field] = 0
                field_stats[field] += 1
        
        summary['field_coverage'] = field_stats
        summary['most_common_fields'] = sorted(field_stats.items(), 
                                             key=lambda x: x[1], 
                                             reverse=True)[:10]
        summary['cleaned_items'] = cleaned_count
        summary['salvaged_items'] = salvaged_count
        summary['strict_validated_items'] = strict_validated_count
        summary['rejection_rate'] = ((len(original_data) - len(validated_data)) / len(original_data) * 100) if original_data else 0
        
        return summary