# additional_utils.py
"""
Additional utility functions for the USA Spending Scraper - Enhanced Version
FIXED: Enhanced fiscal year filtering functionality with consistent date handling
"""

import json
import os
import time
import logging
import glob  # FIXED: Added for backup file cleanup
from datetime import datetime, timedelta  # FIXED: Added timedelta
from typing import Dict, Any, List, Optional

def convert_fiscal_year_to_date_range(fiscal_year):
    """
    Convert fiscal year to actual date range
    FY 2022 = Oct 1, 2021 to Sep 30, 2022
    """
    try:
        fy = int(fiscal_year)
        start_date = f"{fy-1}-10-01"  # October 1 of previous calendar year
        end_date = f"{fy}-09-30"      # September 30 of fiscal year
        return start_date, end_date
    except (ValueError, TypeError):
        # Fallback to calendar year if conversion fails
        return f"{fiscal_year}-01-01", f"{fiscal_year}-12-31"

def is_date_in_fiscal_year(date_str, fiscal_year):
    """
    ENHANCED: Check if a date falls within the specified fiscal year with better parsing
    """
    if not date_str or not fiscal_year:
        return True  # Include if no filtering needed
    
    try:
        fy_start, fy_end = convert_fiscal_year_to_date_range(fiscal_year)
        
        # Parse and normalize the date with enhanced date format handling
        if isinstance(date_str, str) and len(date_str) >= 8:
            # Handle ISO datetime format (e.g., "2022-03-15T10:30:00Z")
            if 'T' in date_str:
                test_date = date_str.split('T')[0]  # YYYY-MM-DD format, remove time
            # Handle hyphen-separated dates (YYYY-MM-DD)
            elif '-' in date_str and len(date_str.split('-')) == 3:
                test_date = date_str.split(' ')[0]  # Remove any time component
            # Handle slash-separated dates
            elif '/' in date_str:
                parts = date_str.split('/')
                if len(parts) >= 3:
                    if len(parts[2]) == 4:  # MM/DD/YYYY format
                        month, day, year = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                        test_date = f"{year}-{month}-{day}"
                    elif len(parts[0]) == 4:  # YYYY/MM/DD format
                        year, month, day = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                        test_date = f"{year}-{month}-{day}"
                    else:  # DD/MM/YY format
                        day, month, year = parts[0].zfill(2), parts[1].zfill(2), f"20{parts[2]}"
                        test_date = f"{year}-{month}-{day}"
                else:
                    return True  # Can't parse, include it
            # Handle dates with only numbers (YYYYMMDD)
            elif date_str.isdigit() and len(date_str) == 8:
                year, month, day = date_str[:4], date_str[4:6], date_str[6:8]
                test_date = f"{year}-{month}-{day}"
            else:
                return True  # Unknown format, include it
        else:
            return True  # Invalid date, include it
        
        # Validate the parsed date format
        try:
            datetime.strptime(test_date, '%Y-%m-%d')
        except ValueError:
            logging.warning(f"⚠️ Invalid date format after parsing: {test_date} from {date_str}")
            return True  # Include if date is invalid
        
        # Check if date falls in fiscal year range
        in_range = fy_start <= test_date <= fy_end
        
        if in_range:
            logging.debug(f"✅ Date {test_date} is in FY{fiscal_year} ({fy_start} to {fy_end})")
        else:
            logging.debug(f"❌ Date {test_date} is NOT in FY{fiscal_year} ({fy_start} to {fy_end})")
        
        return in_range
        
    except Exception as e:
        logging.warning(f"⚠️ Error checking date {date_str} against fiscal year {fiscal_year}: {e}")
        return True  # Include if we can't determine

def is_date_in_any_fiscal_year(date_str, fiscal_years):
    """
    ENHANCED: Check if a date falls within any of the specified fiscal years
    """
    if not fiscal_years or not date_str:
        return True  # Include if no filtering needed
    
    for fy in fiscal_years:
        if is_date_in_fiscal_year(date_str, fy):
            return True
    
    return False

def filter_entity_data_by_fiscal_year(entities, fiscal_years):
    """
    ENHANCED: Filter entity data by fiscal years with better date field detection
    """
    if not fiscal_years or not entities:
        return entities
    
    filtered_entities = []
    
    logging.info(f"🔍 Filtering {len(entities)} entities by fiscal years: {fiscal_years}")
    
    for entity in entities:
        if not isinstance(entity, dict):
            filtered_entities.append(entity)
            continue
        
        # ENHANCED: Check various date fields with priority order
        date_fields = [
            'action_date', 'Action Date',  # Highest priority - actual transaction/award date
            'date_signed', 'signed_date', 'Date Signed',
            'award_date', 'Award Date',
            'transaction_date', 'Transaction Date',
            'issued_date', 'Issued Date',
            'executed_date', 'Executed Date',
            'start_date', 'Start Date',
            'end_date', 'End Date',  # Lower priority
            'timestamp', 'processing_timestamp'  # Lowest priority
        ]
        
        entity_date = None
        date_field_used = None
        
        # Find the first available date field
        for field_name in date_fields:
            date_value = entity.get(field_name)
            if date_value:
                if isinstance(date_value, (int, float)):
                    # Convert timestamp to date string
                    try:
                        entity_date = datetime.fromtimestamp(date_value).strftime('%Y-%m-%d')
                        date_field_used = field_name
                        break
                    except:
                        continue
                elif isinstance(date_value, str) and len(date_value) >= 8:
                    entity_date = date_value
                    date_field_used = field_name
                    break
        
        # Check if entity date falls in any fiscal year
        if entity_date:
            if is_date_in_any_fiscal_year(entity_date, fiscal_years):
                filtered_entities.append(entity)
                logging.debug(f"✅ Included entity with {date_field_used}={entity_date}")
            else:
                logging.debug(f"❌ Excluded entity with {date_field_used}={entity_date} (not in FY{fiscal_years})")
        else:
            # If no date found, include the entity
            filtered_entities.append(entity)
            logging.debug(f"ℹ️ Included entity with no date fields")
    
    logging.info(f"✅ Filtered {len(entities)} entities to {len(filtered_entities)} based on fiscal years {fiscal_years}")
    return filtered_entities

def get_fiscal_year_from_date(date_str):
    """
    ENHANCED: Determine which fiscal year a date belongs to
    """
    if not date_str:
        return None
    
    try:
        # Parse the date
        if isinstance(date_str, str):
            # Handle ISO datetime format
            if 'T' in date_str:
                date_part = date_str.split('T')[0]
            # Handle hyphen-separated dates
            elif '-' in date_str and len(date_str.split('-')) == 3:
                date_part = date_str.split(' ')[0]
            # Handle slash-separated dates
            elif '/' in date_str:
                parts = date_str.split('/')
                if len(parts) >= 3:
                    if len(parts[2]) == 4:  # MM/DD/YYYY
                        month, day, year = parts[0], parts[1], parts[2]
                        date_part = f"{year}-{month.zfill(2)}-{day.zfill(2)}"
                    elif len(parts[0]) == 4:  # YYYY/MM/DD
                        year, month, day = parts[0], parts[1], parts[2]
                        date_part = f"{year}-{month.zfill(2)}-{day.zfill(2)}"
                    else:
                        return None
                else:
                    return None
            else:
                date_part = date_str
        else:
            return None
        
        # Parse the date
        date_obj = datetime.strptime(date_part, '%Y-%m-%d')
        
        # Determine fiscal year
        # If month is October-December, fiscal year is next calendar year
        # If month is January-September, fiscal year is current calendar year
        if date_obj.month >= 10:  # October, November, December
            fiscal_year = date_obj.year + 1
        else:  # January through September
            fiscal_year = date_obj.year
        
        return str(fiscal_year)
        
    except Exception as e:
        logging.warning(f"⚠️ Error determining fiscal year from date {date_str}: {e}")
        return None

def group_entities_by_fiscal_year(entities):
    """
    ENHANCED: Group entities by their fiscal year
    """
    grouped = {}
    
    for entity in entities:
        if not isinstance(entity, dict):
            continue
        
        # Find the date field
        date_fields = [
            'action_date', 'Action Date', 'date_signed', 'award_date',
            'transaction_date', 'start_date', 'timestamp'
        ]
        
        entity_date = None
        for field_name in date_fields:
            date_value = entity.get(field_name)
            if date_value:
                if isinstance(date_value, (int, float)):
                    try:
                        entity_date = datetime.fromtimestamp(date_value).strftime('%Y-%m-%d')
                        break
                    except:
                        continue
                elif isinstance(date_value, str) and len(date_value) >= 8:
                    entity_date = date_value
                    break
        
        # Determine fiscal year
        if entity_date:
            fiscal_year = get_fiscal_year_from_date(entity_date)
            if fiscal_year:
                if fiscal_year not in grouped:
                    grouped[fiscal_year] = []
                grouped[fiscal_year].append(entity)
            else:
                # Unknown fiscal year
                if 'unknown' not in grouped:
                    grouped['unknown'] = []
                grouped['unknown'].append(entity)
        else:
            # No date found
            if 'no_date' not in grouped:
                grouped['no_date'] = []
            grouped['no_date'].append(entity)
    
    return grouped

# FIXED: Add automatic backup cleanup function
def auto_cleanup_backup_files(max_age_hours: int = 24, backup_patterns: List[str] = None) -> int:
    """
    FIXED: Automatically cleanup old backup files older than max_age_hours
    """
    try:
        if backup_patterns is None:
            backup_patterns = [
                "*.backup_*",
                "*_backup_*", 
                "backups/*.json",
                "*.json.backup_*",
                "summary_backup_*",
                "final_results_backup_*",
                "output_backup_*"
            ]
        
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        deleted_count = 0
        
        for pattern in backup_patterns:
            try:
                backup_files = glob.glob(pattern)
                
                for backup_file in backup_files:
                    try:
                        # Check if file is older than max_age_hours
                        file_age = current_time - os.path.getmtime(backup_file)
                        
                        if file_age > max_age_seconds:
                            file_size = os.path.getsize(backup_file)
                            os.remove(backup_file)
                            deleted_count += 1
                            logging.info(f"🗑️ Deleted old backup file: {backup_file} ({file_size} bytes)")
                            
                    except Exception as file_error:
                        logging.warning(f"⚠️ Could not delete backup file {backup_file}: {file_error}")
                        continue
                        
            except Exception as pattern_error:
                logging.warning(f"⚠️ Error processing backup pattern {pattern}: {pattern_error}")
                continue
        
        if deleted_count > 0:
            logging.info(f"✅ Auto-cleanup: Removed {deleted_count} old backup files")
        else:
            logging.debug("ℹ️ Auto-cleanup: No old backup files found")
            
        return deleted_count
        
    except Exception as e:
        logging.error(f"❌ Error during auto backup cleanup: {e}")
        return 0

def load_summary_data() -> Dict[str, Any]:
    """
    FIXED: Load summary data from summary.json file with error handling and auto-cleanup
    """
    # FIXED: Run auto-cleanup before loading
    auto_cleanup_backup_files(max_age_hours=12)
    
    summary_file = "summary.json"
    if os.path.exists(summary_file):
        try:
            with open(summary_file, 'r') as f:
                data = json.load(f)
                logging.info(f"✅ Loaded summary data with {len(data)} entities")
                return data
        except json.JSONDecodeError as e:
            logging.error(f"❌ Error parsing summary.json: {e}")
            # FIXED: Create backup before returning empty dict
            backup_corrupted_file(summary_file)
            return {}
        except Exception as e:
            logging.error(f"❌ Error loading summary.json: {e}")
            return {}
    
    logging.info("📝 No existing summary.json found, starting fresh")
    return {}

def save_summary_data(data: Dict[str, Any]) -> bool:
    """
    FIXED: Save summary data to summary.json file with backup rotation
    """
    try:
        # FIXED: Create backup of existing file before overwriting
        if os.path.exists("summary.json"):
            backup_existing_file("summary.json")
        
        with open("summary.json", 'w') as f:
            json.dump(data, f, indent=4, default=str)
        logging.info(f"✅ Saved summary data with {len(data)} entities")
        
        # FIXED: Run cleanup after saving
        auto_cleanup_backup_files(max_age_hours=24)
        
        return True
    except Exception as e:
        logging.error(f"❌ Error saving summary.json: {e}")
        return False

def backup_existing_file(file_path: str) -> Optional[str]:
    """FIXED: Create backup of existing file with timestamp"""
    try:
        if not os.path.exists(file_path):
            return None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path}.backup_{timestamp}"
        
        # Only keep backups if file is substantial (> 100 bytes)
        if os.path.getsize(file_path) > 100:
            os.rename(file_path, backup_name)
            logging.debug(f"📁 Created backup: {backup_name}")
            return backup_name
        else:
            logging.debug(f"📁 Skipped backup for small file: {file_path}")
            return None
            
    except Exception as e:
        logging.warning(f"⚠️ Could not backup {file_path}: {e}")
        return None

def backup_corrupted_file(file_path: str) -> Optional[str]:
    """FIXED: Backup corrupted files for investigation"""
    try:
        if not os.path.exists(file_path):
            return None
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path}.corrupted_{timestamp}"
        
        os.rename(file_path, backup_name)
        logging.warning(f"🚨 Backed up corrupted file: {backup_name}")
        return backup_name
        
    except Exception as e:
        logging.error(f"❌ Could not backup corrupted file {file_path}: {e}")
        return None

def get_entity_statistics() -> Dict[str, Any]:
    """
    FIXED: Get comprehensive statistics about processed entities with fiscal year support
    """
    # FIXED: Run auto-cleanup before processing
    auto_cleanup_backup_files(max_age_hours=6)
    
    summary = load_summary_data()
    
    stats = {
        'total_entities': len(summary),
        'by_type': {},
        'total_records': 0,
        'processing_times': [],
        'last_processed': None,
        'entities_with_ai_response': 0,
        'entities_with_data': 0,
        'average_records_per_entity': 0,
        'largest_entity': None,
        'most_recent_entity': None,
        'total_spending': 0,
        'top_entities_by_amount': [],
        'backup_files_cleaned': 0,
        'fiscal_year_filtering': True,  # NEW: Indicate fiscal year support
        'date_filtering_note': 'All date filtering uses US Federal Fiscal Year (Oct 1 - Sep 30)'  # NEW
    }
        
    total_records = 0
    largest_amount = 0
    all_entities = []
    
    for key, value in summary.items():
        try:
            # Parse entity type from key
            entity_type = key.split('_')[0] if '_' in key else 'unknown'
            
            # Count by type
            if entity_type not in stats['by_type']:
                stats['by_type'][entity_type] = 0
            stats['by_type'][entity_type] += 1
            
            # Count records
            data = value.get('data', [])
            if isinstance(data, list):
                record_count = len(data)
                total_records += record_count
                
                # Calculate total spending for this entity
                entity_spending = 0
                for record in data:
                    if isinstance(record, dict):
                        amount = record.get('amount', 0)
                        if isinstance(amount, (int, float)):
                            entity_spending += amount
                
                stats['total_spending'] += entity_spending
                
                # Track entity for top entities list
                if entity_spending > 0:
                    all_entities.append({
                        'key': key,
                        'name': data[0].get('name', 'Unknown') if data else 'Unknown',
                        'amount': entity_spending,
                        'type': entity_type
                    })
                
                # Check for largest entity by amount
                if entity_spending > largest_amount:
                    largest_amount = entity_spending
                    stats['largest_entity'] = {
                        'key': key,
                        'name': data[0].get('name', 'Unknown') if data else 'Unknown',
                        'amount': entity_spending,
                        'type': entity_type
                    }
            else:
                total_records += 1
            
            # Check for AI response
            if value.get('ai_response') and value.get('ai_response').strip():
                stats['entities_with_ai_response'] += 1
            
            # Check for data
            if data:
                stats['entities_with_data'] += 1
            
            # Track processing times
            timestamp = value.get('timestamp')
            if timestamp:
                stats['processing_times'].append(timestamp)
                if not stats['last_processed'] or timestamp > stats['last_processed']:
                    stats['last_processed'] = timestamp
                    stats['most_recent_entity'] = {
                        'key': key,
                        'timestamp': timestamp
                    }
                    
        except Exception as e:
            logging.warning(f"⚠️ Error processing entity {key}: {e}")
            continue
    
    stats['total_records'] = total_records
    
    # Calculate averages
    if stats['total_entities'] > 0:
        stats['average_records_per_entity'] = total_records / stats['total_entities']
    
    # Get top entities by amount
    stats['top_entities_by_amount'] = sorted(all_entities, 
                                           key=lambda x: x['amount'], 
                                           reverse=True)[:10]
    
    # Convert last processed to readable format
    if stats['last_processed']:
        stats['last_processed_readable'] = datetime.fromtimestamp(
            stats['last_processed']
        ).strftime("%Y-%m-%d %H:%M:%S")
    
    # Add processing efficiency metrics
    if stats['total_entities'] > 0:
        stats['ai_response_rate'] = (stats['entities_with_ai_response'] / stats['total_entities']) * 100
        stats['data_coverage_rate'] = (stats['entities_with_data'] / stats['total_entities']) * 100
    
    return stats

def clean_old_summary_entries(max_age_hours: int = 24) -> int:
    """
    FIXED: Clean old entries from summary.json older than max_age_hours with backup cleanup
    """
    # FIXED: Run backup cleanup first
    cleanup_count = auto_cleanup_backup_files(max_age_hours=max_age_hours)
    
    summary = load_summary_data()
    current_time = time.time()
    max_age_seconds = max_age_hours * 3600
    
    cleaned_summary = {}
    removed_count = 0
    
    for key, value in summary.items():
        timestamp = value.get('timestamp', current_time)
        if current_time - timestamp < max_age_seconds:
            cleaned_summary[key] = value
        else:
            removed_count += 1
            logging.debug(f"🗑️ Removing old entry: {key}")
    
    # Save cleaned summary
    if save_summary_data(cleaned_summary):
        logging.info(f"🧹 Cleaned {removed_count} old entries from summary, {cleanup_count} backup files")
    
    return removed_count

def export_summary_to_json(filename: Optional[str] = None) -> str:
    """
    FIXED: Export summary data to a JSON file with timestamp and cleanup
    """
    # FIXED: Cleanup old exports first
    auto_cleanup_backup_files(max_age_hours=48, backup_patterns=["summary_export_*.json"])
    
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"summary_export_{timestamp}.json"
    
    summary = load_summary_data()
    
    # Add export metadata
    export_data = {
        'export_timestamp': time.time(),
        'export_date': datetime.now().isoformat(),
        'total_entities': len(summary),
        'export_version': '2.0',
        'auto_cleanup_enabled': True,  # FIXED: Indicate cleanup is enabled
        'fiscal_year_support': True,
        'data': summary
    }
    
    try:
        with open(filename, 'w') as f:
            json.dump(export_data, f, indent=4, default=str)
        
        logging.info(f"📁 Exported summary data to {filename}")
        return filename
    except Exception as e:
        logging.error(f"❌ Error exporting summary: {e}")
        raise

def get_entity_details(entity_key: str) -> Optional[Dict[str, Any]]:
    """
    Get detailed information about a specific entity
    """
    summary = load_summary_data()
    
    if entity_key not in summary:
        return None
    
    entity_data = summary[entity_key]
    
    # Parse entity type and name
    key_parts = entity_key.split('_', 1)
    entity_type = key_parts[0] if key_parts else 'unknown'
    entity_name = key_parts[1] if len(key_parts) > 1 else entity_key
    
    details = {
        'key': entity_key,
        'type': entity_type,
        'name': entity_name,
        'processed': entity_data.get('processed', False),
        'timestamp': entity_data.get('timestamp'),
        'data_count': 0,
        'has_ai_response': bool(entity_data.get('ai_response')),
        'ai_response_length': len(entity_data.get('ai_response', '')),
        'prompt': entity_data.get('prompt', ''),
        'processing_time': None,
        'data_summary': {},
        'query_details': entity_data.get('query_details', {}),
        'fiscal_year_info': entity_data.get('fiscal_year_info', {})
    }
    
    # Count data records and analyze structure
    data = entity_data.get('data', [])
    if isinstance(data, list):
        details['data_count'] = len(data)
        
        # Analyze data structure
        if data:
            sample = data[0] if len(data) > 0 else {}
            if isinstance(sample, dict):
                details['sample_fields'] = list(sample.keys())[:10]  # First 10 fields
                
                # Calculate totals if numeric fields exist
                numeric_fields = ['amount', 'total_amount', 'award_amount', 'Award Amount']
                for field in numeric_fields:
                    if field in sample:
                        total = sum(item.get(field, 0) for item in data 
                                  if isinstance(item.get(field), (int, float)))
                        details['data_summary'][f'total_{field}'] = total
                
                # Group by fiscal year if date fields exist
                fiscal_year_groups = group_entities_by_fiscal_year(data)
                if fiscal_year_groups:
                    details['fiscal_year_breakdown'] = {
                        fy: len(entities) for fy, entities in fiscal_year_groups.items()
                    }
    else:
        details['data_count'] = 1
    
    # Format timestamp
    if details['timestamp']:
        details['processed_time'] = datetime.fromtimestamp(
            details['timestamp']
        ).strftime("%Y-%m-%d %H:%M:%S")
        
        # Calculate processing time (time since timestamp)
        details['processing_time'] = time.time() - details['timestamp']
    
    return details

def search_entities_by_name(search_term: str) -> List[Dict[str, Any]]:
    """
    Search for entities by name in the summary with improved matching
    """
    summary = load_summary_data()
    search_term = search_term.lower()
    
    matches = []
    
    for key, value in summary.items():
        # Parse key
        key_parts = key.split('_', 1)
        entity_type = key_parts[0] if key_parts else 'unknown'
        entity_name = key_parts[1] if len(key_parts) > 1 else key
        
        # Check if search term matches
        if (search_term in entity_name.lower() or 
            search_term in key.lower() or
            search_term in value.get('prompt', '').lower()):
            
            # Calculate relevance score
            relevance_score = 0
            if search_term in entity_name.lower():
                relevance_score += 10
            if search_term == entity_name.lower():
                relevance_score += 20
            if search_term in value.get('prompt', '').lower():
                relevance_score += 5
            
            # Calculate total spending
            total_spending = 0
            data = value.get('data', [])
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        amount = item.get('amount', 0)
                        if isinstance(amount, (int, float)):
                            total_spending += amount
            
            matches.append({
                'key': key,
                'type': entity_type,
                'name': entity_name,
                'data_count': len(value.get('data', [])) if isinstance(value.get('data'), list) else 1,
                'processed': value.get('processed', False),
                'has_ai_response': bool(value.get('ai_response')),
                'relevance_score': relevance_score,
                'timestamp': value.get('timestamp'),
                'total_spending': total_spending
            })
    
    # Sort by relevance score and timestamp
    matches.sort(key=lambda x: (x['relevance_score'], x.get('timestamp', 0)), reverse=True)
    
    return matches

def validate_summary_integrity() -> Dict[str, Any]:
    """
    FIXED: Validate the integrity of summary.json data with comprehensive checks and cleanup
    """
    # FIXED: Run cleanup before validation
    cleanup_count = auto_cleanup_backup_files(max_age_hours=6)
    
    summary = load_summary_data()
    issues = []
    warnings = []
    
    valid_entity_types = ['recipient', 'agency', 'state', 'award_type', 'query']
    
    for key, value in summary.items():
        # Check key format
        if '_' not in key:
            issues.append(f"Invalid key format (missing underscore): {key}")
            continue
        
        # Parse entity type
        entity_type = key.split('_')[0]
        if entity_type not in valid_entity_types:
            warnings.append(f"Unknown entity type: {entity_type} in key {key}")
        
        # Check required fields
        if not isinstance(value, dict):
            issues.append(f"Invalid value type for {key}: expected dict, got {type(value)}")
            continue
        
        if 'data' not in value:
            issues.append(f"Missing 'data' field in {key}")
        
        if 'timestamp' not in value:
            warnings.append(f"Missing 'timestamp' field in {key}")
        
        # Check data structure
        data = value.get('data')
        if data is not None:
            if not isinstance(data, (list, dict)):
                issues.append(f"Invalid data type in {key}: {type(data)}")
            elif isinstance(data, list):
                # Check list contents
                for i, item in enumerate(data[:5]):  # Check first 5 items
                    if not isinstance(item, dict):
                        warnings.append(f"Non-dict item in {key} data at index {i}")
        
        # Check AI response
        ai_response = value.get('ai_response')
        if ai_response and not isinstance(ai_response, str):
            warnings.append(f"Invalid ai_response type in {key}: {type(ai_response)}")
        
        # Check timestamp
        timestamp = value.get('timestamp')
        if timestamp and not isinstance(timestamp, (int, float)):
            warnings.append(f"Invalid timestamp type in {key}: {type(timestamp)}")
    
    return {
        'valid': len(issues) == 0,
        'issues': issues,
        'warnings': warnings,
        'total_entities': len(summary),
        'issue_count': len(issues),
        'warning_count': len(warnings),
        'backup_files_cleaned': cleanup_count  # FIXED: Include cleanup info
    }

def merge_summary_files(file1: str, file2: str, output_file: str = "merged_summary.json") -> int:
    """
    FIXED: Merge two summary JSON files with conflict resolution and backup cleanup
    """
    # FIXED: Cleanup old merged files first
    auto_cleanup_backup_files(max_age_hours=72, backup_patterns=["merged_summary*.json"])
    
    try:
        with open(file1, 'r') as f:
            summary1 = json.load(f)
    except Exception as e:
        logging.error(f"❌ Error loading {file1}: {e}")
        summary1 = {}
    
    try:
        with open(file2, 'r') as f:
            summary2 = json.load(f)
    except Exception as e:
        logging.error(f"❌ Error loading {file2}: {e}")
        summary2 = {}
    
    # Merge summaries with conflict resolution
    merged = {}
    conflicts = 0
    
    # Add all entries from summary1
    for key, value in summary1.items():
        merged[key] = value
    
    # Add entries from summary2, handling conflicts
    for key, value in summary2.items():
        if key in merged:
            # Conflict detected - keep the more recent one
            existing_timestamp = merged[key].get('timestamp', 0)
            new_timestamp = value.get('timestamp', 0)
            
            if new_timestamp > existing_timestamp:
                merged[key] = value
                conflicts += 1
                logging.info(f"🔄 Conflict resolved for {key}: kept newer entry")
        else:
            merged[key] = value
    
    # Save merged summary with backup
    try:
        if os.path.exists(output_file):
            backup_existing_file(output_file)
        
        with open(output_file, 'w') as f:
            json.dump(merged, f, indent=4, default=str)
        
        logging.info(f"🔗 Merged {len(summary1)} + {len(summary2)} = {len(merged)} entities into {output_file}")
        logging.info(f"⚠️ Resolved {conflicts} conflicts")
        
        return len(merged)
    except Exception as e:
        logging.error(f"❌ Error saving merged file: {e}")
        raise

def backup_summary(backup_dir: str = "backups") -> Optional[str]:
    """
    FIXED: Create a backup of the current summary.json with metadata and auto-cleanup
    """
    if not os.path.exists("summary.json"):
        logging.warning("⚠️ No summary.json file to backup")
        return None
    
    try:
        os.makedirs(backup_dir, exist_ok=True)
        
        # FIXED: Cleanup old backups in the backup directory first
        old_backups = glob.glob(f"{backup_dir}/summary_backup_*.json")
        current_time = time.time()
        cleanup_count = 0
        
        for backup_file in old_backups:
            try:
                file_age = current_time - os.path.getmtime(backup_file)
                if file_age > (48 * 3600):  # 48 hours
                    os.remove(backup_file)
                    cleanup_count += 1
            except Exception as cleanup_error:
                logging.warning(f"⚠️ Could not cleanup old backup {backup_file}: {cleanup_error}")
        
        if cleanup_count > 0:
            logging.info(f"🧹 Cleaned up {cleanup_count} old backup files from {backup_dir}")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = os.path.join(backup_dir, f"summary_backup_{timestamp}.json")
        
        # Load current summary and add backup metadata
        summary = load_summary_data()
        backup_data = {
            'backup_timestamp': time.time(),
            'backup_date': datetime.now().isoformat(),
            'original_file': 'summary.json',
            'entity_count': len(summary),
            'backup_version': '2.0',
            'auto_cleanup_enabled': True,  # FIXED: Indicate cleanup is enabled
            'fiscal_year_support': True,
            'data': summary
        }
        
        with open(backup_filename, 'w') as f:
            json.dump(backup_data, f, indent=4, default=str)
        
        logging.info(f"💾 Created backup: {backup_filename}")
        return backup_filename
        
    except Exception as e:
        logging.error(f"❌ Error creating backup: {e}")
        return None

def restore_summary_from_backup(backup_file: str) -> bool:
    """
    FIXED: Restore summary.json from a backup file with safety backup
    """
    if not os.path.exists(backup_file):
        logging.error(f"❌ Backup file {backup_file} not found")
        return False
    
    try:
        # FIXED: Create backup of current summary first
        current_backup = backup_summary()
        if current_backup:
            logging.info(f"📦 Current summary backed up to {current_backup}")
        
        # Load backup data
        with open(backup_file, 'r') as f:
            backup_data = json.load(f)
        
        # Extract the actual summary data
        if 'data' in backup_data:
            summary_data = backup_data['data']
        else:
            # Assume the whole file is the summary
            summary_data = backup_data
        
        # Save restored data
        if save_summary_data(summary_data):
            logging.info(f"🔄 Restored summary.json from {backup_file}")
            logging.info(f"📊 Restored {len(summary_data)} entities")
            return True
        else:
            logging.error("❌ Failed to save restored data")
            return False
            
    except Exception as e:
        logging.error(f"❌ Error restoring from backup: {e}")
        return False

def run_diagnostics() -> Dict[str, Any]:
    """
    FIXED: Run comprehensive diagnostics on the system and return results with cleanup info
    """
    logging.info("🔍 Running USA Spending Scraper Diagnostics...")
    
    # FIXED: Run cleanup as part of diagnostics
    cleanup_count = auto_cleanup_backup_files(max_age_hours=12)
    
    diagnostics = {
        'timestamp': datetime.now().isoformat(),
        'file_status': {},
        'summary_stats': {},
        'data_integrity': {},
        'recommendations': [],
        'system_info': {
            'python_version': None,
            'working_directory': os.getcwd(),
            'disk_usage': {},
            'backup_files_cleaned': cleanup_count,  # FIXED: Include cleanup info
            'fiscal_year_support': True
        }
    }
    
    # Check file existence and sizes
    files_to_check = [
        "summary.json",
        "final_results.json", 
        "all_recipients.json",
        "output.json"
    ]
    
    for filename in files_to_check:
        if os.path.exists(filename):
            size = os.path.getsize(filename)
            diagnostics['file_status'][filename] = {
                'exists': True,
                'size_bytes': size,
                'size_mb': round(size / (1024 * 1024), 2),
                'last_modified': datetime.fromtimestamp(os.path.getmtime(filename)).isoformat()
            }
        else:
            diagnostics['file_status'][filename] = {'exists': False}
    
    # Get summary statistics
    try:
        stats = get_entity_statistics()
        diagnostics['summary_stats'] = stats
    except Exception as e:
        diagnostics['summary_stats'] = {'error': str(e)}
    
    # Check data integrity
    try:
        validation = validate_summary_integrity()
        diagnostics['data_integrity'] = validation
    except Exception as e:
        diagnostics['data_integrity'] = {'error': str(e)}
    
    # Generate recommendations
    recommendations = []
    
    # File recommendations
    if not diagnostics['file_status']['all_recipients.json']['exists']:
        recommendations.append("Consider fetching recipient data to improve matching accuracy")
    
    # Data recommendations
    if diagnostics['summary_stats'].get('ai_response_rate', 0) < 50:
        recommendations.append("Low AI response rate - check OpenAI API configuration")
    
    if diagnostics['data_integrity'].get('issue_count', 0) > 0:
        recommendations.append("Data integrity issues detected - run data cleanup")
    
    if diagnostics['summary_stats'].get('total_entities', 0) == 0:
        recommendations.append("No entities in summary - process some queries to populate data")
    
    # Performance recommendations
    summary_size = diagnostics['file_status'].get('summary.json', {}).get('size_mb', 0)
    if summary_size > 50:
        recommendations.append("Large summary file detected - consider cleaning old entries")
    
    # System recommendations
    if diagnostics['summary_stats'].get('total_spending', 0) > 0:
        recommendations.append(f"Total spending tracked: ${diagnostics['summary_stats']['total_spending']:,.2f}")
    
    # FIXED: Add cleanup recommendations
    if cleanup_count > 0:
        recommendations.append(f"Auto-cleanup removed {cleanup_count} old backup files")
    else:
        recommendations.append("Auto-cleanup enabled - no old backup files found")
    
    # Fiscal year recommendations
    recommendations.append("Fiscal year filtering enabled - all date filtering uses US Federal Fiscal Year (Oct 1 - Sep 30)")
    
    diagnostics['recommendations'] = recommendations
    
    logging.info("✅ Diagnostics complete with auto-cleanup and fiscal year support")
    return diagnostics

def get_performance_metrics() -> Dict[str, Any]:
    """
    FIXED: Get performance metrics for the system with cleanup tracking
    """
    # FIXED: Track cleanup performance
    cleanup_start = time.time()
    cleanup_count = auto_cleanup_backup_files(max_age_hours=24)
    cleanup_time = time.time() - cleanup_start
    
    summary = load_summary_data()
    
    metrics = {
        'data_processing': {
            'total_entities': len(summary),
            'entities_per_hour': 0,
            'average_processing_time': 0,
            'success_rate': 0
        },
        'api_usage': {
            'total_api_calls': 0,
            'successful_calls': 0,
            'failed_calls': 0
        },
        'storage': {
            'summary_size_mb': 0,
            'total_records': 0,
            'average_records_per_entity': 0
        },
        'financial_metrics': {
            'total_spending_tracked': 0,
            'average_spending_per_entity': 0,
            'largest_transaction': 0
        },
        'system_performance': {  # FIXED: Add cleanup metrics
            'backup_files_cleaned': cleanup_count,
            'cleanup_time_seconds': cleanup_time,
            'auto_cleanup_enabled': True,
            'fiscal_year_support': True
        }
    }
    
    try:
        # Calculate processing metrics
        processing_times = []
        successful_entities = 0
        total_spending = 0
        largest_transaction = 0
        
        for key, value in summary.items():
            if value.get('timestamp'):
                processing_times.append(value['timestamp'])
            
            if value.get('processed', False):
                successful_entities += 1
            
            # Calculate financial metrics
            data = value.get('data', [])
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict):
                        amount = item.get('amount', 0)
                        if isinstance(amount, (int, float)):
                            total_spending += amount
                            largest_transaction = max(largest_transaction, amount)
        
        if processing_times:
            processing_times.sort()
            if len(processing_times) > 1:
                time_span = processing_times[-1] - processing_times[0]
                metrics['data_processing']['entities_per_hour'] = len(processing_times) / (time_span / 3600) if time_span > 0 else 0
        
        metrics['data_processing']['success_rate'] = (successful_entities / len(summary) * 100) if summary else 0
        
        # Calculate storage metrics
        if os.path.exists('summary.json'):
            metrics['storage']['summary_size_mb'] = os.path.getsize('summary.json') / (1024 * 1024)
        
        stats = get_entity_statistics()
        metrics['storage']['total_records'] = stats.get('total_records', 0)
        metrics['storage']['average_records_per_entity'] = stats.get('average_records_per_entity', 0)
        
        # Financial metrics
        metrics['financial_metrics']['total_spending_tracked'] = total_spending
        metrics['financial_metrics']['average_spending_per_entity'] = total_spending / len(summary) if summary else 0
        metrics['financial_metrics']['largest_transaction'] = largest_transaction
        
    except Exception as e:
        logging.error(f"❌ Error calculating performance metrics: {e}")
        metrics['system_performance']['error'] = str(e)
    
    return metrics

if __name__ == "__main__":
    # FIXED: Run diagnostics with cleanup when script is executed directly
    results = run_diagnostics()
    print(json.dumps(results, indent=2))