"""
FIXED recipient_processor.py with CORRECT USA Spending API endpoints and proper data fetching
FIXED: Uses correct award search endpoints and proper payload structures
FIXED: Enhanced fiscal year filtering at API level and post-processing level
FIXED: Award type filtering - now properly uses award types from query instead of hardcoded grants
"""

import json
import os
import requests
import logging
import time
import math
import glob  # FIXED: Added for backup cleanup
import re    # FIXED: Added for pattern matching
from datetime import datetime, timedelta
from difflib import get_close_matches
from typing import List, Dict, Any, Optional

class USASpendingAPI:
    def __init__(self):
        self.base_url = "https://api.usaspending.gov/api/v2"
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'USA-Spending-Data-Retriever/2.0'
        })
    
    def get_award_type_codes(self, award_types):
        """FIXED: Convert award types to API codes"""
        try:
            type_mapping = {
                'contracts': ['A', 'B', 'C', 'D'],
                'grants': ['02', '03', '04', '05'],
                'loans': ['07', '08'],
                'all': ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
            }
            
            if not isinstance(award_types, list):
                award_types = ['all']
            
            codes = []
            for award_type in award_types:
                if isinstance(award_type, str):
                    codes.extend(type_mapping.get(award_type.lower(), type_mapping['all']))
            
            # Remove duplicates
            codes = list(set(codes))
            logging.info(f"🎯 Award types {award_types} mapped to codes: {codes}")
            return codes
        except Exception as e:
            logging.error(f"❌ Error getting award type codes: {e}")
            return ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
    
    def convert_fiscal_year_to_date_range(self, fiscal_year):
        """
        ENHANCED: Convert fiscal year to actual date range with better error handling
        FY 2022 = Oct 1, 2021 to Sep 30, 2022
        """
        try:
            fy = int(fiscal_year)
            start_date = datetime(fy-1, 10, 1)  # October 1 of previous calendar year
            end_date = datetime(fy, 9, 30)      # September 30 of fiscal year
            return start_date, end_date
        except (ValueError, TypeError):
            # Fallback to current date range if conversion fails
            end_date = datetime.now()
            start_date = end_date - timedelta(days=365)
            return start_date, end_date

    def get_fiscal_year_date_range(self, fiscal_years):
        """
        ENHANCED: Get the overall date range covering all specified fiscal years
        """
        if not fiscal_years:
            # Default to last 10 years if no specific years
            end_date = datetime.now()
            start_date = end_date - timedelta(days=3650)
            return start_date, end_date
        
        # Convert all fiscal years and find min start and max end
        start_dates = []
        end_dates = []
        
        for fy in fiscal_years:
            start_date, end_date = self.convert_fiscal_year_to_date_range(fy)
            start_dates.append(start_date)
            end_dates.append(end_date)
        
        return min(start_dates), max(end_dates)
    
    def is_date_in_fiscal_year_range(self, date_str, fiscal_years):
        """
        ENHANCED: Check if a date falls within any of the specified fiscal years
        """
        if not fiscal_years or not date_str:
            return True  # Include if no filtering needed
        
        try:
            # Parse the date with enhanced format support
            if isinstance(date_str, str) and len(date_str) >= 8:
                # Handle ISO datetime format (e.g., "2022-03-15T10:30:00Z")
                if 'T' in date_str:
                    test_date = date_str.split('T')[0]  # YYYY-MM-DD format
                # Handle hyphen-separated dates (YYYY-MM-DD)
                elif '-' in date_str and len(date_str.split('-')) == 3:
                    test_date = date_str.split(' ')[0]  # Remove any time component
                # Handle slash-separated dates
                elif '/' in date_str:
                    parts = date_str.split('/')
                    if len(parts) >= 3:
                        if len(parts[2]) == 4:  # MM/DD/YYYY format
                            month, day, year = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                            test_date = f"{year}-{month}-{day}"
                        elif len(parts[0]) == 4:  # YYYY/MM/DD format
                            year, month, day = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                            test_date = f"{year}-{month}-{day}"
                        else:  # DD/MM/YY format
                            day, month, year = parts[0].zfill(2), parts[1].zfill(2), f"20{parts[2]}"
                            test_date = f"{year}-{month}-{day}"
                    else:
                        return True  # Can't parse, include it
                else:
                    test_date = date_str[:10]  # Take first 10 characters
            else:
                return True  # Invalid date, include it
            
            # Check if date falls in any fiscal year range
            for fy in fiscal_years:
                try:
                    fy_int = int(fy)
                    fy_start = f"{fy_int-1}-10-01"  # Oct 1 of previous year
                    fy_end = f"{fy_int}-09-30"      # Sep 30 of fiscal year
                    
                    if fy_start <= test_date <= fy_end:
                        return True
                except (ValueError, TypeError):
                    continue
            
            return False  # Date doesn't fall in any specified fiscal year
            
        except Exception as e:
            logging.warning(f"⚠️ Error checking date {date_str} against fiscal years: {e}")
            return True  # Include if we can't determine
    
    def search_awards_by_recipient_name(self, recipient_name: str, limit: int = 50, fiscal_years: List[str] = None, award_type_codes: List[str] = None) -> List[Dict]:
        """FIXED: Use correct award search endpoint with proper payload structure"""
        # FIXED: More lenient validation - only reject obviously invalid names
        if not recipient_name or len(recipient_name.strip()) < 2:
            logging.warning(f"❌ LENIENT: Invalid recipient name format: '{recipient_name}'")
            return []
        
        # FIXED: Use award type codes from query or default to all
        if not award_type_codes:
            award_type_codes = self.get_award_type_codes(['all'])
        
        logging.info(f"🎯 Searching awards by recipient name with award types: {award_type_codes}")
        
        # FIXED: Use the correct award search endpoint
        endpoint = f"{self.base_url}/search/spending_by_award/"
        
        # ENHANCED: Use fiscal year date range with logging
        if fiscal_years:
            start_date, end_date = self.get_fiscal_year_date_range(fiscal_years)
            logging.info(f"🗓️ Award search using fiscal year range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
            
            # Log individual fiscal year ranges for clarity
            for fy in fiscal_years:
                try:
                    fy_int = int(fy)
                    fy_start = f"{fy_int-1}-10-01"
                    fy_end = f"{fy_int}-09-30"
                    logging.info(f"   FY{fy}: {fy_start} to {fy_end}")
                except:
                    logging.warning(f"   FY{fy}: Invalid format")
        else:
            # Default to last 5 years
            end_date = datetime.now()
            start_date = end_date - timedelta(days=1825)  # 5 years
            logging.info(f"🗓️ Award search using default date range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        
        # FIXED: Use correct payload structure for USA Spending API
        payload = {
            "filters": {
                "award_type_codes": award_type_codes,
                "time_period": [
                    {
                        "start_date": start_date.strftime("%Y-%m-%d"),
                        "end_date": end_date.strftime("%Y-%m-%d")
                    }
                ],
                "recipient_search_text": [recipient_name]  # FIXED: Use correct field for recipient search
            },
            "fields": [
                "Award ID", "Recipient Name", "Award Amount", "Award Type", "Awarding Agency", 
                "Action Date", "Start Date", "End Date", "Description", "Total Outlays"
            ],
            "page": 1,
            "limit": min(limit, 100),  # API limit is 100
            "sort": "Award Amount",
            "order": "desc"
        }
        
        all_awards = []
        
        try:
            # Search multiple pages for comprehensive results
            for page in range(1, 11):  # Check first 5 pages
                payload["page"] = page
                logging.info(f"Searching awards page {page} for '{recipient_name}' with award types {award_type_codes}...")
                
                response = self.session.post(endpoint, json=payload)
                response.raise_for_status()
                
                data = response.json()
                results = data.get("results", [])
                
                if not results:
                    logging.info(f"No more results on page {page}")
                    break
                
                # ENHANCED: Filter and process results
                page_matches = 0
                for result in results:
                    recipient_name_full = result.get("Recipient Name", "")
                    action_date = result.get("Action Date", "")
                    
                    # ENHANCED: Use lenient matching criteria
                    if self._lenient_name_match(recipient_name, recipient_name_full):
                        # ENHANCED: Additional fiscal year filtering at result level
                        if fiscal_years:
                            if self.is_date_in_fiscal_year_range(action_date, fiscal_years):
                                page_matches += 1
                                result["fiscal_year_filtered"] = True
                                result["award_type_codes_used"] = award_type_codes
                                all_awards.append(result)
                            else:
                                logging.debug(f"Excluded result with action_date {action_date} (not in fiscal years {fiscal_years})")
                        else:
                            # No fiscal year filtering
                            page_matches += 1
                            result["fiscal_year_filtered"] = False
                            result["award_type_codes_used"] = award_type_codes
                            all_awards.append(result)
                
                logging.info(f"Page {page}: Found {page_matches} matching awards out of {len(results)} total (award types: {award_type_codes})")
                time.sleep(0.5)  # Rate limiting
                
                # If we found enough awards, we can stop
                if len(all_awards) >= limit:
                    break
            
            logging.info(f"Total awards found: {len(all_awards)} (fiscal year filtered: {bool(fiscal_years)}, award types: {award_type_codes})")
            return all_awards
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 422:
                logging.warning(f"API request format error (422): Trying alternative search method")
                return self._fallback_award_search(recipient_name, fiscal_years, award_type_codes, limit)
            else:
                logging.error(f"HTTP Error searching awards: {e}")
            return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Error searching awards: {e}")
            return []
    
    def _fallback_award_search(self, recipient_name: str, fiscal_years: List[str] = None, award_type_codes: List[str] = None, limit: int = 50) -> List[Dict]:
        """FIXED: Fallback method using recipient search endpoint"""
        try:
            endpoint = f"{self.base_url}/recipient/"
            
            # Search for recipients first
            params = {
                "keyword": recipient_name,
                "award_type": "all",
                "limit": 50
            }
            
            response = self.session.get(endpoint, params=params)
            response.raise_for_status()
            
            data = response.json()
            recipients = data.get("results", [])
            
            all_awards = []
            
            for recipient in recipients:
                recipient_id = recipient.get("recipient_id")
                recipient_name_full = recipient.get("recipient_name", "")
                
                if self._lenient_name_match(recipient_name, recipient_name_full) and recipient_id:
                    # Get awards for this recipient
                    awards = self._get_awards_for_recipient(recipient_id, fiscal_years, award_type_codes)
                    all_awards.extend(awards)
                    
                    if len(all_awards) >= limit:
                        break
            
            logging.info(f"Fallback search found {len(all_awards)} awards")
            return all_awards[:limit]
            
        except Exception as e:
            logging.error(f"Error in fallback award search: {e}")
            return []
    
    def _get_awards_for_recipient(self, recipient_id: str, fiscal_years: List[str] = None, award_type_codes: List[str] = None) -> List[Dict]:
        """FIXED: Get awards for a specific recipient ID"""
        try:
            endpoint = f"{self.base_url}/search/spending_by_award/"
            
            if fiscal_years:
                start_date, end_date = self.get_fiscal_year_date_range(fiscal_years)
            else:
                end_date = datetime.now()
                start_date = end_date - timedelta(days=1825)  # 5 years
            
            if not award_type_codes:
                award_type_codes = self.get_award_type_codes(['all'])
            
            payload = {
                "filters": {
                    "recipient_id": recipient_id,
                    "award_type_codes": award_type_codes,
                    "time_period": [
                        {
                            "start_date": start_date.strftime("%Y-%m-%d"),
                            "end_date": end_date.strftime("%Y-%m-%d")
                        }
                    ]
                },
                "fields": [
                    "Award ID", "Recipient Name", "Award Amount", "Award Type", "Awarding Agency", 
                    "Action Date", "Start Date", "End Date", "Description", "Total Outlays"
                ],
                "page": 1,
                "limit": 100,
                "sort": "Award Amount",
                "order": "desc"
            }
            
            response = self.session.post(endpoint, json=payload)
            response.raise_for_status()
            
            data = response.json()
            results = data.get("results", [])
            
            # Mark results with metadata
            for result in results:
                result["fiscal_year_filtered"] = bool(fiscal_years)
                result["award_type_codes_used"] = award_type_codes
            
            return results
            
        except Exception as e:
            logging.error(f"Error getting awards for recipient {recipient_id}: {e}")
            return []
    
    def _lenient_name_match(self, search_name: str, full_name: str) -> bool:
        """FIXED: More lenient name matching to avoid false negatives"""
        if not search_name or not full_name:
            return False
        
        search_lower = search_name.lower().strip()
        full_lower = full_name.lower().strip()
        
        # Exact match
        if search_lower == full_lower:
            return True
        
        # Check if search name is contained in full name
        if search_lower in full_lower:
            return True
        
        # Check word overlap - more lenient than before
        search_words = set(search_lower.split())
        full_words = set(full_lower.split())
        
        # Remove common words
        common_words = {'the', 'of', 'and', 'for', 'in', 'on', 'at', 'to', 'a', 'an'}
        search_words -= common_words
        full_words -= common_words
        
        if not search_words or not full_words:
            return False
        
        # Require at least 40% of search words to be found (more lenient)
        if len(search_words) > 1:
            found_words = sum(1 for word in search_words if any(word in full_word for full_word in full_words))
            return (found_words / len(search_words)) >= 0.4
        else:
            # For single word searches, require it to be found somewhere
            return any(search_words.pop() in full_word for full_word in full_words)
    
    def get_award_details_by_id(self, award_id: str) -> Dict:
        """FIXED: Get detailed information about a specific award"""
        try:
            endpoint = f"{self.base_url}/awards/{award_id}/"
            
            response = self.session.get(endpoint)
            response.raise_for_status()
            
            data = response.json()
            return data
            
        except Exception as e:
            logging.error(f"Error getting award details for {award_id}: {e}")
            return {}
    
    def search_transactions_by_award_id(self, award_id: str, limit: int = 100) -> List[Dict]:
        """FIXED: Get transactions for a specific award ID"""
        try:
            endpoint = f"{self.base_url}/awards/{award_id}/transactions/"
            
            params = {
                "limit": limit,
                "page": 1,
                "sort": "action_date",
                "order": "desc"
            }
            
            response = self.session.get(endpoint, params=params)
            response.raise_for_status()
            
            data = response.json()
            results = data.get("results", [])
            
            logging.info(f"Found {len(results)} transactions for award {award_id}")
            return results
            
        except Exception as e:
            logging.error(f"Error getting transactions for award {award_id}: {e}")
            return []

class RecipientDataRetriever:
    def __init__(self):
        self.api = USASpendingAPI()
    
    def _names_match(self, name1: str, name2: str) -> bool:
        """FIXED: More lenient name matching for entity comparison"""
        if not name1 or not name2:
            return False
        
        # FIXED: Make comparison case-insensitive and more lenient
        name1_words = set(name1.lower().split())
        name2_words = set(name2.lower().split())
        
        # Remove common words
        common_words = {'of', 'the', 'and', 'for', 'in', 'at', 'on', 'a', 'an'}
        name1_words -= common_words
        name2_words -= common_words
        
        # FIXED: Require more reasonable overlap (50% instead of 70%)
        if len(name1_words & name2_words) >= max(1, min(len(name1_words), len(name2_words)) * 0.5):
            return True
        
        return False
    
    def calculate_financial_summary(self, awards: List[Dict]) -> Dict:
        """
        ENHANCED: Calculate comprehensive financial summary from awards data
        """
        total_awarded = 0
        total_spent = 0
        award_count = len(awards)
        
        for award in awards:
            # Award amount is the total amount awarded
            award_amount = award.get('Award Amount', 0) or 0
            if isinstance(award_amount, str):
                # Clean string amounts
                award_amount = award_amount.replace(',', '').replace('$', '').replace(' ', '')
                try:
                    award_amount = float(award_amount)
                except (ValueError, TypeError):
                    award_amount = 0
            elif award_amount is None:
                award_amount = 0
            
            # Total Outlays represents amount actually spent/disbursed
            outlays = award.get('Total Outlays', 0) or 0
            if isinstance(outlays, str):
                # Clean string amounts
                outlays = outlays.replace(',', '').replace('$', '').replace(' ', '')
                try:
                    outlays = float(outlays)
                except (ValueError, TypeError):
                    outlays = 0
            elif outlays is None:
                outlays = 0
            
            total_awarded += award_amount
            total_spent += outlays
        
        remaining_amount = total_awarded - total_spent
        spending_percentage = (total_spent / total_awarded * 100) if total_awarded > 0 else 0
        
        return {
            "total_amount_awarded": total_awarded,
            "total_amount_spent": total_spent,
            "remaining_amount": remaining_amount,
            "spending_percentage": round(spending_percentage, 2),
            "total_awards_count": award_count
        }

    def analyze_spending_patterns(self, awards: List[Dict], sample_size: int = 5) -> Dict:
        """
        ENHANCED: Analyze spending patterns to detect if 100% spending is suspicious
        """
        analysis = {
            "total_awards_analyzed": len(awards),
            "sample_size": min(sample_size, len(awards)),
            "awards_with_100_percent_spending": 0,
            "awards_with_remaining_balance": 0,
            "suspicious_pattern_detected": False,
            "average_spending_percentage": 0,
            "data_quality_issues": []
        }
        
        try:
            spending_percentages = []
            
            for award in awards[:sample_size]:
                # Basic calculation from current data
                basic_awarded = float(award.get('Award Amount', 0) or 0)
                basic_spent = float(award.get('Total Outlays', 0) or 0)
                basic_percentage = (basic_spent / basic_awarded * 100) if basic_awarded > 0 else 0
                
                # Count spending patterns
                if abs(basic_percentage - 100.0) < 0.01:
                    analysis["awards_with_100_percent_spending"] += 1
                else:
                    analysis["awards_with_remaining_balance"] += 1
                
                spending_percentages.append(basic_percentage)
            
            # Calculate average spending percentage
            if spending_percentages:
                analysis["average_spending_percentage"] = sum(spending_percentages) / len(spending_percentages)
            
            # Detect suspicious patterns
            if analysis["awards_with_100_percent_spending"] / analysis["sample_size"] > 0.8:
                analysis["suspicious_pattern_detected"] = True
                analysis["data_quality_issues"].append("More than 80% of awards show exactly 100% spending - this is statistically unlikely")
            
            if analysis["average_spending_percentage"] > 95:
                analysis["data_quality_issues"].append("Average spending percentage is unusually high (>95%)")
                analysis["data_quality_issues"].append("Total Outlays field may represent cumulative disbursements rather than current spending status")
            
        except Exception as e:
            logging.error(f"Error analyzing spending patterns: {e}")
            analysis["data_quality_issues"].append(f"Error during analysis: {str(e)}")
        
        return analysis
    
    def debug_search_with_fiscal_years(self, recipient_name: str, fiscal_years: List[str] = None, award_type_codes: List[str] = None) -> Dict:
        """ENHANCED: Debug method with CORRECT API usage and CONSISTENT fiscal year filtering and FIXED award type filtering"""
        logging.info(f"DEBUG: Searching for '{recipient_name}' using CORRECT API endpoints and FISCAL YEAR filtering with award types: {award_type_codes}...")
        
        # FIXED: More lenient validation
        if not recipient_name or len(recipient_name.strip()) < 2:
            return {
                "search_query": recipient_name,
                "error": f"Invalid recipient name format: '{recipient_name}'. Name must be at least 2 characters.",
                "search_results": [],
                "retrieval_date": datetime.now().isoformat(),
                "debug_mode": True,
                "lenient_validation": True,
                "fiscal_years": fiscal_years,
                "award_type_codes": award_type_codes,
                "data": {
                    "all_recipients": [],
                    "combined_awards": [],
                    "combined_transactions": [],
                    "summary": {
                        "total_recipients_processed": 0,
                        "total_awards": 0,
                        "total_transactions": 0,
                        "validation_error": f"Invalid recipient name: {recipient_name}"
                    }
                }
            }
        
        # FIXED: Use award type codes from query or default to all
        if not award_type_codes:
            award_type_codes = self.api.get_award_type_codes(['all'])
        
        # FIXED: Method 1 - Use CORRECT award search endpoint
        logging.info(f"\nDEBUG: Method 1 - Using CORRECT award search endpoint with FISCAL YEAR filtering and award types: {award_type_codes}...")
        if fiscal_years:
            # FIXED: Better logging for large year ranges
            if len(fiscal_years) > 10:
                logging.info(f"DEBUG: Filtering by EXPANDED fiscal year range: FY{fiscal_years[0]} to FY{fiscal_years[-1]} ({len(fiscal_years)} years)")
                logging.info(f"DEBUG: This covers October 1, {int(fiscal_years[0])-1} to September 30, {fiscal_years[-1]}")
            else:
                logging.info(f"DEBUG: Filtering by fiscal years: {fiscal_years}")
                # Show fiscal year date ranges for smaller ranges
                for fy in fiscal_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        logging.info(f"DEBUG: FY {fy} = {start_date} to {end_date}")
                    except:
                        logging.info(f"DEBUG: FY {fy} (invalid format)")
        
        # FIXED: Use the corrected award search method
        awards = self.api.search_awards_by_recipient_name(recipient_name, fiscal_years=fiscal_years, award_type_codes=award_type_codes)
        logging.info(f"DEBUG: Found {len(awards)} awards using CORRECT API endpoint with award types {award_type_codes}")
        
        if awards:
            logging.info("DEBUG: Sample awards:")
            for award in awards[:5]:
                amount = award.get('Award Amount', 0)
                action_date = award.get('Action Date', 'Unknown')
                fiscal_filtered = award.get('fiscal_year_filtered', False)
                award_types_used = award.get('award_type_codes_used', [])
                logging.info(f"  - {award.get('Award ID')}: ${float(amount or 0):,.2f} - {award.get('Recipient Name')} - {action_date} (FY filtered: {fiscal_filtered}, Award types: {award_types_used})")
        
        # FIXED: Method 2 - Get detailed award information
        detailed_awards = []
        if awards:
            logging.info(f"\nDEBUG: Method 2 - Getting detailed award information...")
            for award in awards[:5]:  # Limit to first 5 for testing
                award_id = award.get('Award ID')
                if award_id:
                    award_details = self.api.get_award_details_by_id(award_id)
                    if award_details:
                        detailed_awards.append(award_details)
            
            logging.info(f"DEBUG: Retrieved detailed information for {len(detailed_awards)} awards")
        
        # FIXED: Method 3 - Get transaction data for sample awards
        transactions = []
        if awards:
            logging.info(f"\nDEBUG: Method 3 - Getting transaction data for sample awards...")
            for award in awards[:3]:  # Limit to first 3 for testing
                award_id = award.get('Award ID')
                if award_id:
                    award_transactions = self.api.search_transactions_by_award_id(award_id)
                    transactions.extend(award_transactions)
            
            logging.info(f"DEBUG: Found {len(transactions)} total transactions")
        
        # Create recipients summary from awards
        recipients = []
        if awards:
            recipient_dict = {}
            for award in awards:
                name = award.get('Recipient Name', '').strip()
                if name:
                    name_key = name.lower()
                    if name_key not in recipient_dict:
                        recipient_dict[name_key] = {
                            "recipient_name": name,
                            "recipient_id": f"from_awards_{len(recipient_dict)}",
                            "amount": float(award.get('Award Amount', 0) or 0),
                            "award_count": 1,
                            "sample_award_id": award.get('Award ID', ''),
                            "action_date": award.get('Action Date', 'Unknown'),
                            "fiscal_year_filtered": award.get('fiscal_year_filtered', False),
                            "award_type_codes_used": award.get('award_type_codes_used', award_type_codes)
                        }
                    else:
                        recipient_dict[name_key]["amount"] += float(award.get('Award Amount', 0) or 0)
                        recipient_dict[name_key]["award_count"] += 1
            
            recipients = list(recipient_dict.values())
            logging.info(f"DEBUG: Created {len(recipients)} recipients from award search with award types {award_type_codes}")
        
        # ENHANCED: Calculate financial summary and spending analysis with fiscal year info
        financial_summary = self.calculate_financial_summary(awards)
        spending_analysis = self.analyze_spending_patterns(awards, sample_size=5)
        
        # Add fiscal year information to spending analysis
        if fiscal_years:
            spending_analysis['fiscal_years_analyzed'] = fiscal_years
            spending_analysis['fiscal_year_date_ranges'] = []
            
            # FIXED: Better handling for large year ranges
            if len(fiscal_years) > 10:
                spending_analysis['fiscal_year_date_ranges'].append(f"FY {fiscal_years[0]} to FY {fiscal_years[-1]} ({len(fiscal_years)} years)")
                spending_analysis['fiscal_year_date_ranges'].append(f"Period: October 1, {int(fiscal_years[0])-1} to September 30, {fiscal_years[-1]}")
            else:
                for fy in fiscal_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        spending_analysis['fiscal_year_date_ranges'].append(f"FY {fy}: {start_date} to {end_date}")
                    except:
                        spending_analysis['fiscal_year_date_ranges'].append(f"FY {fy}: Invalid format")
        
        # FIXED: Add award type information to spending analysis
        spending_analysis['award_types_analyzed'] = award_type_codes
        spending_analysis['award_type_filtering_applied'] = bool(award_type_codes)
        
        debug_result = {
            "search_query": recipient_name,
            "search_results": recipients,
            "retrieval_date": datetime.now().isoformat(),
            "debug_mode": True,
            "lenient_validation": True,
            "fiscal_years": fiscal_years,
            "fiscal_year_filtering_applied": bool(fiscal_years),
            "award_type_codes": award_type_codes,
            "award_type_filtering_applied": bool(award_type_codes),
            "financial_summary": financial_summary,
            "spending_analysis": spending_analysis,
            "api_endpoints_used": ["search_awards_by_recipient_name", "get_award_details_by_id", "search_transactions_by_award_id"],
            "data": {
                "all_recipients": recipients,
                "combined_awards": awards,
                "combined_transactions": transactions,
                "detailed_awards": detailed_awards,
                "summary": {
                    "total_recipients_processed": len(recipients),
                    "total_awards": len(awards),
                    "total_transactions": len(transactions),
                    "total_award_amount": financial_summary.get("total_amount_awarded", 0),
                    "total_transaction_amount": sum(float(t.get('transaction_amount', 0) or 0) for t in transactions),
                    "total_amount_spent": financial_summary.get("total_amount_spent", 0),
                    "remaining_amount": financial_summary.get("remaining_amount", 0),
                    "spending_percentage": financial_summary.get("spending_percentage", 0),
                    "recipient_names": [r.get("recipient_name", "") for r in recipients],
                    "lenient_validation_applied": True,
                    "fiscal_year_filtering_applied": bool(fiscal_years),
                    "fiscal_years_searched": fiscal_years if fiscal_years else [],
                    "award_type_codes_used": award_type_codes,
                    "award_type_filtering_applied": bool(award_type_codes),
                    "correct_api_endpoints_used": True
                }
            }
        }
        
        # Add fiscal year summary to debug output
        if fiscal_years:
            logging.info(f"\nDEBUG: FISCAL YEAR SUMMARY:")
            logging.info(f"  Fiscal Years Searched: {fiscal_years}")
            
            # FIXED: Better logging for large year ranges
            if len(fiscal_years) > 10:
                logging.info(f"  EXPANDED RANGE: FY{fiscal_years[0]} to FY{fiscal_years[-1]} ({len(fiscal_years)} years)")
                logging.info(f"  Period covered: October 1, {int(fiscal_years[0])-1} to September 30, {fiscal_years[-1]}")
            else:
                for fy in fiscal_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        logging.info(f"  FY {fy}: {start_date} to {end_date}")
                    except:
                        logging.info(f"  FY {fy}: Invalid format")
            
            # Count awards by fiscal year
            awards_by_fy = {}
            for award in awards:
                action_date = award.get('Action Date', '')
                if action_date:
                    for fy in fiscal_years:
                        if self.api.is_date_in_fiscal_year_range(action_date, [fy]):
                            awards_by_fy[fy] = awards_by_fy.get(fy, 0) + 1
                            break
            
            logging.info(f"  Awards by Fiscal Year: {awards_by_fy}")
            debug_result["awards_by_fiscal_year"] = awards_by_fy
        
        # FIXED: Add award type summary to debug output
        if award_type_codes:
            logging.info(f"\nDEBUG: AWARD TYPE SUMMARY:")
            logging.info(f"  Award Types Searched: {award_type_codes}")
            
            # Count awards by type
            awards_by_type = {}
            for award in awards:
                award_type = award.get('Award Type', 'Unknown')
                awards_by_type[award_type] = awards_by_type.get(award_type, 0) + 1
            
            logging.info(f"  Awards by Type: {awards_by_type}")
            debug_result["awards_by_type"] = awards_by_type
        
        # FIXED: Better logging for large year ranges
        logging.info(f"\nDEBUG: FINAL SUMMARY:")
        logging.info(f"  Total Recipients: {len(recipients)}")
        logging.info(f"  Total Awards: {len(awards)}")
        logging.info(f"  Total Transactions: {len(transactions)}")
        logging.info(f"  Total Award Amount: ${financial_summary.get('total_amount_awarded', 0):,.2f}")
        logging.info(f"  Total Amount Spent: ${financial_summary.get('total_amount_spent', 0):,.2f}")
        logging.info(f"  Remaining Amount: ${financial_summary.get('remaining_amount', 0):,.2f}")
        logging.info(f"  Average Spending %: {financial_summary.get('spending_percentage', 0):.1f}%")
        
        if fiscal_years:
            if len(fiscal_years) > 10:
                logging.info(f"  Fiscal Year Filtering: Applied (FY{fiscal_years[0]} to FY{fiscal_years[-1]}, {len(fiscal_years)} years)")
            else:
                logging.info(f"  Fiscal Year Filtering: Applied ({len(fiscal_years)} years: {fiscal_years})")
        else:
            logging.info(f"  Fiscal Year Filtering: Not Applied")
        
        logging.info(f"  Award Type Filtering: {'Applied' if award_type_codes else 'Not Applied'}")
        logging.info(f"  Award Types Used: {award_type_codes}")
        logging.info(f"  CORRECT API Endpoints Used: True")
        
        return debug_result

class RecipientProcessor:
    def __init__(self):
        self.all_recipients_file = "final_results.json"
        self.recipients_cache = None
        self.base_url = "https://api.usaspending.gov/api/v2"
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json',
            'User-Agent': 'USA-Spending-Data-Retriever/2.0'
        })
        self.load_recipients_cache()
    
    def get_award_type_codes(self, award_types):
        """FIXED: Convert award types to API codes - duplicated for compatibility"""
        try:
            type_mapping = {
                'contracts': ['A', 'B', 'C', 'D'],
                'grants': ['02', '03', '04', '05'],
                'loans': ['07', '08'],
                'all': ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
            }
            
            if not isinstance(award_types, list):
                award_types = ['all']
            
            codes = []
            for award_type in award_types:
                if isinstance(award_type, str):
                    codes.extend(type_mapping.get(award_type.lower(), type_mapping['all']))
            
            return list(set(codes))
        except Exception as e:
            logging.error(f"❌ Error getting award type codes: {e}")
            return ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
    
    def load_recipients_cache(self):
        """FIXED: Load recipients data into memory with backup cleanup"""
        try:
            # FIXED: Cleanup old backup files first
            self._cleanup_old_backup_files()
            
            if os.path.exists(self.all_recipients_file):
                # Check if file is empty
                if os.path.getsize(self.all_recipients_file) == 0:
                    logging.warning(f"⚠️ {self.all_recipients_file} is empty, initializing with empty dict")
                    self.recipients_cache = {}
                    self.save_fresh_cache()
                    return
                
                with open(self.all_recipients_file, 'r', encoding='utf-8') as f:
                    try:
                        content = f.read().strip()
                        if not content:
                            logging.warning(f"⚠️ {self.all_recipients_file} contains no content, initializing with empty dict")
                            self.recipients_cache = {}
                            self.save_fresh_cache()
                            return
                        
                        # Try to parse JSON
                        self.recipients_cache = json.loads(content)
                        if not isinstance(self.recipients_cache, dict):
                            # If it's a list or other type, convert to dict
                            logging.warning(f"⚠️ Converting non-dict cache to dict format")
                            if isinstance(self.recipients_cache, list):
                                # Convert list to dict format
                                new_cache = {}
                                for i, item in enumerate(self.recipients_cache):
                                    new_cache[f"item_{i}"] = item
                                self.recipients_cache = new_cache
                            else:
                                self.recipients_cache = {}
                        
                        logging.info(f"✅ Loaded {len(self.recipients_cache)} recipients into cache")
                        
                    except json.JSONDecodeError as json_error:
                        logging.error(f"❌ JSON decode error in {self.all_recipients_file}: {json_error}")
                        logging.info("🔄 Creating backup and initializing fresh cache")
                        
                        # FIXED: Create backup of corrupted file with timestamp
                        backup_file = f"{self.all_recipients_file}.corrupted_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                        try:
                            os.rename(self.all_recipients_file, backup_file)
                            logging.info(f"📁 Corrupted file backed up as: {backup_file}")
                        except Exception as backup_error:
                            logging.error(f"❌ Could not create backup: {backup_error}")
                        
                        # Initialize fresh cache
                        self.recipients_cache = {}
                        self.save_fresh_cache()
                        
            else:
                logging.info(f"📁 {self.all_recipients_file} not found, initializing empty cache")
                self.recipients_cache = {}
                self.save_fresh_cache()
                
        except Exception as e:
            logging.error(f"❌ Error loading recipients cache: {e}")
            logging.info("🔄 Initializing empty cache as fallback")
            self.recipients_cache = {}
    
    def _cleanup_old_backup_files(self, max_age_hours: int = 24):
        """FIXED: Cleanup old backup files related to recipient processing"""
        try:
            current_time = time.time()
            max_age_seconds = max_age_hours * 3600
            
            backup_patterns = [
                "final_results.json.backup_*",
                "final_results.json.corrupted_*",
                "*.recipients_backup_*"
            ]
            
            deleted_count = 0
            
            for pattern in backup_patterns:
                backup_files = glob.glob(pattern)
                
                for backup_file in backup_files:
                    try:
                        file_age = current_time - os.path.getmtime(backup_file)
                        if file_age > max_age_seconds:
                            os.remove(backup_file)
                            deleted_count += 1
                            logging.debug(f"🗑️ Deleted old recipient backup: {backup_file}")
                    except Exception as file_error:
                        logging.warning(f"⚠️ Could not delete backup file {backup_file}: {file_error}")
            
            if deleted_count > 0:
                logging.info(f"✅ Cleaned up {deleted_count} old recipient backup files")
                
        except Exception as e:
            logging.warning(f"⚠️ Error during recipient backup cleanup: {e}")
    
    def save_fresh_cache(self):
        """FIXED: Save a fresh empty cache file with backup"""
        try:
            # FIXED: Create backup of existing file if it exists
            if os.path.exists(self.all_recipients_file):
                backup_name = f"{self.all_recipients_file}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                try:
                    os.rename(self.all_recipients_file, backup_name)
                    logging.debug(f"📁 Backed up existing file to: {backup_name}")
                except Exception as backup_error:
                    logging.warning(f"⚠️ Could not backup existing file: {backup_error}")
            
            fresh_cache = {
                "_metadata": {
                    "description": "USA Spending Recipients Cache",
                    "created": datetime.now().isoformat(),
                    "format_version": "1.0",
                    "lenient_validation_enabled": True,
                    "fiscal_year_support": True,
                    "award_type_filtering_support": True,
                    "correct_api_endpoints_used": True
                }
            }
            
            with open(self.all_recipients_file, 'w', encoding='utf-8') as f:
                json.dump(fresh_cache, f, indent=2, ensure_ascii=False)
            
            logging.info(f"✅ Created fresh cache file with CORRECT API support: {self.all_recipients_file}")
            
        except Exception as e:
            logging.error(f"❌ Error creating fresh cache: {e}")
    
    def process_recipient(self, recipient_name: str, query_details: Dict = None) -> List[Dict[str, Any]]:
        """
        ENHANCED: Process a single recipient with CORRECT API endpoints and CONSISTENT fiscal year filtering and FIXED award type filtering
        """
        # FIXED: More lenient validation - only reject obviously invalid names
        if not recipient_name or len(recipient_name.strip()) < 2:
            logging.error(f"❌ Invalid recipient name: '{recipient_name}' - too short")
            return []
        
        # Check for obviously invalid patterns only
        invalid_patterns = [
            r'^[^a-zA-Z]*$',  # No letters at all
            r'^.{1}$',        # Only 1 character
            r'^[0-9]+$',      # Only numbers
        ]
        
        for pattern in invalid_patterns:
            if re.match(pattern, recipient_name.strip()):
                logging.error(f"❌ Obviously invalid recipient name format: '{recipient_name}'")
                return []
        
        logging.info(f"🔍 Processing recipient with CORRECT API endpoints and CONSISTENT fiscal year filtering and AWARD TYPE filtering: {recipient_name}")
        
        try:
            # Extract fiscal years from query_details
            fiscal_years = query_details.get('year', []) if query_details else []
            
            # FIXED: Extract award types from query_details
            award_types = query_details.get('award_types', ['all']) if query_details else ['all']
            award_type_codes = self.get_award_type_codes(award_types)
            
            logging.info(f"🎯 Award types from query: {award_types} -> codes: {award_type_codes}")
            
            # Step 1: Use CORRECT search methods with CONSISTENT fiscal year filtering and award type filtering
            retriever = RecipientDataRetriever()
            
            # ENHANCED: Always use fiscal year version of debug search with award type filtering and CORRECT API endpoints
            if fiscal_years:
                logging.info(f"📅 Using CORRECT API endpoints with CONSISTENT fiscal year filtering: {fiscal_years}")
                recipient_data = retriever.debug_search_with_fiscal_years(recipient_name, fiscal_years, award_type_codes)
            else:
                logging.info(f"📅 Using CORRECT API endpoints with no fiscal year filtering")
                # Fall back to regular debug search but with more lenient validation and award type filtering
                recipient_data = retriever.debug_search_with_fiscal_years(recipient_name, None, award_type_codes)
            
            # FIXED: Check for validation errors but be more lenient
            if 'error' in recipient_data:
                error_msg = recipient_data['error']
                if "Invalid recipient name format" in error_msg:
                    logging.warning(f"⚠️ LENIENT: {error_msg} - but attempting search anyway")
                    # Try to search anyway with a simpler approach
                    recipient_data = self._simple_search_fallback(recipient_name, fiscal_years, award_type_codes)
                else:
                    logging.error(f"❌ LENIENT: {error_msg}")
                    return []
            
            # Check if recipient_data has the expected structure
            if not recipient_data or not isinstance(recipient_data, dict):
                logging.warning(f"⚠️ No valid data structure returned for recipient: {recipient_name}")
                return []
            
            # Safely access the data with proper error handling
            data_section = recipient_data.get('data', {})
            if not data_section:
                logging.warning(f"⚠️ No 'data' section found for recipient: {recipient_name}")
                return []
            
            # Step 2: Extract enhanced financial data
            financial_summary = recipient_data.get('financial_summary', {})
            spending_analysis = recipient_data.get('spending_analysis', {})
            fiscal_year_info = {
                'fiscal_years_searched': fiscal_years,
                'fiscal_year_filtering_applied': bool(fiscal_years),
                'fiscal_year_filtering_consistent': True,
                'award_types_searched': award_types,
                'award_type_codes_used': award_type_codes,
                'award_type_filtering_applied': bool(award_type_codes and award_type_codes != self.get_award_type_codes(['all'])),
                'correct_api_endpoints_used': True
            }
            
            # Convert debug_search format to system format
            processed_results = []
            
            # Get the data sections with safe defaults
            all_recipients = data_section.get('all_recipients', [])
            combined_awards = data_section.get('combined_awards', [])
            combined_transactions = data_section.get('combined_transactions', [])
            summary_data = data_section.get('summary', {})
            
            logging.info(f"🎯 Found {len(combined_awards)} awards for {recipient_name} using CORRECT API endpoints (LENIENT validation, CONSISTENT fiscal year filtering, award types: {award_types})")
            if fiscal_years:
                logging.info(f"📅 CONSISTENT fiscal year filtering applied: {fiscal_years}")
            if award_types and award_types != ['all']:
                logging.info(f"🎯 Award type filtering applied: {award_types} -> {award_type_codes}")
            logging.info(f"💰 Total Awarded: ${financial_summary.get('total_amount_awarded', 0):,.2f}")
            logging.info(f"💸 Total Spent: ${financial_summary.get('total_amount_spent', 0):,.2f}")
            logging.info(f"💼 Remaining: ${financial_summary.get('remaining_amount', 0):,.2f}")
            
            # Step 3: Create system-compatible records for each award WITH ENHANCED FINANCIAL DATA
            for award in combined_awards:
                try:
                    # Calculate individual award financial metrics
                    award_amount = float(award.get('Award Amount', 0) or 0)
                    amount_spent = float(award.get('Total Outlays', 0) or 0)
                    remaining_amount = award_amount - amount_spent
                    spending_percentage = (amount_spent / award_amount * 100) if award_amount > 0 else 0
                    
                    award_record = {
                        # Basic identification
                        'name': award.get('Recipient Name', recipient_name),
                        'recipient_name': award.get('Recipient Name', recipient_name),
                        'award_id': award.get('Award ID', ''),
                        
                        # ENHANCED: Financial information with detailed breakdown
                        'amount': award_amount,
                        'award_amount': award_amount,
                        'amount_spent': amount_spent,  # Amount actually spent
                        'remaining_amount': remaining_amount,  # Remaining amount
                        'spending_percentage': round(spending_percentage, 2),  # Spending percentage
                        
                        # Award details
                        'award_type': award.get('Award Type', ''),
                        'awarding_agency': award.get('Awarding Agency', ''),
                        'awarding_sub_agency': award.get('Awarding Sub Agency', ''),
                        
                        # Dates
                        'start_date': award.get('Start Date', ''),
                        'end_date': award.get('End Date', ''),
                        'action_date': award.get('Action Date', ''),
                        
                        # Description and additional details
                        'description': award.get('Description', ''),
                        'transaction_count': award.get('transaction_count', 1),
                        
                        # Metadata
                        'source': 'correct_api_award_search_with_lenient_validation_and_consistent_fiscal_year_filtering_and_award_type_filtering',
                        'data_type': 'award',
                        'search_query': recipient_name,
                        'lenient_validation_applied': True,
                        'fiscal_year_info': fiscal_year_info,
                        
                        # ENHANCED: Financial summary information for the recipient
                        'recipient_financial_summary': {
                            'total_amount_awarded': financial_summary.get('total_amount_awarded', 0),
                            'total_amount_spent': financial_summary.get('total_amount_spent', 0),
                            'total_remaining_amount': financial_summary.get('remaining_amount', 0),
                            'overall_spending_percentage': financial_summary.get('spending_percentage', 0),
                            'total_awards_count': financial_summary.get('total_awards_count', 0)
                        },
                        
                        # ENHANCED: Spending analysis information
                        'spending_analysis': spending_analysis,
                        
                        # Full award data for reference
                        'award_data': award,
                        
                        # Summary information
                        'summary_info': {
                            'total_recipients_found': len(all_recipients),
                            'total_awards_found': len(combined_awards),
                            'total_transactions_found': len(combined_transactions),
                            'total_award_amount': summary_data.get('total_award_amount', 0),
                            'total_transaction_amount': summary_data.get('total_transaction_amount', 0),
                            'lenient_validation_applied': summary_data.get('lenient_validation_applied', True),
                            'fiscal_year_filtering_applied': summary_data.get('fiscal_year_filtering_applied', False),
                            'fiscal_years_searched': summary_data.get('fiscal_years_searched', []),
                            'fiscal_year_filtering_consistent': True,
                            'award_type_codes_used': summary_data.get('award_type_codes_used', award_type_codes),
                            'award_type_filtering_applied': summary_data.get('award_type_filtering_applied', False),
                            'correct_api_endpoints_used': True
                        }
                    }
                    
                    processed_results.append(award_record)
                except Exception as award_error:
                    logging.error(f"❌ Error processing award {award.get('Award ID', 'Unknown')}: {award_error}")
                    continue
            
            # Step 4: Create records for transactions (if any) with fiscal year info and award type info
            for transaction in combined_transactions:
                try:
                    transaction_record = {
                        # Basic identification
                        'name': transaction.get('recipient_name', recipient_name),
                        'recipient_name': transaction.get('recipient_name', recipient_name),
                        'transaction_id': transaction.get('transaction_id', ''),
                        'award_id': transaction.get('award_id', ''),
                        
                        # Financial information
                        'amount': float(transaction.get('transaction_amount', 0) or 0),
                        'transaction_amount': float(transaction.get('transaction_amount', 0) or 0),
                        
                        # Transaction details
                        'award_type': transaction.get('award_type', ''),
                        'awarding_agency': transaction.get('awarding_agency_name', ''),
                        'funding_agency': transaction.get('funding_agency_name', ''),
                        
                        # Dates
                        'action_date': transaction.get('action_date', ''),
                        
                        # Description
                        'description': transaction.get('transaction_description', ''),
                        
                        # Metadata
                        'source': 'correct_api_transaction_search_with_lenient_validation_and_consistent_fiscal_year_filtering_and_award_type_filtering',
                        'data_type': 'transaction',
                        'search_query': recipient_name,
                        'lenient_validation_applied': True,
                        'fiscal_year_info': fiscal_year_info,
                        
                        # ENHANCED: Include recipient financial summary
                        'recipient_financial_summary': {
                            'total_amount_awarded': financial_summary.get('total_amount_awarded', 0),
                            'total_amount_spent': financial_summary.get('total_amount_spent', 0),
                            'total_remaining_amount': financial_summary.get('remaining_amount', 0),
                            'overall_spending_percentage': financial_summary.get('spending_percentage', 0),
                            'total_awards_count': financial_summary.get('total_awards_count', 0)
                        },
                        
                        # Full transaction data for reference
                        'transaction_data': transaction,
                        
                        # Summary information
                        'summary_info': summary_data
                    }
                    
                    processed_results.append(transaction_record)
                except Exception as tx_error:
                    logging.error(f"❌ Error processing transaction {transaction.get('transaction_id', 'Unknown')}: {tx_error}")
                    continue
            
            # Step 5: Create recipient summary records WITH ENHANCED FINANCIAL DATA
            for recipient in all_recipients:
                try:
                    recipient_record = {
                        # Basic identification
                        'name': recipient.get('recipient_name', recipient_name),
                        'recipient_name': recipient.get('recipient_name', recipient_name),
                        'recipient_id': recipient.get('recipient_id', ''),
                        
                        # Financial summary - ENHANCED
                        'amount': float(recipient.get('amount', 0) or 0),
                        'total_amount': float(recipient.get('amount', 0) or 0),
                        'award_count': recipient.get('award_count', 0),
                        
                        # ENHANCED: Detailed financial breakdown
                        'total_amount_awarded': financial_summary.get('total_amount_awarded', 0),
                        'total_amount_spent': financial_summary.get('total_amount_spent', 0),
                        'total_remaining_amount': financial_summary.get('remaining_amount', 0),
                        'overall_spending_percentage': financial_summary.get('spending_percentage', 0),
                        
                        # Sample award reference
                        'sample_award_id': recipient.get('sample_award_id', ''),
                        
                        # Metadata
                        'source': 'correct_api_recipient_summary_with_lenient_validation_and_consistent_fiscal_year_filtering_and_award_type_filtering',
                        'data_type': 'recipient_summary',
                        'search_query': recipient_name,
                        'lenient_validation_applied': True,
                        'fiscal_year_info': fiscal_year_info,
                        
                        # ENHANCED: Full financial summary
                        'recipient_financial_summary': financial_summary,
                        'spending_analysis': spending_analysis,
                        
                        # Full recipient data for reference
                        'recipient_data': recipient,
                        
                        # Summary information
                        'summary_info': summary_data
                    }
                    
                    processed_results.append(recipient_record)
                except Exception as recipient_error:
                    logging.error(f"❌ Error processing recipient summary {recipient.get('recipient_name', 'Unknown')}: {recipient_error}")
                    continue
            
            logging.info(f"✅ Successfully processed {len(processed_results)} detailed items using CORRECT API endpoints with LENIENT validation and CONSISTENT fiscal year support and AWARD TYPE filtering")
            logging.info(f"📊 Awards: {len(combined_awards)}, Transactions: {len(combined_transactions)}, Recipients: {len(all_recipients)}")
            logging.info(f"🎯 Award types processed: {award_types} -> {award_type_codes}")
            logging.info(f"🔧 CORRECT API endpoints used: True")
            
            return processed_results
            
        except Exception as e:
            logging.error(f"❌ Error processing recipient {recipient_name} with CORRECT API endpoints and LENIENT validation and CONSISTENT fiscal year filtering and AWARD TYPE filtering: {e}")
            # Return empty list instead of raising exception
            return []
    
    def _simple_search_fallback(self, recipient_name: str, fiscal_years: List[str] = None, award_type_codes: List[str] = None) -> Dict:
        """ENHANCED: Simple fallback search using CORRECT API endpoints with CONSISTENT fiscal year filtering and award type filtering"""
        try:
            logging.info(f"🔄 Attempting simple fallback search using CORRECT API endpoints for: {recipient_name} with award types: {award_type_codes}")
            
            # Create a minimal retriever and try direct API search
            retriever = RecipientDataRetriever()
            
            # Try direct award search with fiscal year filtering and award type filtering
            try:
                awards = retriever.api.search_awards_by_recipient_name(recipient_name, fiscal_years=fiscal_years, award_type_codes=award_type_codes)
                
                if awards:
                    # Create minimal result structure
                    financial_summary = retriever.calculate_financial_summary(awards)
                    
                    return {
                        "search_query": recipient_name,
                        "search_results": [],
                        "retrieval_date": datetime.now().isoformat(),
                        "debug_mode": False,
                        "fallback_search": True,
                        "fiscal_years": fiscal_years,
                        "fiscal_year_filtering_applied": bool(fiscal_years),
                        "fiscal_year_filtering_consistent": True,
                        "award_type_codes": award_type_codes,
                        "award_type_filtering_applied": bool(award_type_codes),
                        "correct_api_endpoints_used": True,
                        "financial_summary": financial_summary,
                        "data": {
                            "all_recipients": [],
                            "combined_awards": awards,
                            "combined_transactions": [],
                            "summary": {
                                "total_recipients_processed": 0,
                                "total_awards": len(awards),
                                "total_transactions": 0,
                                "total_award_amount": financial_summary.get("total_amount_awarded", 0),
                                "fallback_search_used": True,
                                "fiscal_years_searched": fiscal_years or [],
                                "fiscal_year_filtering_consistent": True,
                                "award_type_codes_used": award_type_codes,
                                "award_type_filtering_applied": bool(award_type_codes),
                                "correct_api_endpoints_used": True
                            }
                        }
                    }
                else:
                    logging.warning(f"⚠️ Fallback search found no results for: {recipient_name} with award types: {award_type_codes}")
                    return {
                        "search_query": recipient_name,
                        "search_results": [],
                        "retrieval_date": datetime.now().isoformat(),
                        "debug_mode": False,
                        "fallback_search": True,
                        "fiscal_years": fiscal_years,
                        "fiscal_year_filtering_applied": bool(fiscal_years),
                        "award_type_codes": award_type_codes,
                        "award_type_filtering_applied": bool(award_type_codes),
                        "correct_api_endpoints_used": True,
                        "data": {
                            "all_recipients": [],
                            "combined_awards": [],
                            "combined_transactions": [],
                            "summary": {
                                "total_recipients_processed": 0,
                                "total_awards": 0,
                                "total_transactions": 0,
                                "fallback_search_used": True,
                                "no_results_found": True,
                                "fiscal_year_filtering_consistent": True,
                                "award_type_codes_used": award_type_codes,
                                "award_type_filtering_applied": bool(award_type_codes),
                                "correct_api_endpoints_used": True
                            }
                        }
                    }
                    
            except Exception as api_error:
                logging.error(f"❌ Fallback API search failed: {api_error}")
                return {
                    "search_query": recipient_name,
                    "error": f"Fallback search failed: {str(api_error)}",
                    "data": {"summary": {"fallback_search_failed": True, "correct_api_endpoints_used": True}}
                }
                
        except Exception as e:
            logging.error(f"❌ Simple fallback search failed: {e}")
            return {
                "search_query": recipient_name,
                "error": f"All search methods failed: {str(e)}",
                "data": {"summary": {"all_methods_failed": True, "correct_api_endpoints_used": True}}
            }
    
    def _names_match(self, name1: str, name2: str) -> bool:
        """FIXED: More lenient name matching for entity comparison"""
        if not name1 or not name2:
            return False
        
        # FIXED: Make comparison case-insensitive and more lenient
        name1_words = set(name1.lower().split())
        name2_words = set(name2.lower().split())
        
        # Remove common words
        common_words = {'of', 'the', 'and', 'for', 'in', 'at', 'on', 'a', 'an'}
        name1_words -= common_words
        name2_words -= common_words
        
        # FIXED: Require more reasonable overlap (50% instead of 70%)
        if len(name1_words & name2_words) >= max(1, min(len(name1_words), len(name2_words)) * 0.5):
            return True
        
        return False