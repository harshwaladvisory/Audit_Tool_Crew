#from openai import OpenAI
import openai
import json
import os
import requests 
import time 
import logging
from datetime import datetime
from difflib import get_close_matches
import math
import re
from decimal import Decimal
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
from enhanced_extraction import EnhancedQueryExtractor
from recipient_processor import RecipientProcessor
from data_validator import DataValidator
from additional_utils import *
from output_xl1 import export_dynamic_json_to_excel_bytes
import io

# Import app from app.py
from app import app

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

# File paths
ALL_RECIPIENTS_FILE = "all_recipients.json"
QUERY_OUTPUT_FILE = "final_results.json"
SUMMARY_FILE = "summary.json"
OUTPUT_FILE = "output.json"

# Initialize components
query_extractor = EnhancedQueryExtractor()
recipient_processor = RecipientProcessor()
data_validator = DataValidator()

# OpenAI setup - the newest OpenAI model is "gpt-4o" which was released May 13, 2024
# do not change this unless explicitly requested by the user
# OPENAI_API_KEY = os.environ.get("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")
# openai_client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None

openai.api_key = "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"
openai_client= openai.api_key
@app.route('/')
def index():
    """Main page with query input"""
    return render_template('index.html')

@app.route('/results')
def results():
    """Results page showing processed data"""
    stats = get_entity_statistics()
    return render_template('results.html', stats=stats)

@app.route('/process_query', methods=['POST'])
def process_query():
    """Process user query and fetch relevant data"""
    try:
        data = request.get_json()
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({'error': 'No prompt provided'}), 400
        
        logging.info(f"🔍 Processing query: {prompt}")
        
        # Step 1: Extract query details with enhanced logic
        query_details = query_extractor.extract_query_details(prompt)
        
        # Save query details to output.json
        with open(OUTPUT_FILE, 'w') as f:
            json.dump(query_details, f, indent=4)
        
        # Step 2: Process based on extracted details
        results = []
        
        # Handle recipients if present - Enhanced logic integrated
        if query_details.get('recipients'):
            logging.info(f"📋 Processing recipients: {query_details['recipients']}")
            
            # Use enhanced recipient processing logic
            for recipient_name in query_details['recipients']:
                recipient_data = recipient_processor.process_recipient(recipient_name)
                if recipient_data:
                    # Add additional metadata
                    for item in recipient_data:
                        item['query_type'] = 'recipient'
                        item['original_query'] = prompt
                        item['processing_timestamp'] = time.time()
                    results.extend(recipient_data)
        
        # Handle agencies if present
        if query_details.get('agency_name'):
            logging.info(f"🏛️ Processing agencies: {query_details['agency_name']}")
            for agency in query_details['agency_name']:
                agency_data = fetch_agency_data(agency, query_details)
                if agency_data:
                    # Add metadata
                    for item in agency_data:
                        item['query_type'] = 'agency'
                        item['original_query'] = prompt
                        item['processing_timestamp'] = time.time()
                    results.extend(agency_data)
        
        # Handle states if present
        if query_details.get('state'):
            logging.info(f"🗺️ Processing states: {query_details['state']}")
            for state in query_details['state']:
                state_data = fetch_state_data(state, query_details)
                if state_data:
                    # Add metadata
                    for item in state_data:
                        item['query_type'] = 'state'
                        item['original_query'] = prompt
                        item['processing_timestamp'] = time.time()
                    results.extend(state_data)
        
        # If no specific entities, fetch general data
        if not any([query_details.get('recipients'), query_details.get('agency_name'), query_details.get('state')]):
            logging.info("🌐 Processing general query")
            general_data = fetch_general_data(query_details)
            if general_data:
                # Add metadata
                for item in general_data:
                    item['query_type'] = 'general'
                    item['original_query'] = prompt
                    item['processing_timestamp'] = time.time()
                results.extend(general_data)
        
        # Step 3: Validate and clean results
        if results is None:
            results = []
            
        validated_results = data_validator.validate_and_clean(results)
        
        # Ensure validated_results is not None
        if validated_results is None:
            validated_results = []
        
        # Step 4: Structure data for n8n workflow compatibility
        structured_results = structure_for_n8n(validated_results, prompt, query_details)
        
        # Step 5: Save to final_results.json
        with open(QUERY_OUTPUT_FILE, 'w') as f:
            json.dump(structured_results, f, indent=4, cls=DecimalEncoder)
        
        # Step 6: Update summary with enhanced metadata
        update_summary_with_results(validated_results, prompt, query_details)
        
        logging.info(f"✅ Processing complete. Found {len(validated_results)} results")
        
        return jsonify({
            'success': True,
            'results_count': len(validated_results),
            'query_details': query_details,
            'structured_results': structured_results,
            'message': f'Successfully processed query and found {len(validated_results)} results'
        })
        
    except Exception as e:
        logging.error(f"❌ Error processing query: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/fetch_recipient_data')
def fetch_recipient_data_endpoint():
    """Endpoint to fetch all recipient data"""
    try:
        data = fetch_recipient_data()
        return jsonify({
            'success': True,
            'count': len(data),
            'message': f'Successfully fetched {len(data)} recipients'
        })
    except Exception as e:
        logging.error(f"❌ Error fetching recipient data: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/export_excel')
def export_excel():
    """Export current data to Excel"""
    try:
        summary_data = load_summary_data()
        
        if not summary_data:
            flash('No data available to export', 'warning')
            return redirect(url_for('results'))
        
        # Generate Excel file
        excel_bytes = export_dynamic_json_to_excel_bytes(summary_data)
        
        # Create filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"usa_spending_analysis_{timestamp}.xlsx"
        
        return send_file(
            io.BytesIO(excel_bytes),
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )
        
    except Exception as e:
        logging.error(f"❌ Error exporting Excel: {str(e)}")
        flash(f'Error exporting Excel: {str(e)}', 'error')
        return redirect(url_for('results'))

@app.route('/api/stats')
def api_stats():
    """API endpoint for statistics"""
    try:
        stats = get_entity_statistics()
        return jsonify(stats)
    except Exception as e:
        logging.error(f"❌ Error getting stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search/<search_term>')
def api_search(search_term):
    """API endpoint for searching entities"""
    try:
        matches = search_entities_by_name(search_term)
        return jsonify(matches)
    except Exception as e:
        logging.error(f"❌ Error searching: {str(e)}")
        return jsonify({'error': str(e)}), 500

def structure_for_n8n(results, prompt, query_details):
    """Structure data for n8n workflow compatibility"""
    try:
        # Create structured data that works well with n8n workflow
        structured = {
            'query_metadata': {
                'original_prompt': prompt,
                'query_details': query_details,
                'processing_timestamp': time.time(),
                'results_count': len(results)
            },
            'data_chunks': [],
            'summary': {
                'total_amount': 0,
                'entity_types': {},
                'top_recipients': [],
                'date_range': {
                    'start': None,
                    'end': None
                }
            }
        }
        
        # Split results into manageable chunks for n8n processing
        chunk_size = 50  # Smaller chunks for better processing
        total_amount = 0
        entity_types = {}
        
        for i in range(0, len(results), chunk_size):
            chunk = results[i:i + chunk_size]
            
            # Process chunk data
            chunk_data = {
                'chunk_id': i // chunk_size,
                'chunk_size': len(chunk),
                'data': chunk,
                'chunk_summary': {
                    'total_amount': 0,
                    'entity_count': len(chunk),
                    'entity_names': []
                }
            }
            
            # Calculate chunk statistics
            for item in chunk:
                # Extract amount
                amount = item.get('amount', 0)
                if isinstance(amount, (int, float)):
                    chunk_data['chunk_summary']['total_amount'] += amount
                    total_amount += amount
                
                # Extract entity names
                name = item.get('name', '')
                if name and name not in chunk_data['chunk_summary']['entity_names']:
                    chunk_data['chunk_summary']['entity_names'].append(name)
                
                # Count entity types
                query_type = item.get('query_type', 'unknown')
                entity_types[query_type] = entity_types.get(query_type, 0) + 1
            
            structured['data_chunks'].append(chunk_data)
        
        # Update summary
        structured['summary']['total_amount'] = total_amount
        structured['summary']['entity_types'] = entity_types
        
        # Get top recipients by amount
        sorted_results = sorted(results, key=lambda x: x.get('amount', 0), reverse=True)
        structured['summary']['top_recipients'] = [
            {
                'name': item.get('name', 'Unknown'),
                'amount': item.get('amount', 0),
                'type': item.get('query_type', 'unknown')
            }
            for item in sorted_results[:10]
        ]
        
        return structured
        
    except Exception as e:
        logging.error(f"❌ Error structuring data for n8n: {e}")
        return {
            'query_metadata': {
                'original_prompt': prompt,
                'error': str(e),
                'processing_timestamp': time.time()
            },
            'data_chunks': [{'chunk_id': 0, 'data': results}],
            'summary': {'error': str(e)}
        }

def fetch_recipient_data(url=None, max_pages=10):
    """
    Fetch all recipient data (optimized version)
    """
    url = "https://api.usaspending.gov/api/v2/recipient/duns/"
    all_data = []

    for page in range(1, max_pages + 1):
        params = {
            "order": "desc",
            "sort": "amount",
            "limit": 100,
            "page": page,
            "award_type": "all"
        }

        try:
            logging.info(f"📥 Fetching recipient data page {page}...")
            response = requests.post(url, json=params, timeout=30)
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            if not results:
                logging.info(f"No more results at page {page}. Stopping.")
                break
            all_data.extend(results)
            logging.info(f"✅ Fetched page {page}, records: {len(results)}")

        except requests.exceptions.RequestException as e:
            logging.error(f"❌ Error fetching data on page {page}: {e}")
            break

    logging.info(f"📊 Total records fetched: {len(all_data)}")
    
    os.makedirs(os.path.dirname(ALL_RECIPIENTS_FILE) if os.path.dirname(ALL_RECIPIENTS_FILE) else '.', exist_ok=True)
    
    with open(ALL_RECIPIENTS_FILE, "w") as f:
        json.dump(all_data, f, indent=4)
    logging.info(f"✅ Saved {len(all_data)} recipients to {ALL_RECIPIENTS_FILE}")
    
    return all_data

def fetch_agency_data(agency_name, query_details):
    """Fetch data for specific agency"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_category"
        
        params = {
            "category": "awarding_agency",
            "filters": {
                "time_period": [
                    {
                        "start_date": f"{year}-01-01",
                        "end_date": f"{year}-12-31"
                    } for year in query_details.get('year', ['2024'])
                ],
                "award_type_codes": get_award_type_codes(query_details.get('award_types', ['all']))
            },
            "limit": 50
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        # Filter for matching agency
        results = []
        for result in data.get('results', []):
            if agency_name.lower() in result.get('name', '').lower():
                results.append(result)
        
        return results
        
    except Exception as e:
        logging.error(f"❌ Error fetching agency data for {agency_name}: {e}")
        return []

def fetch_state_data(state_name, query_details):
    """Fetch data for specific state"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_category"
        
        params = {
            "category": "recipient_location",
            "filters": {
                "time_period": [
                    {
                        "start_date": f"{year}-01-01",
                        "end_date": f"{year}-12-31"
                    } for year in query_details.get('year', ['2024'])
                ],
                "award_type_codes": get_award_type_codes(query_details.get('award_types', ['all'])),
                "place_of_performance_locations": [{"country": "USA", "state": state_name}]
            },
            "limit": 50
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        return data.get('results', [])
        
    except Exception as e:
        logging.error(f"❌ Error fetching state data for {state_name}: {e}")
        return []

def fetch_general_data(query_details):
    """Fetch general spending data based on query parameters"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_award"
        
        params = {
            "filters": {
                "time_period": [
                    {
                        "start_date": f"{year}-01-01",
                        "end_date": f"{year}-12-31"
                    } for year in query_details.get('year', ['2024'])
                ],
                "award_type_codes": get_award_type_codes(query_details.get('award_types', ['all']))
            },
            "limit": 100,
            "page": 1,
            "sort": "Award Amount",
            "order": "desc"
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        return data.get('results', [])
        
    except Exception as e:
        logging.error(f"❌ Error fetching general data: {e}")
        return []

def get_award_type_codes(award_types):
    """Convert award types to API codes"""
    type_mapping = {
        'contracts': ['A', 'B', 'C', 'D'],
        'grants': ['02', '03', '04', '05'],
        'loans': ['07', '08'],
        'all': ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
    }
    
    codes = []
    for award_type in award_types:
        codes.extend(type_mapping.get(award_type.lower(), type_mapping['all']))
    
    return list(set(codes))  # Remove duplicates

def update_summary_with_results(results, original_prompt, query_details):
    """Update summary.json with new results"""
    try:
        summary = load_summary_data()
        
        # Create a summary entry for this query
        query_hash = hash(original_prompt) % 1000000
        summary_key = f"query_{query_hash}"
        
        summary[summary_key] = {
            'data': results,
            'prompt': original_prompt,
            'query_details': query_details,
            'timestamp': time.time(),
            'processed': True,
            'ai_response': generate_ai_analysis(results, original_prompt)
        }
        
        # Save updated summary
        with open(SUMMARY_FILE, 'w') as f:
            json.dump(summary, f, indent=4, cls=DecimalEncoder)
        
        logging.info(f"✅ Updated summary with {len(results)} results")
        
    except Exception as e:
        logging.error(f"❌ Error updating summary: {e}")

def generate_ai_analysis(results, prompt):
    """Generate AI analysis of the results"""
    try:
        if not openai_client:
            return "No AI analysis available - OpenAI API key not configured"
        
        # Prepare data for AI analysis
        summary_data = {
            'total_results': len(results),
            'sample_data': results[:5] if results else [],
            'original_query': prompt
        }
        
        # Calculate key metrics
        total_amount = sum(item.get('amount', 0) for item in results if isinstance(item.get('amount'), (int, float)))
        top_recipients = sorted(results, key=lambda x: x.get('amount', 0), reverse=True)[:5]
        
        ai_prompt = f"""
        Analyze the following government spending data and provide insights:
        
        Original Query: {prompt}
        
        Data Summary:
        - Total Results: {len(results)}
        - Total Amount: ${total_amount:,.2f}
        - Top Recipients: {[r.get('name', 'Unknown') for r in top_recipients]}
        
        Sample Data: {json.dumps(summary_data['sample_data'], indent=2)}
        
        Please provide:
        1. Key findings from the data
        2. Notable patterns or trends
        3. Relevant insights related to the original query
        4. Summary of spending amounts and recipients
        5. Any concerning patterns or anomalies
        
        Keep the response concise but informative. Format as structured text.
        """
        
        # Use the newest OpenAI model "gpt-4o" (released May 13, 2024)
        response = openai.ChatCompletion.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert government spending analyst. Provide clear, actionable insights from spending data."},
                {"role": "user", "content": ai_prompt}
            ],
            max_tokens=1000,
            temperature=0.7
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        logging.error(f"❌ Error generating AI analysis: {e}")
        return f"AI analysis error: {str(e)}"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
