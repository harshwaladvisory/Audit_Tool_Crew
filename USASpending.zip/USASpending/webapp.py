import openai
import json
import os
import requests 
import time 
import logging
import glob  # FIXED: Added for backup cleanup
from datetime import datetime, timedelta  # FIXED: Added timedelta for backup cleanup
from difflib import get_close_matches
import math
import re
from decimal import Decimal
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for, flash
from enhanced_extraction import EnhancedQueryExtractor
from recipient_processor import RecipientProcessor
from data_validator import DataValidator
from additional_utils import *
from output_xl1 import export_dynamic_json_to_excel_bytes
import io

# Import app from app.py
from app import app

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

# File paths
ALL_RECIPIENTS_FILE = "all_recipients.json"
QUERY_OUTPUT_FILE = "final_results.json"
SUMMARY_FILE = "summary.json"
OUTPUT_FILE = "output.json"

# Session management - FIXED: Always track current query
CURRENT_QUERY_ID = None
CURRENT_QUERY_DATA = None

# Initialize components
query_extractor = EnhancedQueryExtractor()
recipient_processor = RecipientProcessor()
data_validator = DataValidator()

# OpenAI setup
openai_api_key = "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"

try:
    openai_client = openai.OpenAI(api_key=openai_api_key)
    logging.info("✅ OpenAI client initialized successfully")
except Exception as e:
    logging.error(f"❌ Error initializing OpenAI client: {e}")
    openai_client = None

# ENHANCED: Fiscal year conversion functions with better error handling
def convert_fiscal_year_to_date_range(fiscal_year):
    """
    ENHANCED: Convert fiscal year to actual date range with better validation
    FY 2022 = Oct 1, 2021 to Sep 30, 2022
    """
    try:
        fy = int(fiscal_year)
        start_date = f"{fy-1}-10-01"  # October 1 of previous calendar year
        end_date = f"{fy}-09-30"      # September 30 of fiscal year
        logging.debug(f"📅 FY{fy} converted to: {start_date} to {end_date}")
        return start_date, end_date
    except (ValueError, TypeError):
        # Fallback to calendar year if conversion fails
        logging.warning(f"⚠️ Failed to convert fiscal year '{fiscal_year}', using calendar year")
        return f"{fiscal_year}-01-01", f"{fiscal_year}-12-31"

def get_fiscal_year_time_periods(years):
    """
    ENHANCED: Convert list of fiscal years to time periods for API calls with logging
    """
    time_periods = []
    for year in years:
        start_date, end_date = convert_fiscal_year_to_date_range(year)
        time_periods.append({
            "start_date": start_date,
            "end_date": end_date
        })
        logging.debug(f"📅 Added time period for FY{year}: {start_date} to {end_date}")
    
    logging.info(f"🗓️ Created {len(time_periods)} fiscal year time periods")
    return time_periods

def is_date_in_fiscal_year(date_str, fiscal_year):
    """
    ENHANCED: Check if a date falls within the specified fiscal year with better parsing
    """
    if not date_str or not fiscal_year:
        return True  # Include if no filtering needed
    
    try:
        fy_start, fy_end = convert_fiscal_year_to_date_range(fiscal_year)
        
        # Enhanced date parsing to handle multiple formats
        if isinstance(date_str, str) and len(date_str) >= 8:
            # Handle ISO datetime format (e.g., "2022-03-15T10:30:00Z")
            if 'T' in date_str:
                test_date = date_str.split('T')[0]  # YYYY-MM-DD format
            # Handle hyphen-separated dates (YYYY-MM-DD)
            elif '-' in date_str and len(date_str.split('-')) == 3:
                test_date = date_str.split(' ')[0]  # Remove any time component
            # Handle slash-separated dates
            elif '/' in date_str:
                parts = date_str.split('/')
                if len(parts) >= 3:
                    if len(parts[2]) == 4:  # MM/DD/YYYY format
                        month, day, year = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                        test_date = f"{year}-{month}-{day}"
                    elif len(parts[0]) == 4:  # YYYY/MM/DD format
                        year, month, day = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                        test_date = f"{year}-{month}-{day}"
                    else:  # DD/MM/YY format
                        day, month, year = parts[0].zfill(2), parts[1].zfill(2), f"20{parts[2]}"
                        test_date = f"{year}-{month}-{day}"
                else:
                    return True  # Can't parse, include it
            else:
                test_date = date_str[:10]  # Take first 10 characters
        else:
            return True  # Invalid date, include it
        
        # Validate the parsed date format
        try:
            datetime.strptime(test_date, '%Y-%m-%d')
        except ValueError:
            logging.warning(f"⚠️ Invalid date format after parsing: {test_date} from {date_str}")
            return True  # Include if date is invalid
        
        # Check if date falls in fiscal year range
        in_range = fy_start <= test_date <= fy_end
        
        if in_range:
            logging.debug(f"✅ Date {test_date} is in FY{fiscal_year}")
        else:
            logging.debug(f"❌ Date {test_date} is NOT in FY{fiscal_year}")
        
        return in_range
        
    except Exception as e:
        logging.warning(f"⚠️ Error checking date {date_str} against fiscal year {fiscal_year}: {e}")
        return True  # Include if we can't determine

def filter_results_by_fiscal_year(results, target_years):
    """ENHANCED: Filter results by fiscal year with better logging and date handling"""
    if not target_years or not results:
        return results
    
    # Convert target fiscal years to date ranges
    fiscal_year_ranges = []
    for fy in target_years:
        start_date, end_date = convert_fiscal_year_to_date_range(fy)
        fiscal_year_ranges.append((start_date, end_date))
    
    filtered_results = []
    
    logging.info(f"🔍 Filtering {len(results)} results by fiscal years: {target_years}")
    for fy in target_years:
        try:
            fy_int = int(fy)
            start_date = f"{fy_int-1}-10-01"
            end_date = f"{fy_int}-09-30"
            logging.info(f"   FY{fy}: {start_date} to {end_date}")
        except:
            logging.warning(f"   FY{fy}: Invalid format")
    
    excluded_count = 0
    included_count = 0
    
    for item in results:
        try:
            if not isinstance(item, dict):
                filtered_results.append(item)
                included_count += 1
                continue
            
            # Extract date from various possible fields with priority order
            date_fields = [
                'action_date', 'Action Date',  # Highest priority
                'date_signed', 'signed_date', 'Date Signed',
                'award_date', 'Award Date',
                'transaction_date', 'Transaction Date',
                'issued_date', 'Issued Date',
                'executed_date', 'Executed Date',
                'start_date', 'Start Date',
                'end_date', 'End Date',  # Lower priority
                'timestamp', 'processing_timestamp'  # Lowest priority
            ]
            
            item_date = None
            date_field_used = None
            
            # Find the first available date field
            for field_name in date_fields:
                date_value = item.get(field_name)
                if date_value and date_value not in ['Unknown', 'N/A', None, '', 'null']:
                    if isinstance(date_value, str) and len(date_value) >= 8:
                        # Enhanced date format handling
                        if 'T' in date_value:
                            item_date = date_value.split('T')[0]  # ISO format
                        elif '-' in date_value and len(date_value.split('-')) == 3:
                            item_date = date_value.split(' ')[0]  # YYYY-MM-DD format
                        elif '/' in date_value:
                            parts = date_value.split('/')
                            if len(parts) >= 3:
                                if len(parts[2]) == 4:  # MM/DD/YYYY format
                                    month, day, year = parts[0].zfill(2), parts[1].zfill(2), parts[2]
                                    item_date = f"{year}-{month}-{day}"
                                elif len(parts[0]) == 4:  # YYYY/MM/DD format
                                    year, month, day = parts[0], parts[1].zfill(2), parts[2].zfill(2)
                                    item_date = f"{year}-{month}-{day}"
                                else:  # DD/MM/YY format
                                    day, month, year = parts[0].zfill(2), parts[1].zfill(2), f"20{parts[2]}"
                                    item_date = f"{year}-{month}-{day}"
                        else:
                            item_date = date_value[:10]  # Take first 10 characters
                        
                        date_field_used = field_name
                        break
            
            # Check if item date falls within any of the fiscal year ranges
            if item_date:
                item_included = False
                for start_date, end_date in fiscal_year_ranges:
                    try:
                        # Validate parsed date
                        datetime.strptime(item_date, '%Y-%m-%d')
                        if start_date <= item_date <= end_date:
                            item_included = True
                            break
                    except ValueError:
                        logging.warning(f"⚠️ Invalid parsed date format: {item_date} from {date_value}")
                        item_included = True  # Include if date is invalid
                        break
                
                if item_included:
                    filtered_results.append(item)
                    included_count += 1
                    logging.debug(f"✅ Included item with {date_field_used}={item_date}")
                else:
                    excluded_count += 1
                    logging.debug(f"❌ Excluded item with {date_field_used}={item_date} (not in fiscal years {target_years})")
            else:
                # If no date found, include the item
                filtered_results.append(item)
                included_count += 1
                logging.debug(f"ℹ️ Included item with no date fields")
                
        except Exception as filter_error:
            logging.warning(f"⚠️ Error filtering result: {filter_error}")
            # Include the item if there's an error
            filtered_results.append(item)
            included_count += 1
            continue
    
    logging.info(f"✅ Fiscal year filtering complete: {included_count} included, {excluded_count} excluded")
    logging.info(f"   Final count: {len(filtered_results)} results matching fiscal years {target_years}")
    return filtered_results

# FIXED: Standardized financial calculation function
def calculate_standardized_financial_metrics(item):
    """
    ENHANCED: Standardized financial calculation that matches USA Spending API data structure
    """
    try:
        # Extract award amount (total amount awarded)
        award_amount = 0
        award_amount_fields = ['Award Amount', 'award_amount', 'amount', 'total_amount', 'awarded_amount']
        for field in award_amount_fields:
            value = item.get(field)
            if value is not None:
                try:
                    award_amount = float(value)
                    break
                except (ValueError, TypeError):
                    continue
        
        # Extract amount spent (Total Outlays from USA Spending API)
        # ENHANCED: USA Spending API uses "Total Outlays" for actual spending
        amount_spent = 0
        amount_spent_fields = ['Total Outlays', 'total_outlays', 'amount_spent', 'outlays', 'disbursed_amount']
        for field in amount_spent_fields:
            value = item.get(field)
            if value is not None:
                try:
                    amount_spent = float(value)
                    break
                except (ValueError, TypeError):
                    continue
        
        # ENHANCED: Calculate remaining amount correctly
        remaining_amount = award_amount - amount_spent
        
        # ENHANCED: Calculate spending percentage correctly
        # Handle edge cases where Total Outlays might equal Award Amount due to API data structure
        if award_amount > 0:
            spending_percentage = (amount_spent / award_amount) * 100
            
            # ENHANCED: Handle cases where Total Outlays equals Award Amount (common in USA Spending API)
            # This often indicates the award is fully obligated, not necessarily fully spent
            if spending_percentage > 100:
                spending_percentage = 100
                remaining_amount = 0
            elif spending_percentage < 0:
                spending_percentage = 0
                remaining_amount = award_amount
        else:
            spending_percentage = 0
            remaining_amount = 0
        
        return {
            'award_amount': award_amount,
            'amount_spent': amount_spent,
            'remaining_amount': remaining_amount,
            'spending_percentage': round(spending_percentage, 2)
        }
    except Exception as e:
        logging.error(f"❌ Error calculating financial metrics: {e}")
        return {
            'award_amount': 0,
            'amount_spent': 0,
            'remaining_amount': 0,
            'spending_percentage': 0
        }

# FIXED: Add automatic backup cleanup function
def cleanup_old_backup_files(max_age_hours: int = 24):
    """ENHANCED: Automatically cleanup old backup files older than max_age_hours"""
    try:
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        # Common backup file patterns
        backup_patterns = [
            "*.backup_*",
            "*_backup_*",
            "backups/*.json",
            "*.json.backup_*"
        ]
        
        deleted_count = 0
        
        for pattern in backup_patterns:
            backup_files = glob.glob(pattern)
            
            for backup_file in backup_files:
                try:
                    # Check if file is older than max_age_hours
                    file_age = current_time - os.path.getmtime(backup_file)
                    
                    if file_age > max_age_seconds:
                        os.remove(backup_file)
                        deleted_count += 1
                        logging.info(f"🗑️ Deleted old backup file: {backup_file}")
                        
                except Exception as file_error:
                    logging.warning(f"⚠️ Could not delete backup file {backup_file}: {file_error}")
                    continue
        
        if deleted_count > 0:
            logging.info(f"✅ Cleaned up {deleted_count} old backup files")
        else:
            logging.info("ℹ️ No old backup files found to clean up")
            
        return deleted_count
        
    except Exception as e:
        logging.error(f"❌ Error during backup cleanup: {e}")
        return 0

def reset_session_files():
    """ENHANCED: Reset files for each new query and cleanup old backups"""
    try:
        # ENHANCED: First cleanup old backup files
        cleanup_old_backup_files(max_age_hours=24)
        
        session_info = {
            "session_start": datetime.now().isoformat(),
            "session_id": f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "queries_processed": 0,
            "total_results": 0,
            "fiscal_year_support": True,
            "award_type_filtering_support": True  # FIXED: Add award type support flag
        }
        
        # Always reset files for new query
        reset_final_results_file(session_info)
        reset_summary_file(session_info)
        
        logging.info("✅ Session files reset for new query and old backups cleaned up")
        return True
        
    except Exception as e:
        logging.error(f"❌ Error resetting session files: {e}")
        return False

def clean_files_on_startup():
    """ENHANCED: Clean files when the application starts/refreshes and cleanup old backups"""
    try:
        # ENHANCED: First cleanup old backup files
        cleanup_old_backup_files(max_age_hours=12)  # More aggressive cleanup on startup
        
        files_to_clean = ["final_results.json", "summary.json", "output.json"]
        
        for file_path in files_to_clean:
            if os.path.exists(file_path):
                backup_name = f"{file_path}.backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                try:
                    os.rename(file_path, backup_name)
                    logging.info(f"✅ Backed up {file_path} to {backup_name}")
                except Exception as backup_error:
                    logging.warning(f"⚠️ Could not backup {file_path}: {backup_error}")
                    try:
                        os.remove(file_path)
                        logging.info(f"✅ Deleted {file_path}")
                    except Exception as delete_error:
                        logging.warning(f"⚠️ Could not delete {file_path}: {delete_error}")
        
        logging.info("✅ Files cleaned on startup and old backups removed")
        return True
        
    except Exception as e:
        logging.error(f"❌ Error cleaning files on startup: {e}")
        return False

# Safe JSON Loading Functions
def safe_load_json_file(file_path, default_value=None):
    """Safely load JSON file with proper error handling"""
    if default_value is None:
        default_value = {}
        
    try:
        if not os.path.exists(file_path):
            logging.info(f"📁 {file_path} not found, returning default value")
            return default_value
        
        if os.path.getsize(file_path) == 0:
            logging.warning(f"⚠️ {file_path} is empty, returning default value")
            return default_value
        
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            if not content:
                logging.warning(f"⚠️ {file_path} contains no content, returning default value")
                return default_value
            
            data = json.loads(content)
            logging.info(f"✅ Successfully loaded {file_path}")
            return data
            
    except json.JSONDecodeError as json_error:
        logging.error(f"❌ JSON decode error in {file_path}: {json_error}")
        return default_value
        
    except Exception as e:
        logging.error(f"❌ Error loading {file_path}: {e}")
        return default_value

def reset_final_results_file(session_info):
    """Reset final_results.json with session info"""
    try:
        initial_data = {
            "_session_info": session_info,
            "_metadata": {
                "description": "USA Spending Data Analysis Results",
                "created": datetime.now().isoformat(),
                "format_version": "1.0",
                "fiscal_year_support": True,
                "award_type_filtering_support": True  # FIXED: Add award type support flag
            }
        }
        
        with open("final_results.json", "w", encoding="utf-8") as f:
            json.dump(initial_data, f, indent=2, ensure_ascii=False)
        
        logging.info("✅ final_results.json reset for new session")
        
    except Exception as e:
        logging.error(f"❌ Error resetting final_results.json: {e}")

def reset_summary_file(session_info):
    """Reset summary.json with session info"""
    try:
        initial_data = {
            "_session_info": session_info,
            "_metadata": {
                "description": "Query summaries and AI analysis",
                "created": datetime.now().isoformat(),
                "format_version": "1.0",
                "fiscal_year_support": True,
                "award_type_filtering_support": True  # FIXED: Add award type support flag
            }
        }
        
        with open("summary.json", "w", encoding="utf-8") as f:
            json.dump(initial_data, f, indent=2, ensure_ascii=False)
        
        logging.info("✅ summary.json reset for new session")
        
    except Exception as e:
        logging.error(f"❌ Error resetting summary.json: {e}")

def save_current_query_data(key, data):
    """ENHANCED: Save data for current query only with fiscal year support"""
    try:
        global CURRENT_QUERY_ID, CURRENT_QUERY_DATA
        
        # Set current query tracking
        CURRENT_QUERY_ID = key
        CURRENT_QUERY_DATA = data
        
        # Save to files as well
        existing_data = safe_load_json_file("final_results.json", {
            "_session_info": {
                "session_start": datetime.now().isoformat(),
                "current_query": key,
                "fiscal_year_support": True,
                "award_type_filtering_support": True  # FIXED: Add award type support flag
            }
        })
        
        existing_data[key] = data
        
        if "_session_info" in existing_data:
            existing_data["_session_info"]["last_updated"] = datetime.now().isoformat()
            existing_data["_session_info"]["current_query"] = key
            existing_data["_session_info"]["queries_processed"] = len([k for k in existing_data.keys() if not k.startswith("_")])
            existing_data["_session_info"]["fiscal_year_support"] = True
            existing_data["_session_info"]["award_type_filtering_support"] = True  # FIXED: Add award type support flag
        
        with open("final_results.json", "w", encoding="utf-8") as f:
            json.dump(existing_data, f, indent=2, ensure_ascii=False, cls=DecimalEncoder)
        
        logging.info(f"✅ Saved current query data for key: {key}")
        
    except Exception as e:
        logging.error(f"❌ Error saving current query data: {e}")

# ENHANCED: Enhanced recipient suggestions function
def get_recipient_suggestions_enhanced(invalid_recipients):
    """ENHANCED: Enhanced function to get better suggestions for recipients"""
    suggestions = {}
    
    try:
        extractor = EnhancedQueryExtractor()
        
        for recipient_name in invalid_recipients:
            enhanced_suggestions = extractor.get_enhanced_suggestions(recipient_name)
            suggestions[recipient_name] = enhanced_suggestions
        
        return suggestions
        
    except Exception as e:
        logging.error(f"❌ Error getting recipient suggestions: {e}")
        return {}

# Flask Routes
@app.route('/')
def index():
    """Main page with query input - Clean files on page load"""
    try:
        clean_files_on_startup()
        global CURRENT_QUERY_ID, CURRENT_QUERY_DATA
        CURRENT_QUERY_ID = None
        CURRENT_QUERY_DATA = None
    except Exception as e:
        logging.error(f"❌ Error cleaning files on page load: {e}")
    
    return render_template('index.html')

@app.route('/results')
def results():
    """Results page showing processed data"""
    stats = get_entity_statistics()
    return render_template('results.html', stats=stats)

# In webapp.py, update the process_query function to better handle the extracted years

@app.route('/process_query', methods=['POST'])
def process_query():
    """ENHANCED: Process user query with CONSISTENT fiscal year support and lenient validation and FIXED award type filtering"""
    try:
        # ENHANCED: Always reset files before processing new query
        reset_success = reset_session_files()
        if not reset_success:
            logging.warning("⚠️ Failed to reset session files, continuing anyway")
        
        data = request.get_json()
        prompt = data.get('prompt', '')
        
        if not prompt:
            return jsonify({'error': 'No prompt provided'}), 400
        
        logging.info(f"🔍 Processing NEW query with FISCAL YEAR support and AWARD TYPE filtering (fresh session): {prompt}")
        
        # Step 1: Extract query details with ENHANCED fiscal year validation and award type extraction
        try:
            query_details = query_extractor.extract_query_details(prompt)
        except Exception as e:
            logging.error(f"❌ Error extracting query details: {e}")
            return jsonify({'error': f'Failed to extract query details: {str(e)}'}), 500
        
        # Log fiscal year information for debugging - FIXED: Better logging for "from YYYY" patterns
        target_years = query_details.get('year', [])
        if target_years:
            logging.info(f"📅 Target FISCAL years extracted: {target_years}")
            
            # FIXED: Check if this looks like a "from YYYY" pattern that was expanded
            if len(target_years) > 10:  # If we have many years, it's likely a "from YYYY" expansion
                logging.info(f"📅 EXPANDED RANGE detected: Query likely contained 'from {target_years[0]}' pattern")
                logging.info(f"📅 Searching fiscal years {target_years[0]} through {target_years[-1]} ({len(target_years)} years total)")
            
            # Show first few and last few years for very long ranges
            if len(target_years) > 5:
                first_few = target_years[:3]
                last_few = target_years[-3:]
                logging.info(f"📅 First few fiscal years: {first_few}")
                logging.info(f"📅 Last few fiscal years: {last_few}")
            else:
                for fy in target_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        logging.info(f"   FY{fy}: {start_date} to {end_date}")
                    except:
                        logging.warning(f"   FY{fy}: Invalid format")
        else:
            logging.info(f"📅 No specific fiscal years found, using default range")
        
        # FIXED: Log award type information for debugging
        target_award_types = query_details.get('award_types', ['all'])
        logging.info(f"🎯 Target AWARD TYPES extracted: {target_award_types}")
        
        # ENHANCED: LENIENT validation - only block for critical errors, allow warnings
        validation_errors = query_details.get('validation_errors', [])
        validation_warnings = query_details.get('validation_warnings', [])
        
        # ENHANCED: Only block processing for CRITICAL validation errors (empty errors list now)
        if validation_errors:
            logging.warning(f"❌ CRITICAL validation errors found: {validation_errors}")
            
            # Get suggestions for invalid recipients
            invalid_recipients = query_details.get('recipients', [])
            suggestions = get_recipient_suggestions_enhanced(invalid_recipients)
            
            error_message = "Critical validation errors detected:\n" + "\n".join(validation_errors)
            
            if suggestions:
                suggestion_text = []
                for invalid_name, suggested_names in suggestions.items():
                    if suggested_names:
                        suggestion_text.append(f"For '{invalid_name}', try: {', '.join(suggested_names[:3])}")
                
                if suggestion_text:
                    error_message += f"\n\nSuggestions:\n" + "\n".join(suggestion_text)
            
            error_message += "\n\nPlease correct the critical errors and try again."
            
            return jsonify({
                'error': error_message,
                'validation_errors': validation_errors,
                'extracted_recipients': query_details.get('recipients', []),
                'suggestions': suggestions,
                'error_type': 'critical_validation_error'
            }), 400
        
        # ENHANCED: Log warnings but continue processing
        processing_warnings = []
        if validation_warnings:
            logging.info(f"ℹ️ Validation warnings (continuing with processing): {validation_warnings}")
            processing_warnings.extend([f"Note: {warning}" for warning in validation_warnings])
            processing_warnings.append("The system will search federal records even for entities not in the pre-loaded database.")
        
        # Save query details
        try:
            with open(OUTPUT_FILE, 'w') as f:
                json.dump(query_details, f, indent=4)
        except Exception as e:
            logging.warning(f"⚠️ Could not save query details to output.json: {e}")
        
        # Step 2: Process based on extracted details with enhanced fiscal year filtering and award type filtering
        results = []
        recipient_data_found = False
        recipients_with_no_data = []
        
        if query_details.get('recipients'):
            logging.info(f"📋 Processing recipients with FISCAL YEAR filtering and AWARD TYPE filtering: {query_details['recipients']}")
            logging.info(f"🎯 Award types to search: {target_award_types}")
            
            # FIXED: Better logging for large year ranges
            if len(target_years) > 10:
                logging.info(f"📅 Processing EXPANDED fiscal year range: FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)")
            elif target_years:
                logging.info(f"📅 Processing fiscal years: {target_years}")
            
            for recipient_name in query_details['recipients']:
                try:
                    logging.info(f"🎯 Processing detailed data for recipient: {recipient_name} with award types: {target_award_types}")
                    
                    # ENHANCED: Use enhanced recipient processing with CONSISTENT fiscal year support and award type filtering
                    recipient_data = recipient_processor.process_recipient(recipient_name, query_details)
                    
                    if recipient_data and isinstance(recipient_data, list) and len(recipient_data) > 0:
                        # ENHANCED: Apply standardized financial calculations to each item
                        for item in recipient_data:
                            if isinstance(item, dict):
                                # Apply standardized financial calculations
                                financial_metrics = calculate_standardized_financial_metrics(item)
                                item.update(financial_metrics)
                        
                        # ENHANCED: Apply fiscal year filtering if specified - FIXED: Better handling for large ranges
                        if target_years:
                            if len(target_years) > 10:
                                logging.info(f"🔍 Applying FISCAL YEAR filtering for {recipient_name}: FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)")
                            else:
                                logging.info(f"🔍 Applying FISCAL YEAR filtering for {recipient_name}: {target_years}")
                            
                            filtered_data = filter_results_by_fiscal_year(recipient_data, target_years)
                            if filtered_data:
                                recipient_data = filtered_data
                                if len(target_years) > 10:
                                    logging.info(f"📅 Filtered {len(recipient_data)} results for {recipient_name} by fiscal years FY{target_years[0]}-FY{target_years[-1]}")
                                else:
                                    logging.info(f"📅 Filtered {len(recipient_data)} results for {recipient_name} by fiscal years {target_years}")
                            else:
                                logging.warning(f"⚠️ No data for {recipient_name} after fiscal year filtering")
                                recipients_with_no_data.append(recipient_name)
                                if len(target_years) > 10:
                                    processing_warnings.append(f"No data found for '{recipient_name}' in fiscal years FY{target_years[0]} to FY{target_years[-1]}")
                                else:
                                    processing_warnings.append(f"No data found for '{recipient_name}' in fiscal years {target_years}")
                                continue
                        
                        # Check if we actually got meaningful data
                        meaningful_data = False
                        for item in recipient_data:
                            if isinstance(item, dict):
                                # Check if the item has meaningful financial data
                                award_amount = item.get('award_amount', 0)
                                if award_amount and float(award_amount) > 0:
                                    meaningful_data = True
                                    break
                        
                        if meaningful_data:
                            recipient_data_found = True
                            for item in recipient_data:
                                try:
                                    item['query_type'] = 'recipient'
                                    item['original_query'] = prompt
                                    item['processing_timestamp'] = time.time()
                                    item['extracted_from'] = 'recipient_search'
                                    item['validation_timestamp'] = datetime.now().isoformat()
                                    item['validation_status'] = 'cleaned'
                                    item['fiscal_year_filtered'] = bool(target_years)
                                    item['fiscal_years_applied'] = target_years if target_years else []
                                    item['award_types_filtered'] = target_award_types  # FIXED: Track award types applied
                                    item['award_type_filtering_applied'] = target_award_types != ['all']
                                except Exception as metadata_error:
                                    logging.warning(f"⚠️ Error adding metadata to item: {metadata_error}")
                                    continue
                            
                            results.extend(recipient_data)
                            if len(target_years) > 10:
                                logging.info(f"✅ Added {len(recipient_data)} detailed items for {recipient_name} (fiscal years: FY{target_years[0]}-FY{target_years[-1]}, award types: {target_award_types})")
                            else:
                                logging.info(f"✅ Added {len(recipient_data)} detailed items for {recipient_name} (fiscal year filtered: {bool(target_years)}, award types: {target_award_types})")
                        else:
                            logging.warning(f"⚠️ No meaningful financial data found for recipient: {recipient_name}")
                            recipients_with_no_data.append(recipient_name)
                            processing_warnings.append(f"Limited data found for '{recipient_name}' - may not be a major federal contractor in the specified time period")
                    else:
                        logging.warning(f"⚠️ No valid data returned for recipient: {recipient_name}")
                        recipients_with_no_data.append(recipient_name)
                        processing_warnings.append(f"No data found for '{recipient_name}' in federal spending records for the specified time period")
                        
                except Exception as recipient_error:
                    logging.error(f"❌ Error processing recipient {recipient_name}: {recipient_error}")
                    recipients_with_no_data.append(recipient_name)
                    processing_warnings.append(f"Error processing '{recipient_name}': {str(recipient_error)}")
                    continue
        
        # Handle other entity types (agencies, states, general) with fiscal year filtering and award type filtering
        if query_details.get('agency_name'):
            logging.info(f"🏛️ Processing agencies with FISCAL YEAR filtering and AWARD TYPE filtering: {query_details['agency_name']}")
            for agency in query_details['agency_name']:
                try:
                    agency_data = fetch_agency_data(agency, query_details)
                    if agency_data and isinstance(agency_data, list) and len(agency_data) > 0:
                        # Apply fiscal year filtering if specified
                        if target_years:
                            agency_data = filter_results_by_fiscal_year(agency_data, target_years)
                        
                        if agency_data:
                            recipient_data_found = True
                            for item in agency_data:
                                try:
                                    # ENHANCED: Apply standardized financial calculations
                                    financial_metrics = calculate_standardized_financial_metrics(item)
                                    item.update(financial_metrics)
                                    
                                    item['query_type'] = 'agency'
                                    item['original_query'] = prompt
                                    item['processing_timestamp'] = time.time()
                                    item['extracted_from'] = 'agency_search'
                                    item['fiscal_year_filtered'] = bool(target_years)
                                    item['fiscal_years_applied'] = target_years if target_years else []
                                    item['award_types_filtered'] = target_award_types  # FIXED: Track award types applied
                                    item['award_type_filtering_applied'] = target_award_types != ['all']
                                except Exception as metadata_error:
                                    logging.warning(f"⚠️ Error adding agency metadata: {metadata_error}")
                                    continue
                            results.extend(agency_data)
                        else:
                            if len(target_years) > 10:
                                logging.warning(f"⚠️ No agency data after fiscal year filtering for: {agency}")
                                processing_warnings.append(f"No data found for agency '{agency}' in fiscal years FY{target_years[0]} to FY{target_years[-1]}")
                            else:
                                logging.warning(f"⚠️ No agency data after fiscal year filtering for: {agency}")
                                processing_warnings.append(f"No data found for agency '{agency}' in fiscal years {target_years}")
                    else:
                        logging.warning(f"⚠️ No valid agency data returned for: {agency}")
                        processing_warnings.append(f"No data found for agency '{agency}'")
                except Exception as agency_error:
                    logging.error(f"❌ Error processing agency {agency}: {agency_error}")
                    processing_warnings.append(f"Error processing agency '{agency}': {str(agency_error)}")
                    continue
        
        if query_details.get('state'):
            logging.info(f"🗺️ Processing states with FISCAL YEAR filtering and AWARD TYPE filtering: {query_details['state']}")
            for state in query_details['state']:
                try:
                    state_data = fetch_state_data(state, query_details)
                    if state_data and isinstance(state_data, list) and len(state_data) > 0:
                        # Apply fiscal year filtering if specified
                        if target_years:
                            state_data = filter_results_by_fiscal_year(state_data, target_years)
                        
                        if state_data:
                            recipient_data_found = True
                            for item in state_data:
                                try:
                                    # ENHANCED: Apply standardized financial calculations
                                    financial_metrics = calculate_standardized_financial_metrics(item)
                                    item.update(financial_metrics)
                                    
                                    item['query_type'] = 'state'
                                    item['original_query'] = prompt
                                    item['processing_timestamp'] = time.time()
                                    item['extracted_from'] = 'state_search'
                                    item['fiscal_year_filtered'] = bool(target_years)
                                    item['fiscal_years_applied'] = target_years if target_years else []
                                    item['award_types_filtered'] = target_award_types  # FIXED: Track award types applied
                                    item['award_type_filtering_applied'] = target_award_types != ['all']
                                except Exception as metadata_error:
                                    logging.warning(f"⚠️ Error adding state metadata: {metadata_error}")
                                    continue
                            results.extend(state_data)
                        else:
                            if len(target_years) > 10:
                                logging.warning(f"⚠️ No state data after fiscal year filtering for: {state}")
                                processing_warnings.append(f"No data found for state '{state}' in fiscal years FY{target_years[0]} to FY{target_years[-1]}")
                            else:
                                logging.warning(f"⚠️ No state data after fiscal year filtering for: {state}")
                                processing_warnings.append(f"No data found for state '{state}' in fiscal years {target_years}")
                    else:
                        logging.warning(f"⚠️ No valid state data returned for: {state}")
                        processing_warnings.append(f"No data found for state '{state}'")
                except Exception as state_error:
                    logging.error(f"❌ Error processing state {state}: {state_error}")
                    processing_warnings.append(f"Error processing state '{state}': {str(state_error)}")
                    continue
        
        if not any([query_details.get('recipients'), query_details.get('agency_name'), query_details.get('state')]):
            logging.info("🌐 Processing general query with FISCAL YEAR filtering and AWARD TYPE filtering")
            try:
                general_data = fetch_general_data(query_details)
                if general_data and isinstance(general_data, list) and len(general_data) > 0:
                    # Apply fiscal year filtering if specified
                    if target_years:
                        general_data = filter_results_by_fiscal_year(general_data, target_years)
                    
                    if general_data:
                        recipient_data_found = True
                        for item in general_data:
                            try:
                                # ENHANCED: Apply standardized financial calculations
                                financial_metrics = calculate_standardized_financial_metrics(item)
                                item.update(financial_metrics)
                                
                                item['query_type'] = 'general'
                                item['original_query'] = prompt
                                item['processing_timestamp'] = time.time()
                                item['extracted_from'] = 'general_search'
                                item['fiscal_year_filtered'] = bool(target_years)
                                item['fiscal_years_applied'] = target_years if target_years else []
                                item['award_types_filtered'] = target_award_types  # FIXED: Track award types applied
                                item['award_type_filtering_applied'] = target_award_types != ['all']
                            except Exception as metadata_error:
                                logging.warning(f"⚠️ Error adding general metadata: {metadata_error}")
                                continue
                        results.extend(general_data)
                    else:
                        if len(target_years) > 10:
                            logging.warning("⚠️ No general data after fiscal year filtering")
                            processing_warnings.append(f"No general data found in fiscal years FY{target_years[0]} to FY{target_years[-1]}")
                        else:
                            logging.warning("⚠️ No general data after fiscal year filtering")
                            processing_warnings.append(f"No general data found in fiscal years {target_years}")
                else:
                    logging.warning("⚠️ No valid general data returned")
                    processing_warnings.append("No general data found")
            except Exception as general_error:
                logging.error(f"❌ Error processing general query: {general_error}")
                processing_warnings.append(f"Error processing general query: {str(general_error)}")
        
        # ENHANCED: Better error handling for no data found with fiscal year context and award type context
        if not recipient_data_found or not results:
            logging.warning(f"❌ No data found for query: {prompt}")
            
            # Create a more helpful error message
            if recipients_with_no_data:
                recipient_names = ', '.join(recipients_with_no_data)
                
                # Get suggestions for recipients with no data
                suggestions = get_recipient_suggestions_enhanced(recipients_with_no_data)
                
                error_message = f"No federal spending data found for: {recipient_names}"
                
                # Add fiscal year context if years were specified - FIXED: Better handling for large ranges
                if target_years:
                    if len(target_years) > 10:
                        error_message += f"\n\nSearched fiscal years: FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)"
                        error_message += f"\nThis covers the period from October 1, {int(target_years[0])-1} to September 30, {target_years[-1]}"
                    else:
                        fiscal_year_info = []
                        for fy in target_years:
                            try:
                                fy_int = int(fy)
                                start_date = f"{fy_int-1}-10-01"
                                end_date = f"{fy_int}-09-30"
                                fiscal_year_info.append(f"FY {fy} ({start_date} to {end_date})")
                            except:
                                fiscal_year_info.append(f"FY {fy}")
                        
                        error_message += f"\n\nSearched fiscal years: {', '.join(fiscal_year_info)}"
                
                # FIXED: Add award type context if types were specified
                if target_award_types and target_award_types != ['all']:
                    award_type_info = ', '.join(target_award_types)
                    error_message += f"\nSearched award types: {award_type_info}"
                
                error_message += f"\n\nThis could mean:"
                error_message += f"\n• These entities have not received the specified types of federal contracts or grants in the searched time period"
                error_message += f"\n• The names might be spelled differently in government records"  
                error_message += f"\n• They might primarily work with non-federal agencies"
                error_message += f"\n• The data might be in a different fiscal year or award type"
                
                if suggestions:
                    suggestion_text = []
                    for recipient_name, suggested_names in suggestions.items():
                        if suggested_names:
                            suggestion_text.append(f"For '{recipient_name}', try: {', '.join(suggested_names[:3])}")
                    
                    if suggestion_text:
                        error_message += f"\n\nSuggestions:\n" + "\n".join(suggestion_text)
                
                # Add fiscal year tip - FIXED: Better handling for large ranges
                if target_years:
                    if len(target_years) > 10:
                        error_message += f"\n\nTip: You searched a wide range from FY{target_years[0]} to FY{target_years[-1]}. Try searching a smaller range or specific years."
                    else:
                        error_message += f"\n\nTip: Try searching different fiscal years or remove the year filter to search all available data."
                else:
                    error_message += f"\n\nTip: Try specifying a fiscal year (e.g., 'in 2022') or check if the entity name is spelled correctly."
                
                # FIXED: Add award type tip
                if target_award_types and target_award_types != ['all']:
                    error_message += f"\n\nAward Type Tip: Try searching different award types (contracts, grants, or remove type filter) or check if the entity receives the specified award types."
                
                return jsonify({
                    'error': error_message,
                    'no_data_found': True,
                    'recipients_with_no_data': recipients_with_no_data,
                    'query_details': query_details,
                    'processing_warnings': processing_warnings,
                    'suggestions': suggestions,
                    'fiscal_years_searched': target_years,
                    'award_types_searched': target_award_types,  # FIXED: Include award types in error response
                    'error_type': 'no_data_found'
                }), 404
            else:
                error_message = "No matching data found in the USA Spending database for this query."
                
                if target_years:
                    if len(target_years) > 10:
                        error_message += f" Searched fiscal years: FY{target_years[0]} to FY{target_years[-1]}"
                    else:
                        error_message += f" Searched fiscal years: {', '.join(target_years)}"
                
                # FIXED: Add award type context
                if target_award_types and target_award_types != ['all']:
                    error_message += f", award types: {', '.join(target_award_types)}"
                
                return jsonify({
                    'error': error_message,
                    'no_data_found': True,
                    'query_details': query_details,
                    'processing_warnings': processing_warnings,
                    'fiscal_years_searched': target_years,
                    'award_types_searched': target_award_types,  # FIXED: Include award types in error response
                    'error_type': 'general_no_data'
                }), 404
        
        # Continue with the rest of the function (validation, structuring, saving, etc.)
        # ... (rest of the function remains the same)
        
        # Step 3: Validate and clean results (with more lenient validation)
        validated_results = []
        if results:
            try:
                # Use more lenient validation for better data retention
                data_validator.validation_rules['strict_validation'] = False
                validated_results = data_validator.validate_and_clean(results)
                if validated_results is None:
                    validated_results = []
                    logging.warning("⚠️ Data validator returned None, using empty list")
            except Exception as validation_error:
                logging.error(f"❌ Error during validation: {validation_error}")
                validated_results = results  # Use original results if validation fails
                processing_warnings.append(f"Validation warning: {str(validation_error)}")
        
        if not isinstance(validated_results, list):
            validated_results = []
        
        # Final check for results after validation
        if not validated_results:
            logging.warning(f"❌ No valid results after validation for query: {prompt}")
            return jsonify({
                'error': f"No valid data found after processing. Warnings: {'; '.join(processing_warnings)}",
                'no_valid_data': True,
                'query_details': query_details,
                'processing_warnings': processing_warnings,
                'fiscal_years_searched': target_years,
                'award_types_searched': target_award_types,  # FIXED: Include award types in error response
                'error_type': 'validation_failed'
            }), 404
        
        # Step 4: Structure data with standardized calculations
        try:
            structured_results = structure_for_n8n_enhanced(validated_results, prompt, query_details)
        except Exception as structure_error:
            logging.error(f"❌ Error structuring results: {structure_error}")
            processing_warnings.append(f"Structure warning: {str(structure_error)}")
            structured_results = {
                'query_metadata': {
                    'original_prompt': prompt,
                    'query_details': query_details,
                    'processing_timestamp': time.time(),
                    'results_count': len(validated_results),
                    'error': str(structure_error)
                },
                'data_chunks': [{'chunk_id': 0, 'data': validated_results}],
                'summary': {'total_award_amount': 0, 'total_amount_spent': 0, 'total_remaining_amount': 0, 'error': str(structure_error)}
            }
        
        # Step 5: Save comprehensive data for CURRENT QUERY ONLY
        try:
            comprehensive_data = save_comprehensive_final_results_with_session(structured_results, prompt, query_details, validated_results)
        except Exception as save_error:
            logging.error(f"❌ Error saving comprehensive final results: {save_error}")
            processing_warnings.append(f"Save warning: {str(save_error)}")
            comprehensive_data = None
        
        # Step 6: Update summary WITH AI ANALYSIS
        try:
            update_summary_with_results(validated_results, prompt, query_details, structured_results)
        except Exception as summary_error:
            logging.error(f"❌ Error updating summary: {summary_error}")
            processing_warnings.append(f"Summary warning: {str(summary_error)}")
        
        # ENHANCED: Calculate correct awards count using standardized approach
        awards_count = 0
        total_results_count = len(validated_results)
        
        # Count awards specifically
        for item in validated_results:
            if isinstance(item, dict) and item.get('data_type') == 'award':
                awards_count += 1
        
        # Get financial summary from comprehensive data if available
        financial_summary = {}
        if comprehensive_data and isinstance(comprehensive_data, dict):
            financial_summary = comprehensive_data.get('financial_summary', {})
            # Also try to get awards count from detailed breakdown
            detailed_breakdown = comprehensive_data.get('data', {}).get('detailed_breakdown', {})
            if detailed_breakdown.get('total_awards') is not None:
                awards_count = detailed_breakdown.get('total_awards', awards_count)
        
        # FIXED: Better logging for large year ranges
        if len(target_years) > 10:
            logging.info(f"✅ Processing complete with FISCAL YEAR support (FY{target_years[0]}-FY{target_years[-1]}, {len(target_years)} years) and LENIENT validation and AWARD TYPE filtering. Found {total_results_count} total results, {awards_count} awards for NEW query")
        else:
            logging.info(f"✅ Processing complete with FISCAL YEAR support and LENIENT validation and AWARD TYPE filtering. Found {total_results_count} total results, {awards_count} awards for NEW query")
        
        if target_years:
            if len(target_years) > 10:
                logging.info(f"📅 FISCAL YEAR filtering applied: FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)")
            else:
                logging.info(f"📅 FISCAL YEAR filtering applied: {target_years}")
        if target_award_types and target_award_types != ['all']:
            logging.info(f"🎯 AWARD TYPE filtering applied: {target_award_types}")
        
        # ENHANCED: Build successful response with CORRECT awards count and award type info
        response_data = {
            'success': True,
            'results_count': total_results_count,  # Total results (for backward compatibility)
            'awards_count': awards_count,  # ENHANCED: Correct awards count for UI display
            'total_awards_count': awards_count,  # Alternative field name
            'query_details': query_details,
            'structured_results': structured_results,
            'financial_summary': financial_summary,  # Include financial summary
            'fiscal_years_processed': target_years,  # ENHANCED: Include fiscal year info
            'fiscal_year_filtering_applied': bool(target_years),
            'award_types_processed': target_award_types,  # FIXED: Include award type info
            'award_type_filtering_applied': target_award_types != ['all'],
            'message': f'Successfully processed query with FISCAL YEAR support and AWARD TYPE filtering and found {awards_count} awards ({total_results_count} total results)'
        }
        
        # Add fiscal year context to message - FIXED: Better handling for large ranges
        if target_years:
            if len(target_years) > 10:
                response_data['fiscal_year_details'] = [f"FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)"]
                response_data['message'] += f' for fiscal years: FY{target_years[0]} to FY{target_years[-1]} ({len(target_years)} years)'
            else:
                fiscal_year_context = []
                for fy in target_years:
                    try:
                        fy_int = int(fy)
                        start_date = f"{fy_int-1}-10-01"
                        end_date = f"{fy_int}-09-30"
                        fiscal_year_context.append(f"FY{fy} ({start_date} to {end_date})")
                    except:
                        fiscal_year_context.append(f"FY{fy}")
                response_data['fiscal_year_details'] = fiscal_year_context
                response_data['message'] += f' for fiscal years: {", ".join([f"FY{fy}" for fy in target_years])}'
        
        # FIXED: Add award type context to message
        if target_award_types and target_award_types != ['all']:
            response_data['message'] += f' of type: {", ".join(target_award_types)}'
        
        # Add warnings if any
        if processing_warnings:
            response_data['warnings'] = processing_warnings
            response_data['message'] += f' (with {len(processing_warnings)} notes)'
        
        # Add validation warnings separately
        if validation_warnings:
            response_data['validation_warnings'] = validation_warnings
        
        return jsonify(response_data)
        
    except Exception as e:
        logging.error(f"❌ Error processing query: {str(e)}")
        return jsonify({'error': f'Query processing failed: {str(e)}'}), 500
def save_comprehensive_final_results_with_session(structured_results, prompt, query_details, validated_results):
    """ENHANCED: Save comprehensive results with STANDARDIZED financial calculations and fiscal year filtering and award type filtering"""
    try:
        # ENHANCED: Apply year filtering to validated_results BEFORE calculating financial summary
        target_years = query_details.get('year', [])
        target_award_types = query_details.get('award_types', ['all'])
        
        # ENHANCED: Only filter if we have specific years and haven't already filtered
        if target_years:
            # Check if results are already filtered
            already_filtered = any(item.get('fiscal_year_filtered', False) for item in validated_results if isinstance(item, dict))
            
            if not already_filtered:
                logging.info(f"🔍 Applying additional fiscal year filtering to {len(validated_results)} results")
                filtered_results = filter_results_by_fiscal_year(validated_results, target_years)
                logging.info(f"📅 Additional filtering result: {len(filtered_results)} results")
            else:
                logging.info(f"📅 Results already filtered by fiscal year during processing")
                filtered_results = validated_results
        else:
            filtered_results = validated_results
        
        # ENHANCED: Calculate standardized financial summary from filtered results
        financial_summary = calculate_standardized_financial_summary(filtered_results)
        
        comprehensive_data = {
            "search_query": prompt,
            "query_details": query_details,
            "retrieval_date": datetime.now().isoformat(),
            "processing_complete": True,
            "structured_results": structured_results,
            "raw_results": filtered_results,  # ENHANCED: Use filtered results
            "financial_summary": financial_summary,  # ENHANCED: Use standardized calculation
            "spending_analysis": extract_spending_analysis_from_results(filtered_results),
            "fiscal_year_filtering": {  # ENHANCED: Add fiscal year context
                "target_years": target_years,
                "filtering_applied": bool(target_years),
                "original_results_count": len(validated_results),
                "filtered_results_count": len(filtered_results),
                "fiscal_year_details": []
            },
            "award_type_filtering": {  # FIXED: Add award type context
                "target_award_types": target_award_types,
                "filtering_applied": target_award_types != ['all'],
                "award_type_details": target_award_types
            },
            "data": {
                "summary": structured_results.get('summary', {}),
                "query_metadata": structured_results.get('query_metadata', {}),
                "all_results_by_type": {},
                "detailed_breakdown": {},
                "comprehensive_award_details": [],
                "all_recipients": [],
                "combined_awards": [],
                "combined_transactions": []
            }
        }
        
        # Add fiscal year details
        if target_years:
            for fy in target_years:
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    comprehensive_data["fiscal_year_filtering"]["fiscal_year_details"].append({
                        "fiscal_year": fy,
                        "start_date": start_date,
                        "end_date": end_date,
                        "description": f"FY{fy}: {start_date} to {end_date}"
                    })
                except:
                    comprehensive_data["fiscal_year_filtering"]["fiscal_year_details"].append({
                        "fiscal_year": fy,
                        "description": f"FY{fy}: Invalid format"
                    })
        
        # ENHANCED: Organize results by type with STANDARDIZED financial calculations
        awards_data = []
        transactions_data = []
        recipients_data = []
        agency_data = []
        state_data = []
        
        # Process filtered_results with standardized calculations
        for item in filtered_results:
            try:
                data_type = item.get('data_type', 'unknown')
                query_type = item.get('query_type', 'unknown')
                
                if data_type == 'award':
                    awards_data.append(item)
                elif data_type == 'transaction':
                    transactions_data.append(item)
                elif data_type == 'recipient_summary':
                    recipients_data.append(item)
                elif query_type == 'agency':
                    agency_data.append(item)
                elif query_type == 'state':
                    state_data.append(item)
                
                comprehensive_data["data"]["comprehensive_award_details"].append({
                    "type": data_type,
                    "category": query_type,
                    "details": item
                })
            except Exception as item_error:
                logging.warning(f"⚠️ Error processing item for organization: {item_error}")
                continue
        
        # Properly populate the separate sections
        comprehensive_data["data"]["all_recipients"] = recipients_data
        comprehensive_data["data"]["combined_awards"] = awards_data
        comprehensive_data["data"]["combined_transactions"] = transactions_data
        
        comprehensive_data["data"]["all_results_by_type"] = {
            "awards": awards_data,
            "transactions": transactions_data,
            "recipients": recipients_data,
            "agencies": agency_data,
            "states": state_data
        }
        
        # ENHANCED: Create detailed breakdown with STANDARDIZED calculations
        try:
            comprehensive_data["data"]["detailed_breakdown"] = {
                "total_awards": len(awards_data),
                "total_transactions": len(transactions_data),
                "total_recipients_processed": len(recipients_data),
                "total_agencies": len(agency_data),
                "total_states": len(state_data),
                "total_award_amount": financial_summary.get('total_amount_awarded', 0),
                "total_amount_spent": financial_summary.get('total_amount_spent', 0),
                "total_remaining_amount": financial_summary.get('remaining_amount', 0),
                "average_spending_percentage": financial_summary.get('spending_percentage', 0),
                "financial_efficiency_ratio": financial_summary.get('efficiency_ratio', 0),
                "award_types_found": list(set(item.get('award_type', 'Unknown') for item in awards_data if item.get('award_type'))),
                "agencies_found": list(set(item.get('awarding_agency', 'Unknown') for item in awards_data + transactions_data if item.get('awarding_agency'))),
                "recipients_found": list(set(item.get('recipient_name', 'Unknown') for item in filtered_results if item.get('recipient_name'))),
                "filtered_by_year": target_years,
                "filtered_by_award_types": target_award_types,  # FIXED: Include award types
                "original_results_count": len(validated_results),
                "filtered_results_count": len(filtered_results),
                "fiscal_year_filtering_applied": bool(target_years),
                "award_type_filtering_applied": target_award_types != ['all']  # FIXED: Track award type filtering
            }
        except Exception as breakdown_error:
            logging.error(f"❌ Error creating detailed breakdown: {breakdown_error}")
            comprehensive_data["data"]["detailed_breakdown"] = {
                "error": str(breakdown_error),
                "total_awards": len(awards_data),
                "total_transactions": len(transactions_data),
                "total_recipients_processed": len(recipients_data),
                "filtered_results_count": len(filtered_results),
                "original_results_count": len(validated_results),
                "fiscal_year_filtering_applied": bool(target_years),
                "award_type_filtering_applied": target_award_types != ['all']
            }
        
        # Create unique key for this query
        query_hash = abs(hash(prompt)) % 1000000
        query_key = f"query_{query_hash}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # ENHANCED: Save as current query data
        save_current_query_data(query_key, comprehensive_data)
        
        logging.info(f"✅ Saved comprehensive results with standardized financial calculations and fiscal year filtering and award type filtering")
        logging.info(f"📊 Awards: {len(awards_data)}, Financial Summary: {financial_summary}")
        if target_years:
            logging.info(f"📅 Fiscal year filtering: {target_years}")
        if target_award_types and target_award_types != ['all']:
            logging.info(f"🎯 Award type filtering: {target_award_types}")
        
        return comprehensive_data
        
    except Exception as e:
        logging.error(f"❌ Error saving comprehensive final results: {e}")
        return None

def calculate_standardized_financial_summary(filtered_results):
    """ENHANCED: Calculate standardized financial summary that matches across all modules"""
    try:
        total_awarded = 0
        total_spent = 0
        total_remaining = 0
        award_count = 0
        spending_percentages = []
        
        for item in filtered_results:
            if isinstance(item, dict):
                data_type = item.get('data_type', 'unknown')
                
                if data_type == 'award':
                    award_count += 1
                    
                    # Use standardized field names
                    award_amount = item.get('award_amount', 0) or 0
                    amount_spent = item.get('amount_spent', 0) or 0
                    remaining_amount = item.get('remaining_amount', 0) or 0
                    spending_percentage = item.get('spending_percentage', 0) or 0
                    
                    total_awarded += award_amount
                    total_spent += amount_spent
                    total_remaining += remaining_amount
                    
                    if spending_percentage > 0:
                        spending_percentages.append(spending_percentage)
        
        # Calculate averages
        avg_spending_percentage = sum(spending_percentages) / len(spending_percentages) if spending_percentages else 0
        efficiency_ratio = (total_remaining / total_awarded * 100) if total_awarded > 0 else 0
        
        return {
            "total_amount_awarded": total_awarded,
            "total_amount_spent": total_spent,
            "remaining_amount": total_remaining,
            "spending_percentage": round(avg_spending_percentage, 2),
            "efficiency_ratio": round(efficiency_ratio, 2),
            "total_awards_count": award_count,
            "calculation_method": "standardized_across_all_modules_with_fiscal_year_filtering_and_award_type_filtering"
        }
        
    except Exception as e:
        logging.error(f"❌ Error calculating standardized financial summary: {e}")
        return {
            "total_amount_awarded": 0,
            "total_amount_spent": 0,
            "remaining_amount": 0,
            "spending_percentage": 0,
            "efficiency_ratio": 0,
            "total_awards_count": 0,
            "error": str(e)
        }

def get_current_query_statistics(query_data):
    """ENHANCED: Get statistics for current query with STANDARDIZED calculations and fiscal year info and award type info"""
    try:
        if not query_data or not isinstance(query_data, dict):
            return {'total_queries': 0, 'total_results': 0, 'total_amount': 0, 'message': 'No current query data'}
        
        # ENHANCED: Get standardized financial summary from current query
        financial_summary = query_data.get('financial_summary', {})
        fiscal_year_filtering = query_data.get('fiscal_year_filtering', {})
        award_type_filtering = query_data.get('award_type_filtering', {})  # FIXED: Get award type filtering info
        
        # Use standardized fields
        total_award_amount = financial_summary.get('total_amount_awarded', 0)
        total_amount_spent = financial_summary.get('total_amount_spent', 0)
        total_remaining_amount = financial_summary.get('remaining_amount', 0)
        avg_spending_percentage = financial_summary.get('spending_percentage', 0)
        
        # Get results count from raw_results
        raw_results = query_data.get("raw_results", [])
        results_count = len(raw_results)
        
        # Count awards specifically
        awards_count = len([item for item in raw_results if isinstance(item, dict) and item.get('data_type') == 'award'])
        
        return {
            'total_queries': 1,
            'total_results': results_count,
            'total_amount': total_award_amount,
            'total_award_amount': total_award_amount,
            'total_amount_spent': total_amount_spent,
            'total_remaining_amount': total_remaining_amount,
            'total_awards_count': awards_count,
            'awards_count': awards_count,
            'average_spending_percentage': avg_spending_percentage,
            'financial_efficiency_ratio': financial_summary.get('efficiency_ratio', 0),
            'recent_queries': [CURRENT_QUERY_ID] if CURRENT_QUERY_ID else [],
            'session_start': query_data.get('retrieval_date', 'Unknown'),
            'last_updated': query_data.get('retrieval_date', 'Unknown'),
            'query_mode': 'current_query_only',
            'calculation_method': 'standardized',
            'fiscal_year_filtering': fiscal_year_filtering,  # ENHANCED: Include fiscal year info
            'fiscal_years_processed': fiscal_year_filtering.get('target_years', []),
            'fiscal_year_filtering_applied': fiscal_year_filtering.get('filtering_applied', False),
            'award_type_filtering': award_type_filtering,  # FIXED: Include award type info
            'award_types_processed': award_type_filtering.get('target_award_types', ['all']),
            'award_type_filtering_applied': award_type_filtering.get('filtering_applied', False)
        }
    except Exception as e:
        logging.error(f"❌ Error getting current query statistics: {e}")
        return {'error': str(e)}

def get_entity_statistics():
    """ENHANCED: Get enhanced entity statistics with STANDARDIZED calculations and fiscal year support and award type support"""
    try:
        final_results_data = load_final_results_data()
        if not final_results_data:
            return {'total_queries': 0, 'total_results': 0, 'total_amount': 0, 'message': 'No data available'}
        
        queries = [k for k in final_results_data.keys() if not k.startswith("_")]
        total_queries = len(queries)
        
        # Initialize totals
        total_results = 0
        total_award_amount = 0
        total_amount_spent = 0
        total_remaining_amount = 0
        total_awards_count = 0
        fiscal_year_queries = 0
        award_type_queries = 0  # FIXED: Track award type usage
        
        for query_key in queries:
            query_data = final_results_data[query_key]
            if isinstance(query_data, dict):
                # Get results count from raw_results
                raw_results = query_data.get("raw_results", [])
                if raw_results:
                    results_count = len(raw_results)
                    total_results += results_count
                    
                    # Count awards specifically
                    awards_count = len([item for item in raw_results if isinstance(item, dict) and item.get('data_type') == 'award'])
                    total_awards_count += awards_count
                
                # Get standardized financial data
                financial_summary = query_data.get('financial_summary', {})
                if financial_summary:
                    award_amount = financial_summary.get('total_amount_awarded', 0)
                    amount_spent = financial_summary.get('total_amount_spent', 0)
                    remaining_amount = financial_summary.get('remaining_amount', 0)
                    
                    if isinstance(award_amount, (int, float)):
                        total_award_amount += award_amount
                    if isinstance(amount_spent, (int, float)):
                        total_amount_spent += amount_spent
                    if isinstance(remaining_amount, (int, float)):
                        total_remaining_amount += remaining_amount
                
                # Check for fiscal year filtering
                fiscal_year_filtering = query_data.get('fiscal_year_filtering', {})
                if fiscal_year_filtering.get('filtering_applied', False):
                    fiscal_year_queries += 1
                
                # FIXED: Check for award type filtering
                award_type_filtering = query_data.get('award_type_filtering', {})
                if award_type_filtering.get('filtering_applied', False):
                    award_type_queries += 1
        
        session_info = final_results_data.get("_session_info", {})
        
        # Calculate averages
        avg_spending_percentage = (total_amount_spent / total_award_amount * 100) if total_award_amount > 0 else 0
        efficiency_ratio = (total_remaining_amount / total_award_amount * 100) if total_award_amount > 0 else 0
        
        return {
            'total_queries': total_queries,
            'total_results': total_results,
            'total_amount': total_award_amount,
            'total_award_amount': total_award_amount,
            'total_amount_spent': total_amount_spent,
            'total_remaining_amount': total_remaining_amount,
            'total_awards_count': total_awards_count,
            'awards_count': total_awards_count,
            'average_spending_percentage': round(avg_spending_percentage, 2),
            'financial_efficiency_ratio': round(efficiency_ratio, 2),
            'recent_queries': queries[-5:] if queries else [],
            'session_start': session_info.get('session_start', 'Unknown'),
            'last_updated': session_info.get('last_updated', 'Unknown'),
            'calculation_method': 'standardized',
            'fiscal_year_support': True,  # ENHANCED: Indicate fiscal year support
            'fiscal_year_queries': fiscal_year_queries,
            'fiscal_year_usage_percentage': round((fiscal_year_queries / total_queries * 100) if total_queries > 0 else 0, 1),
            'award_type_support': True,  # FIXED: Indicate award type support
            'award_type_queries': award_type_queries,
            'award_type_usage_percentage': round((award_type_queries / total_queries * 100) if total_queries > 0 else 0, 1)
        }
    except Exception as e:
        logging.error(f"❌ Error getting entity statistics: {e}")
        return {'error': str(e)}

def extract_financial_summary_from_results(validated_results):
    """ENHANCED: Extract financial summary using standardized calculations"""
    try:
        # Use the standardized calculation function
        return calculate_standardized_financial_summary(validated_results)
    except Exception as e:
        logging.error(f"❌ Error extracting financial summary: {e}")
        return {
            "total_amount_awarded": 0,
            "total_amount_spent": 0,
            "remaining_amount": 0,
            "spending_percentage": 0,
            "efficiency_ratio": 0,
            "total_awards_count": 0,
            "error": str(e)
        }

def extract_spending_analysis_from_results(validated_results):
    """Extract spending analysis from validated results"""
    try:
        # Look for existing spending analysis in results
        for item in validated_results:
            if isinstance(item, dict) and 'spending_analysis' in item:
                return item['spending_analysis']
        
        # If no existing analysis, create basic analysis
        awards_analyzed = 0
        awards_with_100_percent = 0
        spending_percentages = []
        
        for item in validated_results:
            if isinstance(item, dict) and item.get('data_type') == 'award':
                awards_analyzed += 1
                spending_pct = item.get('spending_percentage', 0)
                
                if isinstance(spending_pct, (int, float)):
                    spending_percentages.append(spending_pct)
                    if abs(spending_pct - 100.0) < 0.01:
                        awards_with_100_percent += 1
        
        avg_spending = sum(spending_percentages) / len(spending_percentages) if spending_percentages else 0
        
        return {
            "total_awards_analyzed": awards_analyzed,
            "sample_size": awards_analyzed,
            "awards_with_100_percent_spending": awards_with_100_percent,
            "awards_with_remaining_balance": awards_analyzed - awards_with_100_percent,
            "average_spending_percentage": round(avg_spending, 2),
            "suspicious_pattern_detected": (awards_with_100_percent / awards_analyzed > 0.8) if awards_analyzed > 0 else False,
            "data_quality_issues": ["Basic analysis - detailed analysis requires enhanced data"] if awards_analyzed == 0 else []
        }
        
    except Exception as e:
        logging.error(f"❌ Error extracting spending analysis: {e}")
        return {
            "total_awards_analyzed": 0,
            "sample_size": 0,
            "average_spending_percentage": 0,
            "error": str(e)
        }

def structure_for_n8n_enhanced(results, prompt, query_details):
    """ENHANCED: Enhanced structure data with standardized financial calculations and fiscal year support and award type support"""
    try:
        target_years = query_details.get('year', [])
        target_award_types = query_details.get('award_types', ['all'])  # FIXED: Get award types
        
        structured = {
            'query_metadata': {
                'original_prompt': prompt,
                'query_details': query_details,
                'processing_timestamp': time.time(),
                'results_count': len(results),
                'data_types_found': [],
                'sources_found': [],
                'fiscal_years_processed': target_years,
                'fiscal_year_filtering_applied': bool(target_years),
                'award_types_processed': target_award_types,  # FIXED: Include award types
                'award_type_filtering_applied': target_award_types != ['all']
            },
            'data_chunks': [],
            'summary': {
                'total_award_amount': 0,
                'total_amount_spent': 0,
                'total_remaining_amount': 0,
                'average_spending_percentage': 0,
                'total_transaction_amount': 0,
                'entity_types': {},
                'top_recipients': [],
                'top_awards': [],
                'award_types': {},
                'agencies': {},
                'date_range': {
                    'start': None,
                    'end': None
                },
                'fiscal_year_context': {
                    'target_years': target_years,
                    'filtering_applied': bool(target_years)
                },
                'award_type_context': {  # FIXED: Add award type context
                    'target_award_types': target_award_types,
                    'filtering_applied': target_award_types != ['all']
                }
            }
        }
        
        # Add fiscal year details to metadata
        if target_years:
            fiscal_year_details = []
            for fy in target_years:
                try:
                    fy_int = int(fy)
                    start_date = f"{fy_int-1}-10-01"
                    end_date = f"{fy_int}-09-30"
                    fiscal_year_details.append(f"FY{fy}: {start_date} to {end_date}")
                except:
                    fiscal_year_details.append(f"FY{fy}")
            structured['query_metadata']['fiscal_year_details'] = fiscal_year_details
        
        # FIXED: Add award type details to metadata
        if target_award_types and target_award_types != ['all']:
            structured['query_metadata']['award_type_details'] = target_award_types
        
        # Extract data types and sources
        try:
            data_types = set()
            sources = set()
            for item in results:
                if isinstance(item, dict):
                    data_type = item.get('data_type', 'unknown')
                    source = item.get('source', 'unknown')
                    if data_type:
                        data_types.add(data_type)
                    if source:
                        sources.add(source)
            
            structured['query_metadata']['data_types_found'] = list(data_types)
            structured['query_metadata']['sources_found'] = list(sources)
        except Exception as metadata_error:
            logging.warning(f"⚠️ Error extracting metadata: {metadata_error}")
        
        # Process results in chunks with STANDARDIZED financial calculation
        chunk_size = 50
        total_award_amount = 0
        total_amount_spent = 0
        total_remaining_amount = 0
        total_transaction_amount = 0
        entity_types = {}
        award_types = {}
        agencies = {}
        
        for i in range(0, len(results), chunk_size):
            chunk = results[i:i + chunk_size]
            
            chunk_data = {
                'chunk_id': i // chunk_size,
                'chunk_size': len(chunk),
                'data': chunk,
                'chunk_summary': {
                    'total_award_amount': 0,
                    'total_amount_spent': 0,
                    'total_remaining_amount': 0,
                    'total_transaction_amount': 0,
                    'average_spending_percentage': 0,
                    'entity_count': len(chunk),
                    'entity_names': [],
                    'award_ids': [],
                    'data_types': {},
                    'fiscal_year_context': {
                        'target_years': target_years,
                        'filtering_applied': bool(target_years)
                    },
                    'award_type_context': {  # FIXED: Add award type context to chunks
                        'target_award_types': target_award_types,
                        'filtering_applied': target_award_types != ['all']
                    }
                }
            }
            
            # ENHANCED: Use standardized financial calculations
            chunk_spending_percentages = []
            
            for item in chunk:
                try:
                    if not isinstance(item, dict):
                        continue
                    
                    data_type = item.get('data_type', 'unknown')
                    
                    # Use standardized field names
                    if data_type == 'award':
                        award_amount = item.get('award_amount', 0)
                        amount_spent = item.get('amount_spent', 0)
                        remaining_amount = item.get('remaining_amount', 0)
                        spending_percentage = item.get('spending_percentage', 0)
                        
                        chunk_data['chunk_summary']['total_award_amount'] += award_amount
                        chunk_data['chunk_summary']['total_amount_spent'] += amount_spent
                        chunk_data['chunk_summary']['total_remaining_amount'] += remaining_amount
                        
                        total_award_amount += award_amount
                        total_amount_spent += amount_spent
                        total_remaining_amount += remaining_amount
                        
                        if isinstance(spending_percentage, (int, float)):
                            chunk_spending_percentages.append(spending_percentage)
                        
                    elif data_type == 'transaction':
                        transaction_amount = float(item.get('transaction_amount', 0) or item.get('amount', 0) or 0)
                        chunk_data['chunk_summary']['total_transaction_amount'] += transaction_amount
                        total_transaction_amount += transaction_amount
                        chunk_data['chunk_summary']['total_amount_spent'] += transaction_amount
                        total_amount_spent += transaction_amount
                    
                    # Extract other metadata
                    name = item.get('name', '') or item.get('recipient_name', '')
                    if name and isinstance(name, str) and name not in chunk_data['chunk_summary']['entity_names']:
                        chunk_data['chunk_summary']['entity_names'].append(name)
                    
                    award_id = item.get('award_id', '')
                    if award_id and isinstance(award_id, str) and award_id not in chunk_data['chunk_summary']['award_ids']:
                        chunk_data['chunk_summary']['award_ids'].append(award_id)
                    
                    # Count entity types
                    query_type = item.get('query_type', 'unknown')
                    if isinstance(query_type, str):
                        entity_types[query_type] = entity_types.get(query_type, 0) + 1
                    
                    # Count data types
                    if isinstance(data_type, str):
                        chunk_data['chunk_summary']['data_types'][data_type] = chunk_data['chunk_summary']['data_types'].get(data_type, 0) + 1
                    
                    # Count award types
                    award_type = item.get('award_type', '')
                    if award_type and isinstance(award_type, str):
                        award_types[award_type] = award_types.get(award_type, 0) + 1
                    
                    # Count agencies
                    agency = item.get('awarding_agency', '')
                    if agency and isinstance(agency, str):
                        agencies[agency] = agencies.get(agency, 0) + 1
                        
                except Exception as item_error:
                    logging.warning(f"⚠️ Error processing item in chunk: {item_error}")
                    continue
            
            # Calculate chunk average spending percentage
            if chunk_spending_percentages:
                chunk_data['chunk_summary']['average_spending_percentage'] = sum(chunk_spending_percentages) / len(chunk_spending_percentages)
            
            structured['data_chunks'].append(chunk_data)
        
        # Update summary with standardized calculations
        try:
            structured['summary']['total_award_amount'] = total_award_amount
            structured['summary']['total_amount_spent'] = total_amount_spent
            structured['summary']['total_remaining_amount'] = total_remaining_amount
            structured['summary']['total_transaction_amount'] = total_transaction_amount
            structured['summary']['average_spending_percentage'] = (total_amount_spent / total_award_amount * 100) if total_award_amount > 0 else 0
            structured['summary']['entity_types'] = entity_types
            structured['summary']['award_types'] = award_types
            structured['summary']['agencies'] = agencies
            
        except Exception as summary_error:
            logging.error(f"❌ Error updating summary: {summary_error}")
        
        return structured
        
    except Exception as e:
        logging.error(f"❌ Error structuring data for n8n: {e}")
        return {
            'query_metadata': {
                'original_prompt': prompt,
                'error': str(e),
                'processing_timestamp': time.time(),
                'fiscal_years_processed': query_details.get('year', []) if query_details else [],
                'fiscal_year_filtering_applied': bool(query_details.get('year', []) if query_details else []),
                'award_types_processed': query_details.get('award_types', ['all']) if query_details else ['all'],  # FIXED: Include award types in error case
                'award_type_filtering_applied': (query_details.get('award_types', ['all']) != ['all']) if query_details else False
            },
            'data_chunks': [{'chunk_id': 0, 'data': results}] if results else [],
            'summary': {
                'total_award_amount': 0, 
                'total_amount_spent': 0, 
                'total_remaining_amount': 0,
                'error': str(e)
            }
        }

def update_summary_with_results(results, original_prompt, query_details, structured_results=None):
    """Update summary.json with new results - RESTORED AI ANALYSIS"""
    try:
        summary = load_summary_data()
        if summary is None:
            summary = {}
        
        query_hash = abs(hash(original_prompt)) % 1000000
        summary_key = f"query_{query_hash}"
        
        # RESTORED: Generate AI analysis with structured results
        try:
            ai_response = generate_ai_analysis_enhanced(results, original_prompt, structured_results)
        except Exception as ai_error:
            logging.warning(f"⚠️ AI analysis failed: {ai_error}")
            ai_response = "AI analysis not available due to error"
        
        summary[summary_key] = {
            'data': results,
            'prompt': original_prompt,
            'query_details': query_details,
            'timestamp': time.time(),
            'processed': True,
            'ai_response': ai_response,  # RESTORED: Full AI analysis
            'structured_results': structured_results
        }
        
        try:
            with open(SUMMARY_FILE, 'w') as f:
                json.dump(summary, f, indent=4, cls=DecimalEncoder)
            logging.info(f"✅ Updated summary with {len(results)} results and AI analysis")
        except Exception as save_error:
            logging.error(f"❌ Error saving summary file: {save_error}")
        
    except Exception as e:
        logging.error(f"❌ Error updating summary: {e}")

def generate_ai_analysis_enhanced(results, prompt, structured_results=None):
    """Generate enhanced AI analysis of the results with FINANCIAL FOCUS and award type awareness"""
    try:
        # Check if OpenAI client is properly initialized
        if not openai_client:
            logging.warning("⚠️ OpenAI client not available - skipping AI analysis")
            return "AI analysis not available - OpenAI client not configured"
        
        # Prepare enhanced data for AI analysis with FINANCIAL FOCUS and award type context
        try:
            # Extract financial summary if available
            financial_summary = {}
            spending_analysis = {}
            
            # Look for enhanced financial data in results
            for item in results[:5]:  # Check first 5 items
                if isinstance(item, dict):
                    if 'financial_summary' in item:
                        financial_summary = item['financial_summary']
                    if 'spending_analysis' in item:
                        spending_analysis = item['spending_analysis']
                    if financial_summary and spending_analysis:
                        break
            
            # Use structured results if available for better analysis
            if structured_results and isinstance(structured_results, dict):
                summary_data = structured_results.get('summary', {})
                total_award_amount = summary_data.get('total_award_amount', 0)
                total_amount_spent = summary_data.get('total_amount_spent', 0)
                total_remaining_amount = summary_data.get('total_remaining_amount', 0)
                avg_spending_percentage = summary_data.get('average_spending_percentage', 0)
                
                top_recipients = summary_data.get('top_recipients', [])[:5]
                top_awards = summary_data.get('top_awards', [])[:3]
                award_types = summary_data.get('award_types', {})
                agencies = summary_data.get('agencies', {})
                
                # FIXED: Get award type context
                award_type_context = summary_data.get('award_type_context', {})
                target_award_types = award_type_context.get('target_award_types', ['all'])
                award_type_filtering_applied = award_type_context.get('filtering_applied', False)
                
                # Format top recipients for analysis
                top_recipient_names = [r.get('name', 'Unknown') for r in top_recipients]
                
                # Get key statistics
                query_metadata = structured_results.get('query_metadata', {})
                total_results = query_metadata.get('results_count', len(results))
                data_types_found = query_metadata.get('data_types_found', [])
                
            else:
                # Fallback to financial summary
                total_award_amount = financial_summary.get('total_amount_awarded', 0)
                total_amount_spent = financial_summary.get('total_amount_spent', 0)
                total_remaining_amount = financial_summary.get('remaining_amount', 0)
                avg_spending_percentage = financial_summary.get('spending_percentage', 0)
                total_results = len(results)
                data_types_found = []
                top_recipient_names = []
                award_types = {}
                agencies = {}
                target_award_types = ['all']
                award_type_filtering_applied = False
            
            # Create sample data for AI with FINANCIAL FOCUS
            sample_data = []
            for item in results[:3]:  # Show 3 sample items
                if isinstance(item, dict):
                    sample_item = {
                        'recipient_name': item.get('recipient_name', 'Unknown'),
                        'award_amount': item.get('award_amount', 0),
                        'amount_spent': item.get('amount_spent', item.get('total_outlays', 0)),
                        'remaining_amount': item.get('remaining_amount', 0),
                        'spending_percentage': item.get('spending_percentage', 0),
                        'award_type': item.get('award_type', 'Unknown'),
                        'awarding_agency': item.get('awarding_agency', 'Unknown'),
                        'data_type': item.get('data_type', 'unknown')
                    }
                    sample_data.append(sample_item)
            
        except Exception as data_prep_error:
            logging.warning(f"⚠️ Error preparing enhanced data for AI analysis: {data_prep_error}")
            total_award_amount = 0
            total_amount_spent = 0
            total_remaining_amount = 0
            avg_spending_percentage = 0
            top_recipient_names = ['Data preparation error']
            total_results = len(results)
            sample_data = []
            award_types = {}
            agencies = {}
            data_types_found = []
            financial_summary = {}
            spending_analysis = {}
            target_award_types = ['all']
            award_type_filtering_applied = False
        
        # Create enhanced AI prompt with FINANCIAL FOCUS and award type awareness
        ai_prompt = f"""
        Analyze the following government spending data with a focus on financial efficiency and spending patterns:
        
        QUERY ANALYSIS:
        Original Query: {prompt}
        
        FINANCIAL OVERVIEW:
        - Total Results Found: {total_results}
        - Total Amount Awarded: ${total_award_amount:,.2f}
        - Total Amount Spent: ${total_amount_spent:,.2f}
        - Total Remaining Amount: ${total_remaining_amount:,.2f}
        - Average Spending Percentage: {avg_spending_percentage:.1f}%
        - Financial Efficiency Ratio: {((total_remaining_amount / total_award_amount * 100) if total_award_amount > 0 else 0):.1f}%
        - Data Types Found: {', '.join(data_types_found)}
        
        AWARD TYPE FILTERING:
        - Award Types Requested: {', '.join(target_award_types)}
        - Award Type Filtering Applied: {award_type_filtering_applied}
        - Results are {'filtered' if award_type_filtering_applied else 'unfiltered'} by award type
        
        SPENDING PATTERN ANALYSIS:
        {json.dumps(spending_analysis, indent=2) if spending_analysis else 'No detailed spending analysis available'}
        
        TOP RECIPIENTS:
        {', '.join(top_recipient_names[:5]) if top_recipient_names else 'None identified'}
        
        AWARD TYPES DISTRIBUTION:
        {json.dumps(award_types, indent=2) if award_types else 'No award type data'}
        
        AGENCIES INVOLVED:
        {json.dumps(dict(list(agencies.items())[:5]), indent=2) if agencies else 'No agency data'}
        
        SAMPLE FINANCIAL RECORDS:
        {json.dumps(sample_data, indent=2)}
        
        Please provide a FINANCIAL-FOCUSED analysis with AWARD TYPE awareness:
        1. EXECUTIVE FINANCIAL SUMMARY: Key financial findings, efficiency metrics, and spending patterns with award type context
        2. AWARD TYPE ANALYSIS: How the requested award types ({', '.join(target_award_types)}) affect the financial patterns
        3. SPENDING EFFICIENCY ANALYSIS: How well funds are being utilized, remaining balances, spending rates
        4. FINANCIAL RISK ASSESSMENT: Any unusual spending patterns, 100% spending flags, or data quality concerns
        5. RECIPIENT FINANCIAL PROFILE: Top recipients by funding amount and their spending patterns
        6. AGENCY SPENDING PATTERNS: Which agencies are involved and their funding distribution
        7. FINANCIAL COMPLIANCE INSIGHTS: Any potential areas requiring financial oversight or audit
        8. ACTIONABLE FINANCIAL RECOMMENDATIONS: Specific recommendations for financial monitoring and management
        
        Focus specifically on:
        - Award amounts vs. actual spending for the requested award types
        - Remaining fund balances and their implications
        - Unusual 100% spending patterns that may indicate data issues
        - Financial efficiency and fund utilization rates
        - Potential areas for cost savings or reallocation
        - Impact of award type filtering on financial patterns
        
        Format as structured text with clear financial sections and specific dollar amounts.
        """
        
        # Use the correct OpenAI API call format
        try:
            response = openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system", 
                        "content": "You are an expert government financial analyst specializing in federal spending efficiency, budget analysis, and financial compliance. Provide detailed, actionable financial insights with specific dollar amounts and efficiency metrics. Focus on financial patterns, spending efficiency, and potential areas of financial concern or optimization. Consider the impact of award type filtering on analysis."
                    },
                    {"role": "user", "content": ai_prompt}
                ],
                max_tokens=2000,  # Increased for more detailed financial analysis
                temperature=0.2,  # Lower temperature for more focused financial analysis
                timeout=60
            )
            
            analysis_result = response.choices[0].message.content
            logging.info("✅ Generated enhanced financial-focused AI analysis with award type awareness successfully")
            return analysis_result
            
        except Exception as api_error:
            logging.error(f"❌ OpenAI API error: {api_error}")
            return f"AI financial analysis error: OpenAI API call failed - {str(api_error)}"
        
    except Exception as e:
        logging.error(f"❌ Error generating enhanced financial AI analysis: {e}")
        return f"AI financial analysis error: {str(e)}"

@app.route('/api/get_latest_analysis')
def get_latest_analysis():
    """API endpoint to get the latest AI analysis"""
    try:
        summary_data = load_summary_data()
        
        if not summary_data:
            return jsonify({'analysis': 'No analysis available yet. Process some queries first.'})
        
        # Get the most recent query analysis
        latest_analysis = None
        latest_timestamp = 0
        
        for query_key, query_data in summary_data.items():
            if isinstance(query_data, dict) and not query_key.startswith('_'):
                timestamp = query_data.get('timestamp', 0)
                if timestamp > latest_timestamp:
                    latest_timestamp = timestamp
                    latest_analysis = query_data.get('ai_response', '')
        
        if latest_analysis:
            return jsonify({'analysis': latest_analysis})
        else:
            return jsonify({'analysis': 'No analysis available for current results.'})
            
    except Exception as e:
        logging.error(f"❌ Error getting latest analysis: {e}")
        return jsonify({'analysis': f'Error loading analysis: {str(e)}'})

@app.route('/export_excel')
def export_excel():
    """FIXED: Export only current query data to Excel"""
    try:
        global CURRENT_QUERY_DATA, CURRENT_QUERY_ID
        
        # FIXED: Use current query data if available, otherwise load from file
        if CURRENT_QUERY_DATA and CURRENT_QUERY_ID:
            logging.info(f"✅ Using current query data for Excel export: {CURRENT_QUERY_ID}")
            
            # Create a clean export data structure with only current query
            export_data = {
                "_session_info": {
                    "session_start": datetime.now().isoformat(),
                    "export_type": "current_query_only",
                    "current_query": CURRENT_QUERY_ID
                },
                "_metadata": {
                    "description": "USA Spending Data Analysis Results - Current Query Only",
                    "created": datetime.now().isoformat(),
                    "format_version": "1.0"
                },
                CURRENT_QUERY_ID: CURRENT_QUERY_DATA
            }
            
            excel_data = export_data
            
        else:
            # Fallback to file data but only get the most recent query
            logging.info("📁 No current query data in memory, loading from file")
            final_results_data = load_final_results_data()
            
            if not final_results_data:
                flash('No data available to export', 'warning')
                return redirect(url_for('results'))
            
            # Get only the most recent query
            queries = [k for k in final_results_data.keys() if not k.startswith("_")]
            if not queries:
                flash('No query data available to export', 'warning')
                return redirect(url_for('results'))
            
            # Sort by timestamp to get most recent
            latest_query = None
            latest_timestamp = 0
            
            for query_key in queries:
                query_data = final_results_data[query_key]
                if isinstance(query_data, dict):
                    timestamp = query_data.get('timestamp', 0)
                    if timestamp > latest_timestamp:
                        latest_timestamp = timestamp
                        latest_query = query_key
            
            if latest_query:
                # Create export data with only the latest query
                export_data = {
                    "_session_info": {
                        "session_start": datetime.now().isoformat(),
                        "export_type": "latest_query_only",
                        "latest_query": latest_query
                    },
                    "_metadata": {
                        "description": "USA Spending Data Analysis Results - Latest Query Only",
                        "created": datetime.now().isoformat(),
                        "format_version": "1.0"
                    },
                    latest_query: final_results_data[latest_query]
                }
                excel_data = export_data
                logging.info(f"✅ Using latest query data for export: {latest_query}")
            else:
                flash('No valid query data found to export', 'error')
                return redirect(url_for('results'))
        
        # Generate Excel with improved error handling
        try:
            excel_bytes = export_dynamic_json_to_excel_bytes(excel_data)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"usa_spending_single_query_{timestamp}.xlsx"
            
            logging.info(f"✅ SINGLE QUERY Excel file generated successfully: {filename}")
            
            return send_file(
                io.BytesIO(excel_bytes),
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                as_attachment=True,
                download_name=filename
            )
            
        except Exception as excel_error:
            logging.error(f"❌ Excel generation error: {excel_error}")
            flash(f'Excel generation failed: {str(excel_error)}. Check console logs for details.', 'error')
            return redirect(url_for('results'))
        
    except Exception as e:
        logging.error(f"❌ Error in export_excel route: {str(e)}")
        flash(f'Export failed: {str(e)}', 'error')
        return redirect(url_for('results'))

@app.route('/api/stats')
def api_stats():
    """FIXED: API endpoint for current query statistics only"""
    try:
        global CURRENT_QUERY_DATA, CURRENT_QUERY_ID
        
        if CURRENT_QUERY_DATA and CURRENT_QUERY_ID:
            # Calculate stats from current query data
            stats = get_current_query_statistics(CURRENT_QUERY_DATA)
            return jsonify(stats)
        else:
            # Fallback to file-based stats for latest query
            stats = get_entity_statistics()
            return jsonify(stats)
    except Exception as e:
        logging.error(f"❌ Error getting stats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/search/<search_term>')
def api_search(search_term):
    """FIXED: API endpoint for searching entities in current query only"""
    try:
        global CURRENT_QUERY_DATA
        
        if CURRENT_QUERY_DATA:
            matches = search_entities_in_current_query(search_term, CURRENT_QUERY_DATA)
        else:
            matches = search_entities_by_name(search_term)
        
        return jsonify(matches)
    except Exception as e:
        logging.error(f"❌ Error searching: {str(e)}")
        return jsonify({'error': str(e)}), 500

def search_entities_in_current_query(search_term, query_data):
    """Search entities in current query data only"""
    try:
        matches = []
        
        # Search in raw results
        raw_results = query_data.get('raw_results', [])
        for item in raw_results:
            if isinstance(item, dict):
                name = item.get('name', '') or item.get('recipient_name', '')
                if isinstance(name, str) and search_term.lower() in name.lower():
                    data_type = item.get('data_type', 'unknown')
                    if data_type == 'award':
                        amount = item.get('award_amount', 0) or item.get('amount', 0)
                    elif data_type == 'transaction':
                        amount = item.get('transaction_amount', 0) or item.get('amount', 0)
                    else:
                        amount = item.get('amount', 0)
                    
                    matches.append({
                        'name': name,
                        'amount': amount,
                        'query': query_data.get('search_query', 'Current Query'),
                        'type': item.get('data_type', 'unknown'),
                        'source': 'current_query'
                    })
        
        return matches[:20]  # Limit results
    except Exception as e:
        logging.error(f"❌ Error searching current query entities: {e}")
        return []

@app.route('/api/session/reset', methods=['POST'])
def reset_session():
    """Force reset current session"""
    try:
        global CURRENT_QUERY_ID, CURRENT_QUERY_DATA
        
        success = clean_files_on_startup()
        CURRENT_QUERY_ID = None
        CURRENT_QUERY_DATA = None
        
        if success:
            return jsonify({'success': True, 'message': 'Session reset successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to reset session'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Data Fetching Functions with fiscal year support and award type support
def fetch_agency_data(agency_name, query_details):
    """Fetch data for specific agency - FIXED for fiscal year and award type"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_category"
        
        years = query_details.get('year', ['2024'])
        if not isinstance(years, list):
            years = ['2024']
        
        # FIXED: Use fiscal year date ranges
        time_periods = get_fiscal_year_time_periods(years)
        
        # FIXED: Get award type codes from query
        award_types = query_details.get('award_types', ['all'])
        award_type_codes = get_award_type_codes(award_types)
        
        params = {
            "category": "awarding_agency",
            "filters": {
                "time_period": time_periods,
                "award_type_codes": award_type_codes  # FIXED: Use dynamic award type codes
            },
            "limit": 50
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for result in data.get('results', []):
            if isinstance(result, dict) and agency_name.lower() in result.get('name', '').lower():
                results.append(result)
        
        logging.info(f"✅ Fetched {len(results)} agency results for {agency_name} with award types: {award_types}")
        return results
        
    except Exception as e:
        logging.error(f"❌ Error fetching agency data for {agency_name}: {e}")
        return []

def fetch_state_data(state_name, query_details):
    """Fetch data for specific state - FIXED for fiscal year and award type"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_category"
        
        years = query_details.get('year', ['2024'])
        if not isinstance(years, list):
            years = ['2024']
        
        # FIXED: Use fiscal year date ranges
        time_periods = get_fiscal_year_time_periods(years)
        
        # FIXED: Get award type codes from query
        award_types = query_details.get('award_types', ['all'])
        award_type_codes = get_award_type_codes(award_types)
        
        params = {
            "category": "recipient_location",
            "filters": {
                "time_period": time_periods,
                "award_type_codes": award_type_codes,  # FIXED: Use dynamic award type codes
                "place_of_performance_locations": [{"country": "USA", "state": state_name}]
            },
            "limit": 50
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        results = data.get('results', [])
        logging.info(f"✅ Fetched {len(results)} state results for {state_name} with award types: {award_types}")
        return results
        
    except Exception as e:
        logging.error(f"❌ Error fetching state data for {state_name}: {e}")
        return []

def fetch_general_data(query_details):
    """Fetch general spending data based on query parameters - FIXED for fiscal year and award type"""
    try:
        url = "https://api.usaspending.gov/api/v2/search/spending_by_award"
        
        years = query_details.get('year', ['2024'])
        if not isinstance(years, list):
            years = ['2024']
        
        # FIXED: Use fiscal year date ranges
        time_periods = get_fiscal_year_time_periods(years)
        
        # FIXED: Get award type codes from query
        award_types = query_details.get('award_types', ['all'])
        award_type_codes = get_award_type_codes(award_types)
        
        params = {
            "filters": {
                "time_period": time_periods,
                "award_type_codes": award_type_codes  # FIXED: Use dynamic award type codes
            },
            "limit": 100,
            "page": 1,
            "sort": "Award Amount",
            "order": "desc"
        }
        
        response = requests.post(url, json=params, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        results = data.get('results', [])
        logging.info(f"✅ Fetched {len(results)} general results with award types: {award_types}")
        return results
        
    except Exception as e:
        logging.error(f"❌ Error fetching general data: {e}")
        return []

def fetch_recipient_data(url=None, max_pages=10):
    """Fetch all recipient data (optimized version)"""
    url = "https://api.usaspending.gov/api/v2/recipient/duns/"
    all_data = []

    for page in range(1, max_pages + 1):
        params = {
            "order": "desc",
            "sort": "amount",
            "limit": 100,
            "page": page,
            "award_type": "all"
        }

        try:
            logging.info(f"📥 Fetching recipient data page {page}...")
            response = requests.post(url, json=params, timeout=30)
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            if not results:
                logging.info(f"No more results at page {page}. Stopping.")
                break
            all_data.extend(results)
            logging.info(f"✅ Fetched page {page}, records: {len(results)}")

        except requests.exceptions.RequestException as e:
            logging.error(f"❌ Error fetching data on page {page}: {e}")
            break

    logging.info(f"📊 Total records fetched: {len(all_data)}")
    
    os.makedirs(os.path.dirname(ALL_RECIPIENTS_FILE) if os.path.dirname(ALL_RECIPIENTS_FILE) else '.', exist_ok=True)
    
    with open(ALL_RECIPIENTS_FILE, "w") as f:
        json.dump(all_data, f, indent=4)
    logging.info(f"✅ Saved {len(all_data)} recipients to {ALL_RECIPIENTS_FILE}")
    
    return all_data

def get_award_type_codes(award_types):
    """FIXED: Convert award types to API codes - moved from recipient_processor"""
    try:
        type_mapping = {
            'contracts': ['A', 'B', 'C', 'D'],
            'grants': ['02', '03', '04', '05'],
            'loans': ['07', '08'],
            'all': ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']
        }
        
        if not isinstance(award_types, list):
            award_types = ['all']
        
        codes = []
        for award_type in award_types:
            if isinstance(award_type, str):
                codes.extend(type_mapping.get(award_type.lower(), type_mapping['all']))
        
        # Remove duplicates
        codes = list(set(codes))
        logging.info(f"🎯 Award types {award_types} mapped to codes: {codes}")
        return codes
    except Exception as e:
        logging.error(f"❌ Error getting award type codes: {e}")
        return ['A', 'B', 'C', 'D', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11']

def load_summary_data():
    """Load summary data safely"""
    return safe_load_json_file(SUMMARY_FILE, {})

def load_final_results_data():
    """Load final results data safely"""
    return safe_load_json_file("final_results.json", {})

def search_entities_by_name(search_term):
    """Search entities by name safely"""
    try:
        summary_data = load_summary_data()
        final_results_data = load_final_results_data()
        matches = []
        
        # Search in summary data
        for query_key, query_data in summary_data.items():
            if isinstance(query_data, dict) and 'data' in query_data:
                for item in query_data['data']:
                    if isinstance(item, dict):
                        name = item.get('name', '') or item.get('recipient_name', '')
                        if isinstance(name, str) and search_term.lower() in name.lower():
                            data_type = item.get('data_type', 'unknown')
                            if data_type == 'award':
                                amount = item.get('award_amount', 0) or item.get('amount', 0)
                            elif data_type == 'transaction':
                                amount = item.get('transaction_amount', 0) or item.get('amount', 0)
                            else:
                                amount = item.get('amount', 0)
                            
                            matches.append({
                                'name': name,
                                'amount': amount,
                                'query': query_data.get('prompt', 'Unknown'),
                                'type': item.get('data_type', 'unknown'),
                                'source': 'summary'
                            })
        
        # Remove duplicates and limit results
        unique_matches = []
        seen = set()
        for match in matches:
            key = (match['name'], match['amount'], match['query'])
            if key not in seen:
                seen.add(key)
                unique_matches.append(match)
        
        return unique_matches[:20]
    except Exception as e:
        logging.error(f"❌ Error searching entities: {e}")
        return []

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)